"""The way to JARVIS's local models: the `jarvis-ml` service (ml_service.py).

It runs beside the server on the same machine, in its own Python
environment, and answers on loopback only (JARVIS_ML_URL, default
http://127.0.0.1:8341). This module is the server's side of the embeddings
it serves, which turn a sentence into a vector so memory can be searched by
meaning (jarvis_memory.search, memory_db.nearest).

Everything here fails soft. With the service down, not installed, or still
loading its model, `embed_*` return None and memory search falls back to
keywords. A failure also stops calls for a short while, so a missing
service costs one refused connection a minute, not one per question.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
import urllib.error
import urllib.request
from typing import Optional

log = logging.getLogger("jarvis.ml")

EMBED_MODEL = os.getenv("JARVIS_EMBED_MODEL", "BAAI/bge-small-en-v1.5")
TIMEOUT_SEC = 4.0
BACKOFF_SEC = 60.0

_down_until = 0.0
_lock = threading.Lock()


def base_url() -> str:
    return os.getenv("JARVIS_ML_URL", "http://127.0.0.1:8341").rstrip("/")


def enabled() -> bool:
    return os.getenv("JARVIS_ML", "1") != "0"


def _post(path: str, body: dict, timeout: float = TIMEOUT_SEC) -> Optional[dict]:
    global _down_until
    if not enabled() or time.time() < _down_until:
        return None
    req = urllib.request.Request(base_url() + path, data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())
    except (urllib.error.URLError, OSError, ValueError) as e:
        with _lock:
            if time.time() >= _down_until:
                log.info("local models unavailable (%s); keyword search only for now", e)
            _down_until = time.time() + BACKOFF_SEC
        return None


def _vectors(texts: list[str], kind: str) -> Optional[list[list[float]]]:
    if not texts:
        return []
    reply = _post("/embed", {"texts": texts, "kind": kind, "model": EMBED_MODEL},
                  timeout=TIMEOUT_SEC + len(texts) * 0.2)
    if not reply or reply.get("model") != EMBED_MODEL:
        return None
    vecs = reply.get("vectors")
    if not isinstance(vecs, list) or len(vecs) != len(texts):
        return None
    return vecs


def embed_query(text: str) -> Optional[list[float]]:
    vecs = _vectors([text[:2000]], "query")
    return vecs[0] if vecs else None


def embed_passages(texts: list[str]) -> Optional[list[list[float]]]:
    return _vectors([t[:4000] for t in texts], "passage")


def backfill(batch: int = 32) -> int:
    """Embed whatever in memory has no embedding yet (or one made from older
    text). Returns how many were stored. Called on a timer by the server."""
    import memory_db
    items = memory_db.missing_embeddings(EMBED_MODEL, limit=batch)
    if not items:
        return 0
    vecs = embed_passages([t for _, t in items])
    if vecs is None:
        return 0
    memory_db.store_embeddings(EMBED_MODEL, items, vecs)
    return len(items)


def status() -> dict:
    """What the dashboard shows: is the service there, and what is loaded."""
    global _down_until
    if not enabled():
        return {"up": False, "reason": "turned off (JARVIS_ML=0)"}
    req = urllib.request.Request(base_url() + "/health")
    try:
        with urllib.request.urlopen(req, timeout=2) as resp:
            body = json.loads(resp.read())
        _down_until = 0.0
        return {"up": True, **(body if isinstance(body, dict) else {})}
    except (urllib.error.URLError, OSError, ValueError) as e:
        return {"up": False, "reason": str(e)[:200]}


# ---------------------------------------------------------------------------
# Voice: speaking (Kokoro) and listening (Whisper). Async, on the server's
# own loop; same soft failure as above.
# ---------------------------------------------------------------------------

VOICE = os.getenv("JARVIS_VOICE", "bm_george:0.7,bm_lewis:0.3")
VOICE_SPEED = float(os.getenv("JARVIS_VOICE_SPEED", "1.05"))
_health: dict = {"at": 0.0, "body": {}}


def current_voice() -> str:
    """Read at each call, so a change in Settings is heard at once."""
    return os.getenv("JARVIS_VOICE", "").strip() or VOICE


def current_speed() -> float:
    try:
        return min(1.6, max(0.6, float(os.getenv("JARVIS_VOICE_SPEED", "") or VOICE_SPEED)))
    except ValueError:
        return VOICE_SPEED


def piper_setting(key: str) -> Optional[float]:
    """JARVIS_PIPER_NOISE / _W: how much a Piper voice varies (None: the
    voice's own default, 0.667 and 0.8 for a Piper voice)."""
    try:
        v = float(os.getenv(key, "") or "nan")
    except ValueError:
        return None
    return None if v != v else min(1.5, max(0.0, v))


async def health(max_age: float = 30.0) -> dict:
    """/health, cached briefly: which models are loaded."""
    if time.time() - _health["at"] < max_age:
        return _health["body"]
    import httpx
    body: dict = {}
    if enabled():
        try:
            async with httpx.AsyncClient(timeout=2.0) as c:
                r = await c.get(base_url() + "/health")
                if r.status_code == 200:
                    body = r.json()
        except (httpx.HTTPError, OSError, ValueError):
            body = {}
    _health.update(at=time.time(), body=body)
    return body


async def ready(engine: str) -> bool:
    return bool((await health()).get("ready", {}).get(engine))


async def speak(text: str, voice: str = "", speed: float = 0.0, client=None,
                noise: Optional[float] = None, noise_w: Optional[float] = None) -> Optional[bytes]:
    """MP3 (or WAV) of `text` in JARVIS's local voice, or None."""
    import httpx
    if not enabled():
        return None
    own = client is None
    client = client or httpx.AsyncClient(timeout=20.0)
    try:
        body = {"text": text, "voice": voice or current_voice(), "speed": speed or current_speed()}
        if body["voice"].startswith("piper:"):
            body["noise"] = noise if noise is not None else piper_setting("JARVIS_PIPER_NOISE")
            body["noise_w"] = noise_w if noise_w is not None else piper_setting("JARVIS_PIPER_NOISE_W")
        r = await client.post(base_url() + "/tts", json=body, timeout=20.0)
        if r.status_code != 200:
            log.warning("local voice refused (%s): %s", r.status_code, r.text[:200])
            if r.status_code == 503:
                _health["at"] = 0.0
            return None
        return r.content
    except (httpx.HTTPError, OSError) as e:
        log.warning("local voice unavailable: %s", e)
        _health["at"] = 0.0
        return None
    finally:
        if own:
            await client.aclose()


async def transcribe(wav: bytes, prompt: str = "") -> Optional[dict]:
    """{"text", "duration", "seconds"} for a recorded WAV, or None."""
    import httpx
    if not enabled():
        return None
    try:
        async with httpx.AsyncClient(timeout=30.0) as c:
            r = await c.post(base_url() + "/stt", content=wav, headers={
                "Content-Type": "audio/wav", "X-Prompt": " ".join(prompt.split())[:200]})
        if r.status_code != 200:
            log.warning("local listening refused (%s): %s", r.status_code, r.text[:200])
            return None
        return r.json()
    except (httpx.HTTPError, OSError, ValueError) as e:
        log.warning("local listening unavailable: %s", e)
        _health["at"] = 0.0
        return None
