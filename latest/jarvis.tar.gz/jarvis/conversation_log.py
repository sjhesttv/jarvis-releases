"""Everything that was said: one row per exchange in memory.db.

What is recorded: the user's own words and what JARVIS actually said back.
Never tool output. The brain's replies can paraphrase a page it read; the
owner has accepted that, so searching this log does not taint a turn
(server.TAINT_EXEMPT_TOOLS says so).

A day still reads as a Markdown document (`render_day`), which is what the
dashboard shows, edits (`replace_day`) and exports:

    # Conversations, 2026-11-03

    ## 14:32:05
    **You:** what's the server doing
    **JARVIS:** Four percent CPU and plenty of disk, sir.

Each field is flattened to one line, so an utterance can never forge an
entry of its own in that form, and `parse_text` reads back exactly what was
rendered.
"""

from __future__ import annotations

import re
import time
from contextlib import closing
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional

import memory_db
from jarvis_memory import one_line

FIELD_MAX = 4000
_DAY_RE = re.compile(r"\d{4}-\d{2}-\d{2}")
_TIME_RE = re.compile(r"## (\d{2}:\d{2}:\d{2})")
_WORD_RE = re.compile(r"[a-z0-9']+")
_STOP = frozenset("a an the and or but to of in on at for is it its it's i you "
                  "me my we what was were be do did does that this with sir".split())


@dataclass
class Exchange:
    day: str
    time: str
    you: str
    jarvis: str
    ts: float = 0.0

    @property
    def epoch(self) -> float:
        if self.ts:
            return self.ts
        try:
            return datetime.strptime(f"{self.day} {self.time}", "%Y-%m-%d %H:%M:%S").timestamp()
        except ValueError:
            return 0.0

    def as_dict(self) -> dict:
        return {"day": self.day, "time": self.time, "you": self.you, "jarvis": self.jarvis}


def _row(r) -> Exchange:
    return Exchange(r["day"], datetime.fromtimestamp(r["ts"]).strftime("%H:%M:%S"),
                    r["you"], r["jarvis"], r["ts"])


def append(you: str, jarvis: str, when: Optional[datetime] = None) -> Optional[int]:
    """Record one exchange. Never raises: a full disk must not stop a reply."""
    you = one_line(you, FIELD_MAX)
    jarvis = one_line(jarvis, FIELD_MAX)
    if not you and not jarvis:
        return None
    when = when or datetime.now()
    try:
        with closing(memory_db.connect()) as c, c:
            cur = c.execute("INSERT INTO exchanges (ts, day, you, jarvis) VALUES (?,?,?,?)",
                            (when.timestamp(), when.strftime("%Y-%m-%d"), you, jarvis))
            return int(cur.lastrowid)
    except Exception:
        return None


def day(slug: str) -> list[Exchange]:
    with closing(memory_db.connect()) as c:
        rows = c.execute("SELECT * FROM exchanges WHERE day = ? ORDER BY ts, id", (slug,)).fetchall()
    return [_row(r) for r in rows]


def days_meta() -> list[dict]:
    with closing(memory_db.connect()) as c:
        rows = c.execute("SELECT day, count(*) AS n FROM exchanges GROUP BY day ORDER BY day DESC").fetchall()
    return [{"slug": r["day"], "count": r["n"]} for r in rows]


def since(epoch: float, max_chars: int = 8000) -> list[Exchange]:
    """Exchanges after `epoch`, oldest first, the newest kept when over budget."""
    with closing(memory_db.connect()) as c:
        rows = c.execute("SELECT * FROM exchanges WHERE ts > ? ORDER BY ts DESC, id DESC LIMIT 400",
                         (epoch or 0.0,)).fetchall()
    kept, used = [], 0
    for r in rows:
        used += len(r["you"]) + len(r["jarvis"]) + 40
        if used > max_chars and kept:
            break
        kept.append(_row(r))
    return list(reversed(kept))


def last_exchange_epoch() -> float:
    with closing(memory_db.connect()) as c:
        r = c.execute("SELECT max(ts) FROM exchanges").fetchone()
    return float(r[0] or 0.0)


def _words(text: str) -> set[str]:
    return {w for w in _WORD_RE.findall(text.lower()) if w not in _STOP and len(w) > 1}


def search(query: str, days_back: int = 90, limit: int = 6) -> list[Exchange]:
    """Best-matching exchanges: every query word counts, a word in what the
    user said counts double, and newer wins a tie. Candidates come from the
    full-text index, so this stays fast however long the history gets."""
    wanted = _words(query)
    if not wanted:
        return []
    oldest = time.time() - max(1, days_back) * 86400
    ids = [rid for rid, _ in memory_db.keyword("exchanges", wanted, limit=500)]
    if not ids:
        return []
    with closing(memory_db.connect()) as c:
        marks = ",".join("?" * len(ids))
        rows = c.execute(f"SELECT * FROM exchanges WHERE id IN ({marks}) AND ts >= ?",
                         (*ids, oldest)).fetchall()
    scored = []
    for r in rows:
        e = _row(r)
        you, said = _words(e.you), _words(e.jarvis)
        score = 2 * len(wanted & you) + len(wanted & said)
        if score:
            scored.append((score, e.epoch, e))
    scored.sort(key=lambda t: (t[0], t[1]), reverse=True)
    return [e for _, _, e in scored[:limit]]


# --- the Markdown form of a day ---------------------------------------------

def render_day(slug: str) -> Optional[str]:
    if not isinstance(slug, str) or not _DAY_RE.fullmatch(slug):
        return None
    entries = day(slug)
    if not entries:
        return None
    out = [f"# Conversations, {slug}\n"]
    for e in entries:
        out.append(f"## {e.time}\n**You:** {e.you}\n**JARVIS:** {e.jarvis}\n")
    return "\n".join(out)


def parse_text(slug: str, text: str) -> list[Exchange]:
    out: list[Exchange] = []
    current: Optional[Exchange] = None
    for line in text.splitlines():
        m = _TIME_RE.fullmatch(line.strip())
        if m:
            current = Exchange(slug, m.group(1), "", "")
            out.append(current)
        elif current is not None and line.startswith("**You:** "):
            current.you = one_line(line[len("**You:** "):], FIELD_MAX)
        elif current is not None and line.startswith("**JARVIS:** "):
            current.jarvis = one_line(line[len("**JARVIS:** "):], FIELD_MAX)
    return [e for e in out if e.epoch and (e.you or e.jarvis)]


def replace_day(slug: str, text: str) -> None:
    """The owner's edit of one day: what the text says is what that day holds."""
    entries = parse_text(slug, text)
    with closing(memory_db.connect()) as c, c:
        c.execute("DELETE FROM exchanges WHERE day = ?", (slug,))
        for e in entries:
            c.execute("INSERT INTO exchanges (ts, day, you, jarvis) VALUES (?,?,?,?)",
                      (e.epoch, slug, e.you, e.jarvis))


def delete_day(slug: str) -> bool:
    with closing(memory_db.connect()) as c, c:
        return c.execute("DELETE FROM exchanges WHERE day = ?", (slug,)).rowcount > 0


def import_day(slug: str, text: str, replace: bool = False) -> str:
    """One day file from the old folder layout or an old export."""
    if not _DAY_RE.fullmatch(slug):
        return "kept"
    entries = parse_text(slug, text)
    with closing(memory_db.connect()) as c, c:
        have = {(round(r["ts"]), r["you"]) for r in c.execute(
            "SELECT ts, you FROM exchanges WHERE day = ?", (slug,))}
        if have and replace:
            c.execute("DELETE FROM exchanges WHERE day = ?", (slug,))
            have = set()
        added = 0
        for e in entries:
            if (round(e.epoch), e.you) in have:
                continue
            c.execute("INSERT INTO exchanges (ts, day, you, jarvis) VALUES (?,?,?,?)",
                      (e.epoch, slug, e.you, e.jarvis))
            added += 1
    return "added" if added else "kept"


def doc_path(slug: str):
    import jarvis_memory
    return jarvis_memory.doc_path("conversation", slug)
