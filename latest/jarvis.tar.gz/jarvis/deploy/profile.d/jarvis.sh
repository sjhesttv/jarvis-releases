# Shown on SSH login until JARVIS has been set up. Installed by deploy/install.sh.
if [ -n "$PS1" ] && [ ! -f /etc/jarvis/jarvis.env ]; then
  printf '\n  JARVIS is installed but not set up yet. Run:  sudo jarvis-setup\n\n'
fi
