"""The windows JARVIS has open on the user's screen — his to open, move,
resize and close.

The server is the source of truth: every window has an id ("w3") the brain
can name, a kind (image, markdown, text, html, page, download) and a layout
given in words, because a language model places "the report on the left,
the site on the right" far more reliably than it does pixels:

    position  center | left | right | top | bottom | top-left | top-right |
              bottom-left | bottom-right | full
    size      small | medium | large | full

The page turns a layout into a rectangle for its own viewport and animates
every change. A page that connects later (a reload, a second tab) is sent
`snapshot()` so it shows what JARVIS has open. If the user closes one by
hand, the page says so and `forget()` drops it.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Optional

POSITIONS = ("center", "left", "right", "top", "bottom", "top-left", "top-right",
             "bottom-left", "bottom-right", "full")
SIZES = ("small", "medium", "large", "full")
KINDS = ("image", "markdown", "text", "html", "page", "live", "download")
MAX_WINDOWS = 6

# Where a new window goes when JARVIS does not say: the first one in the
# middle, then the halves, then the corners — the least-covered spot first.
_AUTO = ("center", "right", "left", "top-right", "top-left", "bottom-right",
         "bottom-left")


class WindowProblem(ValueError):
    """Said back to the brain as is."""


@dataclass
class Window:
    id: str
    kind: str
    title: str
    url: str
    position: str = "center"
    size: str = "medium"
    name: str = ""
    source: str = ""
    z: int = 0
    extra: dict = field(default_factory=dict)

    def frame(self) -> dict:
        """The protocol message that opens (or re-opens) this window."""
        return {"type": "window", "action": "open", "id": self.id, "kind": self.kind,
                "title": self.title, "url": self.url, "position": self.position,
                "size": self.size, "name": self.name, "source": self.source, "z": self.z}

    def describe(self) -> str:
        what = {"page": "web page (picture)", "live": "live web page",
                "download": "file"}.get(self.kind, self.kind)
        where = f"{self.size} {self.position}" if self.position != "full" else "full screen"
        extra = f" of {self.source}" if self.kind in ("page", "live") and self.source else ""
        return f"{self.id}: {what}{extra} '{self.title}', {where}"


class WindowManager:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._windows: dict[str, Window] = {}
        self._next = 1
        self._z = 0

    # -- validation ------------------------------------------------------------
    @staticmethod
    def layout(position: Optional[str], size: Optional[str]) -> tuple[Optional[str], Optional[str]]:
        pos = (position or "").strip().lower().replace(" ", "-") or None
        sz = (size or "").strip().lower() or None
        if pos is not None and pos not in POSITIONS:
            raise WindowProblem(f"Position must be one of: {', '.join(POSITIONS)}.")
        if sz is not None and sz not in SIZES:
            raise WindowProblem(f"Size must be one of: {', '.join(SIZES)}.")
        return pos, sz

    def _free_position(self) -> str:
        taken = {w.position for w in self._windows.values()}
        return next((p for p in _AUTO if p not in taken), "center")

    # -- the operations -----------------------------------------------------------
    def open(self, kind: str, title: str, url: str, *, position: Optional[str] = None,
             size: Optional[str] = None, name: str = "", source: str = "") -> tuple[Window, list[str]]:
        """A new window. Returns it and the ids closed to make room."""
        if kind not in KINDS:
            kind = "download"
        pos, sz = self.layout(position, size)
        with self._lock:
            closed = []
            while len(self._windows) >= MAX_WINDOWS:
                oldest = min(self._windows.values(), key=lambda w: w.z)
                closed.append(oldest.id)
                del self._windows[oldest.id]
            if pos is None:
                pos = self._free_position()
            if sz is None:
                sz = "large" if pos in ("center", "full") and not self._windows else (
                    "full" if pos == "full" else "medium")
            self._z += 1
            win = Window(id=f"w{self._next}", kind=kind, title=title[:120], url=url,
                         position=pos, size=sz, name=name, source=source, z=self._z)
            self._next += 1
            self._windows[win.id] = win
            return win, closed

    def get(self, wid: str) -> Window:
        win = self._windows.get(str(wid or "").strip())
        if win is None:
            ids = ", ".join(self._windows) or "none"
            raise WindowProblem(f"There is no window {wid!r}; open now: {ids}.")
        return win

    def place(self, wid: str, position: Optional[str] = None,
              size: Optional[str] = None) -> Window:
        pos, sz = self.layout(position, size)
        if pos is None and sz is None:
            raise WindowProblem("Say where to put it (position) or how big (size).")
        with self._lock:
            win = self.get(wid)
            if pos is not None:
                win.position = pos
            if sz is not None:
                win.size = sz
            if pos == "full":
                win.size = "full"
            self._z += 1
            win.z = self._z
            return win

    def focus(self, wid: str) -> Window:
        with self._lock:
            win = self.get(wid)
            self._z += 1
            win.z = self._z
            return win

    def close(self, wid: str) -> Window:
        with self._lock:
            win = self.get(wid)
            del self._windows[win.id]
            return win

    def close_all(self) -> list[str]:
        with self._lock:
            ids = list(self._windows)
            self._windows.clear()
            return ids

    def forget(self, wid: str) -> bool:
        """The user closed it by hand."""
        with self._lock:
            return self._windows.pop(str(wid), None) is not None

    def update_url(self, wid: str, url: str, name: str = "") -> Window:
        with self._lock:
            win = self.get(wid)
            win.url = url
            if name:
                win.name = name
            return win

    def listing(self) -> list[Window]:
        return sorted(self._windows.values(), key=lambda w: w.z)

    def snapshot(self) -> list[dict]:
        return [w.frame() for w in self.listing()]

    def describe(self) -> str:
        rows = self.listing()
        if not rows:
            return "No windows are open."
        return "Open windows, back to front:\n" + "\n".join(w.describe() for w in rows)
