"""Connections the owner manages from the settings panel.

Two kinds, because they are wired into JARVIS differently:

* **GitHub** — a token in `GH_TOKEN`. `gh` (gh_lookup.py) and every spawned
  run read it from the environment, so saving it takes effect at once, and
  `gh auth setup-git` lets `git clone` / `git push` in a run use it too. It
  lives in the settings `.env` (JARVIS_ENV_FILE), never in the browser: the
  status endpoint reports the account it belongs to, not the token.

* **MCP servers** — entries in `<data>/jarvis/connections.json`, the one file
  the brain's MCP config is built from (server._write_mcp_config). The brain
  reads it when it starts, so a change needs a restart to connect. Secrets in
  an entry (`env`, `headers`) are written to that 0600 file and never sent
  back to the browser.

Everything that touches the file or a subprocess is here; the routes in
server.py are thin.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import shutil
from pathlib import Path
from typing import Optional
from urllib.parse import urlsplit

import httpx

import auth_store
import claude_env
import data_paths

log = logging.getLogger("jarvis.connectors")

GITHUB_API = "https://api.github.com/user"
TOKEN_RE = re.compile(r"[A-Za-z0-9_]{20,255}")

# Same rule server.declared_connections applies when it reads the file.
SERVER_NAME_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}")
RESERVED = "jarvis"
ENV_KEY_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]{0,127}")
HEADER_RE = re.compile(r"[A-Za-z0-9-]{1,64}")
MAX_ARGS = 32
MAX_VALUE = 4096


class ConnectorError(ValueError):
    """Something the owner can fix; the message is shown to them as is."""


# ---------------------------------------------------------------------------
# GitHub
# ---------------------------------------------------------------------------

async def github_identity(token: str, client: Optional[httpx.AsyncClient] = None
                          ) -> tuple[bool, str]:
    """(True, login) if GitHub accepts the token, else (False, why)."""
    if not token:
        return False, "No token."
    if not TOKEN_RE.fullmatch(token):
        return False, "That does not look like a GitHub token."
    owned = client is None
    client = client or httpx.AsyncClient(timeout=8.0)
    try:
        resp = await client.get(GITHUB_API, headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "User-Agent": "jarvis-connectors"})
    except httpx.HTTPError as e:
        return False, f"Could not reach GitHub ({type(e).__name__})."
    finally:
        if owned:
            await client.aclose()
    if resp.status_code == 200:
        try:
            return True, str(resp.json().get("login") or "")
        except ValueError:
            return True, ""
    if resp.status_code in (401, 403):
        return False, "GitHub refused that token."
    return False, f"GitHub answered HTTP {resp.status_code}."


async def _run(*args: str, timeout: float = 15.0) -> tuple[int, str]:
    try:
        proc = await asyncio.create_subprocess_exec(
            *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
            env=claude_env.child_env())
    except OSError as e:
        return -1, str(e)
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout)
    except asyncio.TimeoutError:
        proc.kill()
        return -1, "timed out"
    return proc.returncode or 0, out.decode("utf-8", "ignore").strip()


async def configure_git(name: str, email: str) -> list[str]:
    """Let git use GH_TOKEN (through gh) and sign commits. Returns notes for
    anything that could not be done; never raises."""
    notes = []
    if shutil.which("gh"):
        rc, out = await _run("gh", "auth", "setup-git", "--hostname", "github.com")
        if rc != 0:
            notes.append(f"gh auth setup-git failed: {out[:200]}")
    else:
        notes.append("gh is not installed, so git push will not use the token.")
    if shutil.which("git"):
        for key, value in (("user.name", name), ("user.email", email)):
            if value:
                rc, out = await _run("git", "config", "--global", key, value)
                if rc != 0:
                    notes.append(f"git config {key} failed: {out[:200]}")
    return notes


def clean_git_identity(name: str, email: str) -> tuple[str, str]:
    name, email = (name or "").strip(), (email or "").strip()
    if len(name) > 100 or any(ord(c) < 32 for c in name):
        raise ConnectorError("That commit name is not usable.")
    if email and (len(email) > 254 or not re.fullmatch(r"[^@\s]+@[^@\s]+", email)):
        raise ConnectorError("That commit email is not usable.")
    return name, email


# ---------------------------------------------------------------------------
# MCP servers (connections.json)
# ---------------------------------------------------------------------------

def _load() -> dict:
    """The whole file as an object, keeping the comment keys. A file that does
    not parse is REFUSED, never replaced: it is still the owner's config."""
    data_paths.ensure_brain_home()
    path = data_paths.connections_path()
    try:
        body = json.loads(path.read_text())
    except FileNotFoundError:
        body = {}
    except ValueError as e:
        raise ConnectorError(f"{path} is not valid JSON ({e}); fix it by hand "
                             f"first, so nothing in it is lost.")
    if not isinstance(body, dict):
        raise ConnectorError(f"{path} must contain a JSON object.")
    if not isinstance(body.get("mcpServers", {}), dict):
        raise ConnectorError(f'"mcpServers" in {path} must be an object.')
    body.setdefault("mcpServers", {})
    return body


def _save(body: dict) -> None:
    auth_store.write_private(data_paths.connections_path(),
                             json.dumps(body, indent=2) + "\n")


def describe(name: str, entry: dict, connected: set[str]) -> dict:
    """What the browser may see about one server: never env or header values."""
    url = entry.get("url") if isinstance(entry.get("url"), str) else ""
    command = entry.get("command") if isinstance(entry.get("command"), str) else ""
    args = entry.get("args") if isinstance(entry.get("args"), list) else []
    if url:
        parts = urlsplit(url)
        target = f"{parts.scheme}://{parts.netloc}{parts.path}"
    else:
        target = " ".join([command, *[str(a) for a in args]]).strip()
    secrets = []
    for block in ("env", "headers"):
        if isinstance(entry.get(block), dict):
            secrets.extend(str(k) for k in entry[block])
    secrets.sort()
    return {"name": name, "kind": "url" if url else "command", "target": target,
            "secrets": secrets, "connected": name in connected}


def list_servers(connected: set[str]) -> list[dict]:
    try:
        block = _load()["mcpServers"]
    except ConnectorError:
        return []
    return [describe(n, e, connected) for n, e in sorted(block.items())
            if isinstance(e, dict)]


def _pairs(raw, pattern: re.Pattern, what: str) -> dict[str, str]:
    if not raw:
        return {}
    if not isinstance(raw, dict):
        raise ConnectorError(f"{what} must be name/value pairs.")
    out = {}
    for key, value in raw.items():
        if not isinstance(key, str) or not pattern.fullmatch(key):
            raise ConnectorError(f"{key!r} is not a usable {what} name.")
        if not isinstance(value, str) or len(value) > MAX_VALUE or "\n" in value or "\r" in value:
            raise ConnectorError(f"The value for {key} is not usable.")
        out[key] = value
    return out


def build_entry(spec: dict) -> tuple[str, dict]:
    """Validate what the form sent and turn it into a connections.json entry."""
    name = str(spec.get("name") or "").strip()
    if not SERVER_NAME_RE.fullmatch(name) or "__" in name:
        raise ConnectorError("Use a short name: letters, digits, dots, dashes "
                             "and single underscores.")
    if name == RESERVED:
        raise ConnectorError('"jarvis" is the name of JARVIS\'s own tools; pick another.')
    url = str(spec.get("url") or "").strip()
    command = str(spec.get("command") or "").strip()
    if bool(url) == bool(command):
        raise ConnectorError("Give either a URL or a command, not both.")
    if url:
        parts = urlsplit(url)
        local = parts.hostname in ("localhost", "127.0.0.1", "::1")
        if parts.scheme not in ("https", "http") or not parts.netloc or \
                (parts.scheme == "http" and not local):
            raise ConnectorError("A remote server's URL must start with https://.")
        if len(url) > 2048:
            raise ConnectorError("That URL is too long.")
        entry: dict = {"type": "http", "url": url}
        headers = _pairs(spec.get("headers"), HEADER_RE, "header")
        if headers:
            entry["headers"] = headers
        return name, entry
    args = spec.get("args") or []
    if not isinstance(args, list) or len(args) > MAX_ARGS or \
            not all(isinstance(a, str) and len(a) <= MAX_VALUE for a in args):
        raise ConnectorError("The arguments are not usable.")
    if len(command) > 512 or any(ord(c) < 32 for c in command):
        raise ConnectorError("That command is not usable.")
    entry = {"command": command, "args": args}
    env = _pairs(spec.get("env"), ENV_KEY_RE, "environment variable")
    if env:
        entry["env"] = env
    return name, entry


def add_server(spec: dict, replace: bool = False) -> str:
    name, entry = build_entry(spec)
    body = _load()
    if name in body["mcpServers"] and not replace:
        raise ConnectorError(f'There is already a connection named "{name}".')
    body["mcpServers"][name] = entry
    _save(body)
    log.info("connectors: saved MCP server %s", name)
    return name


def remove_server(name: str) -> bool:
    body = _load()
    if name not in body["mcpServers"]:
        return False
    del body["mcpServers"][name]
    _save(body)
    log.info("connectors: removed MCP server %s", name)
    return True


def file_path() -> Path:
    return data_paths.connections_path()
