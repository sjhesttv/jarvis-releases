"""Scheduled and background jobs: what JARVIS does when nobody is talking.

Four kinds:

  remind     at the time, tell the user something. No brain needed.
  check      at the time, have the brain look into something with its reading
             tools ("is CI green on jarvis?", "anything new on my PRs?") and
             report it. `until_reported` makes it a watcher: it keeps
             checking on its schedule until the brain has something to say,
             then stops ("tell me when the deploy finishes").
  watch_url  fetch a page on a schedule and say when its text changes.
  watch_run  say when one of JARVIS's own runs finishes.

When:
  once at a time · every N minutes · daily at HH:MM (optionally weekdays
  only), all in the server's own time zone, which the setup wizard sets.

Stored in SQLite (`<data>/jobs.db`). The scheduler in server.py asks
`due()` every few seconds and calls back to do the work, so this module has
no opinion about brains, speech or push.
"""

from __future__ import annotations

import json
import re
import secrets
import sqlite3
import threading
import time
from contextlib import closing
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from typing import Optional

import data_paths

KINDS = ("remind", "check", "watch_url", "watch_run")
MIN_INTERVAL_MIN = 5
MAX_JOBS = 50
TITLE_MAX = 120
PROMPT_MAX = 2000
_lock = threading.Lock()


class JobProblem(ValueError):
    """Said back to the brain or the dashboard as is."""


@dataclass
class Job:
    id: str
    title: str
    kind: str
    schedule: dict
    prompt: str = ""
    url: str = ""
    run_id: str = ""
    until_reported: bool = False
    enabled: bool = True
    next_run: Optional[float] = None
    last_run: Optional[float] = None
    last_result: str = ""
    state: dict = field(default_factory=dict)
    created: float = field(default_factory=time.time)

    def as_dict(self) -> dict:
        d = dict(self.__dict__)
        d["when"] = describe_schedule(self.schedule)
        return d


def _db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(data_paths.data_dir() / "jobs.db"))
    conn.row_factory = sqlite3.Row
    conn.execute("""CREATE TABLE IF NOT EXISTS jobs (
        id TEXT PRIMARY KEY, title TEXT NOT NULL, kind TEXT NOT NULL,
        schedule TEXT NOT NULL, prompt TEXT NOT NULL DEFAULT '', url TEXT NOT NULL DEFAULT '',
        run_id TEXT NOT NULL DEFAULT '', until_reported INTEGER NOT NULL DEFAULT 0,
        enabled INTEGER NOT NULL DEFAULT 1, next_run REAL, last_run REAL,
        last_result TEXT NOT NULL DEFAULT '', state TEXT NOT NULL DEFAULT '{}',
        created REAL NOT NULL)""")
    return conn


def _row(r: sqlite3.Row) -> Job:
    return Job(id=r["id"], title=r["title"], kind=r["kind"], schedule=json.loads(r["schedule"]),
               prompt=r["prompt"], url=r["url"], run_id=r["run_id"],
               until_reported=bool(r["until_reported"]), enabled=bool(r["enabled"]),
               next_run=r["next_run"], last_run=r["last_run"], last_result=r["last_result"],
               state=json.loads(r["state"] or "{}"), created=r["created"])


def _write(job: Job) -> None:
    with closing(_db()) as conn, conn:
        conn.execute("""INSERT OR REPLACE INTO jobs VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
            job.id, job.title, job.kind, json.dumps(job.schedule), job.prompt, job.url, job.run_id,
            int(job.until_reported), int(job.enabled), job.next_run, job.last_run,
            job.last_result[:2000], json.dumps(job.state), job.created))


# ---------------------------------------------------------------------------
# When
# ---------------------------------------------------------------------------

_HHMM = re.compile(r"([01]?\d|2[0-3]):([0-5]\d)")
_DATETIME = re.compile(r"(\d{4})-(\d{2})-(\d{2})[ T]([01]?\d|2[0-3]):([0-5]\d)")


def parse_schedule(when: dict, now: Optional[float] = None) -> dict:
    """Validate what the brain or the dashboard asked for into a schedule."""
    if not isinstance(when, dict):
        raise JobProblem("Say when: in_minutes, at (YYYY-MM-DD HH:MM), daily_at (HH:MM) or every_minutes.")
    now = now or time.time()
    if when.get("in_minutes") is not None:
        try:
            minutes = float(when["in_minutes"])
        except (TypeError, ValueError):
            raise JobProblem("in_minutes must be a number.")
        if not 0 < minutes <= 60 * 24 * 365:
            raise JobProblem("in_minutes must be between 0 and a year.")
        return {"type": "once", "at": now + minutes * 60}
    if when.get("at"):
        m = _DATETIME.fullmatch(str(when["at"]).strip())
        if not m:
            raise JobProblem("at must look like 2026-11-05 08:30 (server time).")
        y, mo, d, h, mi = (int(x) for x in m.groups())
        try:
            at = datetime(y, mo, d, h, mi).timestamp()
        except ValueError:
            raise JobProblem("That date does not exist.")
        if at < now - 60:
            raise JobProblem("That time has already passed.")
        return {"type": "once", "at": at}
    if when.get("daily_at"):
        m = _HHMM.fullmatch(str(when["daily_at"]).strip())
        if not m:
            raise JobProblem("daily_at must look like 08:30.")
        return {"type": "daily", "time": f"{int(m.group(1)):02d}:{m.group(2)}",
                "weekdays": bool(when.get("weekdays"))}
    if when.get("every_minutes") is not None:
        try:
            minutes = int(when["every_minutes"])
        except (TypeError, ValueError):
            raise JobProblem("every_minutes must be a whole number.")
        if minutes < MIN_INTERVAL_MIN or minutes > 60 * 24 * 7:
            raise JobProblem(f"every_minutes must be between {MIN_INTERVAL_MIN} and a week.")
        return {"type": "interval", "minutes": minutes}
    raise JobProblem("Say when: in_minutes, at (YYYY-MM-DD HH:MM), daily_at (HH:MM) or every_minutes.")


def next_time(schedule: dict, after: float) -> Optional[float]:
    t = schedule.get("type")
    if t == "once":
        return schedule["at"] if schedule["at"] > after - 1 else None
    if t == "interval":
        return after + schedule["minutes"] * 60
    if t == "daily":
        h, m = (int(x) for x in schedule["time"].split(":"))
        base = datetime.fromtimestamp(after)
        cand = base.replace(hour=h, minute=m, second=0, microsecond=0)
        if cand.timestamp() <= after:
            cand += timedelta(days=1)
        while schedule.get("weekdays") and cand.weekday() >= 5:
            cand += timedelta(days=1)
        return cand.timestamp()
    return None


def describe_schedule(schedule: dict) -> str:
    t = schedule.get("type")
    if t == "once":
        return "once, " + datetime.fromtimestamp(schedule["at"]).strftime("%a %d %b %H:%M")
    if t == "interval":
        mins = schedule["minutes"]
        return f"every {mins // 60} h" if mins % 60 == 0 and mins >= 60 else f"every {mins} min"
    if t == "daily":
        return f"{'weekdays' if schedule.get('weekdays') else 'daily'} at {schedule['time']}"
    return "?"


# ---------------------------------------------------------------------------
# The store
# ---------------------------------------------------------------------------

def add(*, title: str, kind: str, when: dict, prompt: str = "", url: str = "",
        run_id: str = "", until_reported: bool = False, now: Optional[float] = None) -> Job:
    now = now or time.time()
    title = " ".join(str(title or "").split())[:TITLE_MAX]
    if not title:
        raise JobProblem("Give the job a short title.")
    if kind not in KINDS:
        raise JobProblem(f"kind must be one of: {', '.join(KINDS)}.")
    prompt = str(prompt or "").strip()[:PROMPT_MAX]
    if kind in ("remind", "check") and not prompt:
        raise JobProblem("Say what to remind him of, or what to check.")
    if kind == "watch_url" and not str(url).startswith(("http://", "https://")):
        raise JobProblem("watch_url needs a web address.")
    if kind == "watch_run" and not re.fullmatch(r"[A-Za-z0-9_-]{4,64}", str(run_id or "")):
        raise JobProblem("watch_run needs the run's id.")
    if kind == "watch_run":
        schedule = {"type": "interval", "minutes": 1}     # polled; ends when the run does
    else:
        schedule = parse_schedule(when, now)
    with _lock:
        if len(list_jobs()) >= MAX_JOBS:
            raise JobProblem(f"There are already {MAX_JOBS} jobs; remove some first.")
        job = Job(id=secrets.token_hex(4), title=title, kind=kind, schedule=schedule,
                  prompt=prompt, url=str(url or ""), run_id=str(run_id or ""),
                  until_reported=bool(until_reported or kind == "watch_run"),
                  created=now)
        job.next_run = (now + 60 if kind == "watch_run" else
                        schedule["at"] if schedule["type"] == "once" else next_time(schedule, now))
        _write(job)
    return job


def get(job_id: str) -> Optional[Job]:
    with closing(_db()) as conn:
        r = conn.execute("SELECT * FROM jobs WHERE id = ?", (str(job_id),)).fetchone()
    return _row(r) if r else None


def list_jobs() -> list[Job]:
    with closing(_db()) as conn:
        rows = conn.execute("SELECT * FROM jobs ORDER BY created").fetchall()
    return [_row(r) for r in rows]


def remove(job_id: str) -> bool:
    with closing(_db()) as conn, conn:
        return conn.execute("DELETE FROM jobs WHERE id = ?", (str(job_id),)).rowcount > 0


def set_enabled(job_id: str, enabled: bool, now: Optional[float] = None) -> Optional[Job]:
    job = get(job_id)
    if job is None:
        return None
    job.enabled = enabled
    if enabled and (job.next_run is None or job.next_run < (now or time.time())):
        job.next_run = next_time(job.schedule, now or time.time())
    _write(job)
    return job


def due(now: Optional[float] = None) -> list[Job]:
    now = now or time.time()
    return [j for j in list_jobs() if j.enabled and j.next_run is not None and j.next_run <= now]


def record(job: Job, result: str, *, reported: bool, now: Optional[float] = None,
           state: Optional[dict] = None) -> Job:
    """After a run: remember what happened and when it runs next."""
    now = now or time.time()
    job.last_run = now
    job.last_result = result or ""
    if state is not None:
        job.state = state
    if job.schedule["type"] == "once" or (job.until_reported and reported):
        job.enabled = False
        job.next_run = None
    else:
        job.next_run = next_time(job.schedule, now)
    _write(job)
    return job


def describe(jobs: list[Job]) -> str:
    if not jobs:
        return "No scheduled jobs."
    lines = []
    for j in jobs:
        status = "" if j.enabled else " (paused)" if j.next_run else " (done)"
        nxt = datetime.fromtimestamp(j.next_run).strftime("%a %H:%M") if j.next_run else "-"
        lines.append(f"{j.id}: {j.kind} '{j.title}', {describe_schedule(j.schedule)}, next {nxt}{status}")
    return "Scheduled jobs:\n" + "\n".join(lines)


