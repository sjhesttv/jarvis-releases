"""JARVIS's long-term memory, stored in SQLite (memory_db.py).

The layers:

  core      the facts marked for every conversation: rendered to MEMORY.md,
            which the persona `@`-imports. Bounded at MEMORY_INDEX_MAX.
  facts     one row per thing he was asked to remember (title, hook, body)
  notes     per-project notes, one stamped row each, appended in order
  journal   the handover one brain generation leaves the next
  episodes  short summaries of past conversations (memory_db.add_episode)

Found by `search`: keyword relevance from SQLite's FTS5 index plus, when the
local embedding model is up, meaning (ml_client.py), so a question can find
a memory that never used its words.

Each memory still has a Markdown form, the way a person reads it: `Doc` is
a handle that renders one on demand (`read_text()`), and the dashboard's
editor sends that form back (`replace_doc`). MEMORY.md is generated, but an
edit made to the file by hand is noticed and taken into the database before
it is next written, so nothing the user types there is lost.

Nothing the BRAIN can reach is destructive: facts are created or replaced
by their author, notes and journal entries only appended, and no tool
deletes anything. `replace_doc` / `delete_doc` / `write_index` serve the
dashboard's editor, which only a signed-in owner reaches.

Upgrading from the folder of Markdown files: `ensure_layout` imports
`memory/`, `projects/`, `journal/`, `conversations/` and MEMORY.md once,
then moves them aside into `legacy-markdown-<date>/`. Nothing is deleted.
"""

from __future__ import annotations

import hashlib
import os
import re
import tempfile
import time
from contextlib import closing
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

import data_paths
import memory_db

MEMORY_INDEX_MAX = 80          # core facts: what fits in every conversation
SLUG_MAX = 60

_APOSTROPHES = re.compile(r"['’‘\"“”]")
_NON_ALNUM = re.compile(r"[^a-z0-9]+")


# ---------------------------------------------------------------------------
# Values that land on a STRUCTURED line
# ---------------------------------------------------------------------------
#
# MEMORY.md is `@`-imported by `jarvis_home/CLAUDE.md`, so every line of it
# is system text in every future generation, and `recall` is deliberately not
# a tainting tool because "what actually protects it is that the WRITERS are
# gated" (server.TAINT_EXEMPT_TOOLS). `server.MEMORY_WRITERS` is one half of
# that gate — WHO may write. This is the other half: the SHAPE of what gets
# written. A title, a hook, a project name, a note, a journal reason: each is
# one line in every form it is ever rendered to, so each is flattened, and
# an index line is only written if the index's own parser reads it back as
# exactly the values handed in.
#
# `str.split()` with no argument splits on every character
# `str.splitlines()` knows about and then some, so the join below cannot
# leave a separator behind.
FIELD_MAX_CHARS = 240

# The index's own link syntax: a `]` or `(` in a TITLE closes the link and
# opens another. Removed rather than escaped: no name needs brackets.
_INDEX_STRUCTURAL = re.compile(r"[\[\]()]")


def one_line(value: str, limit: int = FIELD_MAX_CHARS) -> str:
    """`value` reduced to something that can only ever occupy one line."""
    flat = " ".join(str(value or "").split())
    return flat[: limit - 1] + "…" if len(flat) > limit else flat


class IndexFull(Exception):
    """The core list is at MEMORY_INDEX_MAX and this entry is a NEW one.

    Raised rather than silently dropped: `tool_remember` says out loud that
    nothing was written. What is loaded whole into every generation needs a
    bound the brain (the thing being talked to) cannot talk its way past.
    """


class UnwritableValue(Exception):
    """The line this value would produce does not read back as itself."""


def _normalize_title(text: str) -> str:
    """Full-length normalised title: "Tony's DB choice" and "tonys db
    choice" are the same memory; two long titles sharing their first
    SLUG_MAX characters are not."""
    stripped = _APOSTROPHES.sub("", (text or "").lower())
    return _NON_ALNUM.sub("-", stripped).strip("-")


def slugify(text: str) -> str:
    """A short name a person can recognise in a listing."""
    norm = _normalize_title(text)
    return (norm[:SLUG_MAX].rstrip("-") or "note")


# ---------------------------------------------------------------------------
# The index line format (MEMORY.md)
# ---------------------------------------------------------------------------
#
# Used with `fullmatch`, never `$` (which matches before a trailing newline;
# tests/test_anchored_patterns.py holds every pattern to that). `.` excludes
# only "\n" of the ten characters `str.splitlines()` splits on, so the class
# below spells out all ten; the test checks the list against splitlines.
_ON_ONE_LINE = r"[^\r\n\v\f\x1c\x1d\x1e\x85  ]"

_SEPARATORS = "\r\n\v\f\x1c\x1d\x1e\x85  "

_INDEX_LINE_RE = re.compile(
    rf"- \[(?P<title>[^\]{_SEPARATORS}]*)\]"
    rf"\((?P<slug>[^)/\\{_SEPARATORS}]*?)\.md\)"
    rf"(?:[ \t]*[—–-][ \t]*(?P<hook>{_ON_ONE_LINE}*))?")


def _index_line(title: str, slug: str, hook: str) -> str:
    """The one line this memory occupies, proven to read back as itself."""
    line = f"- [{title}]({slug}.md) — {hook}"
    m = _INDEX_LINE_RE.fullmatch(line)
    if (line.splitlines() != [line] or m is None
            or m.group("title") != title or m.group("slug") != slug
            or (m.group("hook") or "") != hook):
        raise UnwritableValue(
            "that memory cannot be written as a single index line")
    return line


INDEX_NAME = "MEMORY.md"
INDEX_HEADER = (
    "# What JARVIS remembers\n\n"
    "One line per memory. This file is loaded into every conversation, so it\n"
    "stays short; the detail is found with `recall`.\n\n"
)


def _index_path() -> Path:
    return data_paths.brain_home() / INDEX_NAME


# ---------------------------------------------------------------------------
# Documents: one memory, rendered the way a person reads it
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Doc:
    """A handle on one memory document. Rendered from the database on every
    read, so it is never stale."""
    kind: str
    slug: str

    @property
    def stem(self) -> str:
        return self.slug

    @property
    def name(self) -> str:
        return f"{self.slug}.md"

    def exists(self) -> bool:
        return render(self.kind, self.slug) is not None

    is_file = exists

    def read_text(self, *_a, **_k) -> str:
        text = render(self.kind, self.slug)
        if text is None:
            raise FileNotFoundError(f"{self.kind}/{self.slug}")
        return text

    def __str__(self) -> str:
        return f"{self.kind}/{self.slug}"


def _day(ts: float) -> str:
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d")


def _minute(ts: float) -> str:
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")


def _render_fact(row) -> str:
    return f"# {row['title']}\n\n_{_day(row['updated'])}_\n\n{row['body'].strip()}\n"


def _render_project(rows) -> str:
    out = [f"# {rows[-1]['project']}\n"]
    out += [f"_{_minute(r['ts'])}_ — {r['text']}" for r in rows]
    return "\n".join(out) + "\n"


def render(kind: str, slug: str) -> Optional[str]:
    """The Markdown form of one document, or None if there is no such one."""
    if not isinstance(slug, str) or not slug:
        return None
    if kind == "conversation":
        import conversation_log
        return conversation_log.render_day(slug)
    with closing(memory_db.connect()) as c:
        if kind == "memory":
            row = c.execute("SELECT * FROM facts WHERE slug = ?", (slug,)).fetchone()
            return _render_fact(row) if row else None
        if kind == "project":
            rows = c.execute("SELECT * FROM notes WHERE project_slug = ? ORDER BY ts, id",
                             (slug,)).fetchall()
            return _render_project(rows) if rows else None
        if kind == "journal":
            row = c.execute("SELECT text FROM journal WHERE slug = ?", (slug,)).fetchone()
            return row["text"] if row else None
        if kind == "episode":
            if not slug.isdigit():
                return None
            row = c.execute("SELECT * FROM episodes WHERE id = ?", (int(slug),)).fetchone()
            if not row:
                return None
            return (f"# Conversation, {_minute(row['start'])} – "
                    f"{datetime.fromtimestamp(row['end']).strftime('%H:%M')}\n\n{row['text']}\n")
    return None


def all_docs_text() -> str:
    """Every document, rendered: what a person would read if they read it
    all. (MEMORY.md included.) Used by tests and the readable export."""
    parts = [index_text()]
    for kind, slugs in (("memory", [e["slug"] for e in memory_entries()]),
                        ("project", [e["slug"] for e in project_entries()]),
                        ("journal", [e["slug"] for e in journal_entries_meta()])):
        for slug in slugs:
            parts.append(render(kind, slug) or "")
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Facts and the core index
# ---------------------------------------------------------------------------

def _fact_by_norm(c, norm: str):
    return c.execute("SELECT * FROM facts WHERE norm = ?", (norm,)).fetchone()


def _free_slug(c, base: str) -> str:
    slug, n = base, 2
    while c.execute("SELECT 1 FROM facts WHERE slug = ?", (slug,)).fetchone():
        slug = f"{base}-{n}"
        n += 1
    return slug


def _touch_index() -> None:
    """Re-render MEMORY.md (only if the brain's home exists: a read never
    creates it)."""
    if data_paths.brain_home().is_dir():
        _render_index()


def write_memory(title: str, body: str) -> Doc:
    """One fact. Re-writing the same title (case, punctuation and
    apostrophes aside) updates it in place; a different title that happens
    to slugify the same gets a slug of its own, so neither is lost.

    The TITLE is flattened to one line; the BODY is a paragraph and keeps
    the user's own shape.
    """
    ensure_layout()
    title = one_line(title)
    norm = _normalize_title(title)
    now = time.time()
    with closing(memory_db.connect()) as c, c:
        row = _fact_by_norm(c, norm) or _fact_by_norm(
            c, _normalize_title(_INDEX_STRUCTURAL.sub("", title)))
        if row:
            c.execute("UPDATE facts SET title = ?, body = ?, updated = ? WHERE id = ?",
                      (title.strip(), body.strip(), now, row["id"]))
            slug = row["slug"]
        else:
            slug = _free_slug(c, slugify(title))
            c.execute("INSERT INTO facts (slug, norm, title, body, hook, core, created, updated) "
                      "VALUES (?,?,?,?,?,0,?,?)", (slug, norm, title.strip(), body.strip(), "", now, now))
    _touch_index()
    return Doc("memory", slug)


def read_memory(name: str) -> Optional[str]:
    return render("memory", slugify(name))


def list_memories() -> list[str]:
    with closing(memory_db.connect()) as c:
        return sorted(r["slug"] for r in c.execute("SELECT slug FROM facts"))


def add_to_index(title: str, hook: str) -> None:
    """Mark a memory as core (in every conversation), with its one-line hook.
    A repeated title updates its hook in place.

    Raises `IndexFull` for a NEW core entry once there are MEMORY_INDEX_MAX:
    updating one that is already core does not grow the list and is always
    allowed. Raises `UnwritableValue` if the line would not read back.
    """
    ensure_layout()
    _absorb_index_edits()
    title = _INDEX_STRUCTURAL.sub("", one_line(title))
    hook = one_line(hook)
    slug = slugify(title)
    _index_line(title, slug, hook)            # proves the shape, or raises
    norm = _normalize_title(title)
    now = time.time()
    with closing(memory_db.connect()) as c, c:
        row = _fact_by_norm(c, norm)
        if row is None or not row["core"]:
            core = c.execute("SELECT count(*) FROM facts WHERE core = 1").fetchone()[0]
            if core >= MEMORY_INDEX_MAX:
                raise IndexFull(f"MEMORY.md already holds {MEMORY_INDEX_MAX} memories")
        if row:
            c.execute("UPDATE facts SET hook = ?, core = 1, core_order = COALESCE(core_order, ?) "
                      "WHERE id = ?", (hook, now, row["id"]))
        else:
            c.execute("INSERT INTO facts (slug, norm, title, body, hook, core, core_order, created, updated) "
                      "VALUES (?,?,?,?,?,1,?,?,?)",
                      (_free_slug(c, slug), norm, title, "", hook, now, now, now))
    _render_index()


def index_is_full() -> bool:
    return len(index_entries()) >= MEMORY_INDEX_MAX


def _core_rows(c):
    return c.execute("SELECT * FROM facts WHERE core = 1 ORDER BY core_order, id").fetchall()


def index_entries() -> list[dict]:
    """The core list: title / slug / hook, in the order they were added."""
    with closing(memory_db.connect()) as c:
        return [{"title": r["title"], "slug": r["slug"], "hook": r["hook"]} for r in _core_rows(c)]


def index_lines() -> list[str]:
    out = []
    for e in index_entries():
        try:
            out.append(_index_line(_INDEX_STRUCTURAL.sub("", e["title"]), e["slug"], e["hook"]))
        except UnwritableValue:
            continue
    return out


def index_text() -> str:
    """MEMORY.md as it is (or would be) written."""
    pre = memory_db.meta_get("index_preamble", INDEX_HEADER)
    post = memory_db.meta_get("index_postscript", "")
    body = "\n".join(index_lines())
    text = pre.rstrip("\n") + "\n\n" + (body + "\n" if body else "")
    if post.strip():
        text += "\n" + post.strip("\n") + "\n"
    return text


def refresh_index() -> None:
    """Write MEMORY.md again from the database (after an import)."""
    _render_index()


def _render_index() -> None:
    text = index_text()
    _atomic_write(_index_path(), text)
    memory_db.meta_set("index_hash", hashlib.sha256(text.encode()).hexdigest())


def _absorb_index_edits() -> None:
    """MEMORY.md is generated, but it is also a file the user may open in
    an editor. If it no longer matches what was last written, take it in
    (write_index) before writing over it."""
    try:
        text = _index_path().read_text()
    except OSError:
        return
    if hashlib.sha256(text.encode()).hexdigest() != memory_db.meta_get("index_hash"):
        try:
            write_index(text, render=False)
        except ValueError:
            pass


def write_index(text: str, render: bool = True) -> None:
    """The owner's edit of the whole index (dashboard, or the file itself).

    Lines of the index shape become the core list in that order (a new title
    becomes a fact of its own); a core memory missing from the text is no
    longer core, though it is still remembered. Everything else is kept as
    the owner's own prose: what comes before the first entry, and after.
    """
    if len(text.encode("utf-8")) > DOC_MAX_BYTES:
        raise ValueError("That is too long for the index.")
    if len(text.splitlines()) > MEMORY_INDEX_MAX * 3:
        raise ValueError(f"The index is read into every conversation; keep it "
                         f"under {MEMORY_INDEX_MAX} memories.")
    pre, post, entries = [], [], []
    for line in text.splitlines():
        m = _INDEX_LINE_RE.fullmatch(line.strip()) if line.startswith("- [") else None
        if m:
            entries.append(((m.group("title") or "").strip(), m.group("slug"),
                            one_line(m.group("hook") or "")))
        elif entries:
            post.append(line)
        else:
            pre.append(line)
    if len(entries) > MEMORY_INDEX_MAX:
        raise ValueError(f"The index holds at most {MEMORY_INDEX_MAX} memories.")
    now = time.time()
    with closing(memory_db.connect()) as c, c:
        c.execute("UPDATE facts SET core = 0, core_order = NULL")
        for i, (title, slug, hook) in enumerate(entries):
            title = one_line(title) or slug
            row = c.execute("SELECT id FROM facts WHERE slug = ?", (slug,)).fetchone() \
                or _fact_by_norm(c, _normalize_title(title))
            if row:
                c.execute("UPDATE facts SET hook = ?, core = 1, core_order = ? WHERE id = ?",
                          (hook, now + i / 1000, row["id"]))
            else:
                c.execute("INSERT INTO facts (slug, norm, title, body, hook, core, core_order, created, updated) "
                          "VALUES (?,?,?,?,?,1,?,?,?)",
                          (_free_slug(c, slugify(slug) if slug else slugify(title)),
                           _normalize_title(title), title, "", hook, now + i / 1000, now, now))
    memory_db.meta_set("index_preamble", "\n".join(pre).strip("\n") + "\n" if pre else INDEX_HEADER)
    memory_db.meta_set("index_postscript", "\n".join(post).strip("\n"))
    if render:
        _render_index()


def remove_from_index(slug: str) -> bool:
    with closing(memory_db.connect()) as c, c:
        changed = c.execute("UPDATE facts SET core = 0, core_order = NULL WHERE slug = ? AND core = 1",
                            (slug,)).rowcount
    if changed:
        _touch_index()
    return bool(changed)


# ---------------------------------------------------------------------------
# Project notes
# ---------------------------------------------------------------------------

def write_project_note(project: str, text: str) -> Doc:
    """What JARVIS knows about one project, appended in order (last week's
    finding is still true; a replace would discard it). Both values are one
    line: a note is one stamped line in its Markdown form."""
    ensure_layout()
    project = one_line(project)
    text = one_line(text)
    slug = slugify(project)
    with closing(memory_db.connect()) as c, c:
        c.execute("INSERT INTO notes (project, project_slug, ts, text) VALUES (?,?,?,?)",
                  (project, slug, time.time(), text))
    return Doc("project", slug)


def read_project_note(project: str) -> Optional[str]:
    return render("project", slugify(project))


# ---------------------------------------------------------------------------
# The journal (generation handovers)
# ---------------------------------------------------------------------------

_JOURNAL_STAMP_FMT = "%Y-%m-%d-%H%M%S-%f"   # fixed-width: lexicographic == chronological
_JOURNAL_NAME_RE = re.compile(r"(\d{4}-\d{2}-\d{2}-\d{6}-\d{6})-(.+)\.md")

# Reasons that mark an entry as a PLACEHOLDER: a tombstone proving a
# generation ended rather than vanished. Stored, but never carried into the
# next generation as "where you left off" — one silent shutdown must not
# erase a real handover written minutes earlier.
PLACEHOLDER_REASONS = frozenset({"rotation-silent", "shutdown-silent"})

# A collision gets "-2", "-3"… on its slug, so a reason may carry one.
_COLLISION_SUFFIX = re.compile(r"-\d+$")


def write_journal(text: str, reason: str = "shutdown",
                  untrusted_source: Optional[str] = None) -> Doc:
    """How one brain generation hands over to the next.

    `untrusted_source` is what the writing generation had read that JARVIS
    did not write ("a web page"), or None. It is recorded IN THE ENTRY,
    because the next generation after a restart reads this note back and
    the process that wrote it is gone.

    Ordered by an explicit fixed-width microsecond stamp, never by when a
    row was last edited. `reason` and `untrusted_source` both land on the
    entry's single `# ` header line, so both are flattened.
    """
    ensure_layout()
    reason = one_line(reason) or "shutdown"
    untrusted_source = one_line(untrusted_source) or None
    now = datetime.now()
    stamp = now.strftime(_JOURNAL_STAMP_FMT)
    base = slugify(reason)
    header_stamp = now.strftime("%Y-%m-%d %H:%M")
    provenance = (f"\n\nThe generation that wrote this had read "
                  f"{untrusted_source} that day." if untrusted_source else "")
    body = f"# {header_stamp} ({reason}){provenance}\n\n{text.strip()}\n"
    with closing(memory_db.connect()) as c, c:
        slug, tail, n = f"{stamp}-{base}", base, 2
        while c.execute("SELECT 1 FROM journal WHERE slug = ?", (slug,)).fetchone():
            tail = f"{base}-{n}"
            slug = f"{stamp}-{tail}"
            n += 1
        c.execute("INSERT INTO journal (slug, stamp, reason, untrusted_source, ts, text) "
                  "VALUES (?,?,?,?,?,?)", (slug, stamp, tail, untrusted_source, now.timestamp(), body))
    return Doc("journal", slug)


def journal_reason(doc) -> str:
    """The reason part of a journal entry's name ("" if it has none)."""
    m = _JOURNAL_NAME_RE.fullmatch(getattr(doc, "name", str(doc)))
    return m.group(2) if m else ""


def is_placeholder_reason(reason: str) -> bool:
    if reason in PLACEHOLDER_REASONS:
        return True
    return _COLLISION_SUFFIX.sub("", reason) in PLACEHOLDER_REASONS


def journal_entries() -> list[tuple[str, str, Doc]]:
    """Every entry as (stamp, reason, doc), oldest first, by its own stamp."""
    with closing(memory_db.connect()) as c:
        rows = c.execute("SELECT slug, stamp, reason FROM journal ORDER BY stamp, id").fetchall()
    return [(r["stamp"], r["reason"], Doc("journal", r["slug"])) for r in rows]


def latest_journal(limit: int = 1200, include_placeholders: bool = False) -> Optional[str]:
    """The most recent real handover, bounded — prepended to every new
    brain. Placeholders are skipped unless asked for."""
    entries = journal_entries()
    if not include_placeholders:
        entries = [e for e in entries if not is_placeholder_reason(e[1])]
    if not entries:
        return None
    text = render("journal", entries[-1][2].slug) or ""
    return text if len(text) <= limit else text[: limit - 1] + "…"


# ---------------------------------------------------------------------------
# Search: keyword (FTS5) + meaning (embeddings)
# ---------------------------------------------------------------------------

EXCERPT_CHARS = 240

# Words too common to mean anything on their own: a query made only of
# these must find nothing, not everything.
_STOP_WORDS = frozenset({
    "a", "an", "and", "are", "as", "at", "be", "but", "by", "did", "do",
    "does", "for", "from", "had", "has", "have", "he", "her", "his", "i",
    "in", "is", "it", "its", "of", "on", "or", "our", "she", "so", "that",
    "the", "their", "them", "there", "they", "this", "to", "was", "we",
    "were", "what", "when", "which", "who", "with", "you", "your",
})

# A meaning match counts when the embedding model thinks it is at least
# this close (cosine, normalised vectors). Below it is noise.
MEANING_MIN = 0.45
MEANING_WEIGHT = 20


def _score(query_words: set[str], title: str, body: str) -> int:
    """Title matches count for more: a memory named for the thing you asked
    about is almost always the one you meant."""
    title_l, body_l = title.lower(), body.lower()
    score = 0
    for w in query_words:
        if w in title_l:
            score += 10
        score += body_l.count(w)
    return score


_URL_RE = re.compile(r"https?://\S+")
_URL_LONG_MIN = 30      # shorter than this reads fine spoken as-is
_TABLE_ROW = re.compile(r"\|.*\|")


def _speakable(text: str) -> str:
    """Polish a line for speech: a table row's pipes and a long URL read
    badly aloud; ordinary prose is left alone."""
    def _tame_url(m: re.Match) -> str:
        url = m.group(0)
        if len(url) < _URL_LONG_MIN:
            return url
        domain = re.sub(r"^https?://", "", url).split("/")[0]
        domain = re.sub(r"^www\.", "", domain)
        return domain or "a link"

    text = _URL_RE.sub(_tame_url, text)
    if _TABLE_ROW.fullmatch(text.strip()):
        cells = [c.strip() for c in text.strip().strip("|").split("|")]
        text = ", ".join(c for c in cells if c)
    return text


def _cap(text: str) -> str:
    text = _speakable(" ".join(text.split()))
    return text if len(text) <= EXCERPT_CHARS else text[: EXCERPT_CHARS - 1] + "…"


_LEADING_STAMP = re.compile(r"^_[^_\n]+_\s*[—-]\s*")


def _clean_line(line: str) -> Optional[str]:
    """A line stripped to what could be spoken, or None if it is furniture
    (a heading marker, a note's leading stamp, a bare date)."""
    candidate = line.strip().lstrip("#").strip()
    candidate = _LEADING_STAMP.sub("", candidate)
    if not candidate or not any(c.isalpha() for c in candidate):
        return None
    return candidate


def _excerpt(body: str, query_words: set[str]) -> str:
    """The line that matched, so the brain sees why this was returned:
    a substantive matching line; else a body line that only echoes the
    query; else (a title-only hit) the first substantive body line."""
    echo_only = None
    for line in body.splitlines():
        is_heading = line.strip().startswith("#")
        candidate = _clean_line(line)
        if candidate is None:
            continue
        low = candidate.lower()
        if not any(w in low for w in query_words):
            continue
        if set(re.split(r"[^a-z0-9]+", low)) - {""} <= query_words:
            if not is_heading:
                echo_only = echo_only or candidate
            continue
        return _cap(candidate)

    if echo_only is not None:
        return _cap(echo_only)

    for line in body.splitlines():
        if line.strip().startswith("#"):
            continue
        candidate = _clean_line(line)
        if candidate:
            return _cap(candidate)

    return _cap(body)


def _query_words(query: str) -> set[str]:
    return {w for w in re.split(r"[^a-z0-9]+", (query or "").lower())
            if len(w) > 1 and w not in _STOP_WORDS}


_KIND_OF = {"facts": "memory", "notes": "project", "journal": "journal", "episodes": "episode"}


def _ref_to_doc(c, ref: str) -> Optional[tuple[str, str]]:
    table, _, rid = ref.partition(":")
    if not rid.isdigit():
        return None
    rid = int(rid)
    if table == "facts":
        r = c.execute("SELECT slug FROM facts WHERE id = ?", (rid,)).fetchone()
        return ("memory", r["slug"]) if r else None
    if table == "notes":
        r = c.execute("SELECT project_slug FROM notes WHERE id = ?", (rid,)).fetchone()
        return ("project", r["project_slug"]) if r else None
    if table == "journal":
        r = c.execute("SELECT slug FROM journal WHERE id = ?", (rid,)).fetchone()
        return ("journal", r["slug"]) if r else None
    if table == "episodes":
        return ("episode", str(rid))
    return None


def search(query: str, limit: int = 5) -> list[dict]:
    """Best matches across facts, project notes, the journal and past
    conversation summaries.

    Candidates come from the FTS5 index (any query word, as a prefix) and,
    when the local model is up, from embeddings (meaning). Keyword hits are
    scored as they always were (a word in the title is worth ten in the
    body); a close meaning match adds up to MEANING_WEIGHT.
    """
    words = _query_words(query)
    meaning: dict[tuple[str, str], float] = {}
    try:
        import ml_client
        vec = ml_client.embed_query(query) if (query or "").strip() else None
    except Exception:
        vec = None
    candidates: set[tuple[str, str]] = set()
    with closing(memory_db.connect()) as c:
        if words:
            for table in ("facts", "notes", "journal", "episodes"):
                for rowid, _rank in memory_db.keyword(table, words, limit=50):
                    found = _ref_to_doc(c, f"{table}:{rowid}")
                    if found:
                        candidates.add(found)
        if vec is not None:
            for ref, cos in memory_db.nearest(vec, vec_model(), limit=12):
                if cos < MEANING_MIN:
                    continue
                found = _ref_to_doc(c, ref)
                if found:
                    candidates.add(found)
                    meaning[found] = max(meaning.get(found, 0.0), cos)
    if not words and not meaning:
        return []
    hits = []
    for kind, slug in candidates:
        body = render(kind, slug)
        if body is None:
            continue
        score = _score(words, slug, body) if words else 0
        if (kind, slug) in meaning:
            score += round(meaning[(kind, slug)] * MEANING_WEIGHT)
        if score <= 0:
            continue
        excerpt = _excerpt(body, words) if words else _excerpt_first(body)
        hits.append({"kind": kind, "name": slug, "path": f"{kind}/{slug}",
                     "excerpt": excerpt, "score": score,
                     "meaning": round(meaning.get((kind, slug), 0.0), 3)})
        if kind == "episode":
            hits[-1]["day"] = body[len("# Conversation, "):][:10]
    hits.sort(key=lambda h: (-h["score"], h["name"]))
    return hits[:limit]


def _excerpt_first(body: str) -> str:
    for line in body.splitlines():
        if line.strip().startswith("#"):
            continue
        candidate = _clean_line(line)
        if candidate:
            return _cap(candidate)
    return _cap(body)


def vec_model() -> str:
    try:
        import ml_client
        return ml_client.EMBED_MODEL
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Listings — what the dashboard's Memory view reads. Never create anything.
# ---------------------------------------------------------------------------

def memory_entries() -> list[dict]:
    with closing(memory_db.connect()) as c:
        rows = c.execute("SELECT slug, title, updated, core FROM facts ORDER BY updated DESC").fetchall()
    return [{"slug": r["slug"], "title": r["title"], "modified": r["updated"],
             "core": bool(r["core"])} for r in rows]


def project_entries() -> list[dict]:
    with closing(memory_db.connect()) as c:
        rows = c.execute("SELECT project_slug, max(ts) AS modified, count(*) AS n, "
                         "(SELECT project FROM notes n2 WHERE n2.project_slug = notes.project_slug "
                         " ORDER BY ts DESC, id DESC LIMIT 1) AS title "
                         "FROM notes GROUP BY project_slug ORDER BY modified DESC").fetchall()
    return [{"slug": r["project_slug"], "title": r["title"], "modified": r["modified"],
             "count": r["n"]} for r in rows]


def episode_entries(limit: int = 200) -> list[dict]:
    return [{"slug": str(e["id"]), "start": e["start"], "end": e["end"], "day": e["day"],
             "summary": one_line(e["text"], 160)} for e in memory_db.episodes(limit)]


def _stamp_to_epoch(stamp: str) -> float:
    try:
        return datetime.strptime(stamp, _JOURNAL_STAMP_FMT).timestamp()
    except ValueError:
        return 0.0


def journal_entries_meta() -> list[dict]:
    """slug / when / reason for each journal entry, newest first."""
    return [{"slug": doc.slug, "when": _stamp_to_epoch(stamp), "reason": reason}
            for stamp, reason, doc in reversed(journal_entries())]


def latest_journal_slug() -> Optional[str]:
    """The entry a new brain will actually carry (placeholders skipped)."""
    entries = [e for e in journal_entries() if not is_placeholder_reason(e[1])]
    return entries[-1][2].slug if entries else None


# Slugs arrive from URLs. They are looked up as values in the database and
# never become paths, but they are still held to the shape a slug has.
_SLUG_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,120}")

DOC_KINDS = ("memory", "project", "journal", "conversation", "episode")


def doc_path(kind: str, slug: str) -> Optional[Doc]:
    """The document for one (kind, slug), or None if there isn't one —
    including any slug that is not the shape of a slug."""
    if kind not in DOC_KINDS or not isinstance(slug, str) or not _SLUG_RE.fullmatch(slug):
        return None
    doc = Doc(kind, slug)
    return doc if doc.exists() else None


# ---------------------------------------------------------------------------
# The owner's editor (dashboard Memory tab). Never reachable from a tool.
# ---------------------------------------------------------------------------

DOC_MAX_BYTES = 256 * 1024
EDITABLE_KINDS = ("memory", "project", "journal", "conversation", "episode")

_NOTE_LINE_RE = re.compile(rf"_(\d{{4}}-\d{{2}}-\d{{2}} \d{{2}}:\d{{2}})_[ \t]*[—–-][ \t]*({_ON_ONE_LINE}*)")
_DATE_LINE_RE = re.compile(r"_\d{4}-\d{2}-\d{2}_")


def _atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=f".{path.name}-")
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.replace(tmp, path)


def parse_fact(text: str, fallback_title: str = "") -> tuple[str, str]:
    """(title, body) from a fact's Markdown form: the first `# ` line is the
    title, a bare `_date_` line after it is furniture, the rest is body."""
    title, body, seen_title = fallback_title, [], False
    for line in text.splitlines():
        if not seen_title and line.startswith("# "):
            title, seen_title = line[2:].strip(), True
            continue
        if seen_title and not body and (not line.strip() or _DATE_LINE_RE.fullmatch(line.strip())):
            continue
        body.append(line)
    return one_line(title) or fallback_title, "\n".join(body).strip()


def parse_project(text: str) -> tuple[str, list[tuple[float, str]]]:
    """(project name, [(ts, note)]) from a project's Markdown form. A line
    without a stamp joins as a note of its own, stamped now."""
    name, notes = "", []
    now = time.time()
    for line in text.splitlines():
        s = line.strip()
        if not s:
            continue
        if s.startswith("# ") and not name:
            name = one_line(s[2:])
            continue
        m = _NOTE_LINE_RE.fullmatch(s)
        if m:
            try:
                ts = datetime.strptime(m.group(1), "%Y-%m-%d %H:%M").timestamp()
            except ValueError:
                ts = now
            if m.group(2).strip():
                notes.append((ts, one_line(m.group(2))))
        else:
            notes.append((now, one_line(s)))
    return name, notes


def replace_doc(kind: str, slug: str, text: str) -> Doc:
    """The owner's edit of one document, in its Markdown form."""
    if kind not in EDITABLE_KINDS:
        raise ValueError("That cannot be edited.")
    if len(text.encode("utf-8")) > DOC_MAX_BYTES:
        raise ValueError("That is too long.")
    if doc_path(kind, slug) is None:
        raise FileNotFoundError(slug)
    now = time.time()
    if kind == "conversation":
        import conversation_log
        conversation_log.replace_day(slug, text)
        return Doc(kind, slug)
    with closing(memory_db.connect()) as c, c:
        if kind == "memory":
            row = c.execute("SELECT * FROM facts WHERE slug = ?", (slug,)).fetchone()
            title, body = parse_fact(text, row["title"])
            c.execute("UPDATE facts SET title = ?, norm = ?, body = ?, updated = ? WHERE id = ?",
                      (title, _normalize_title(title), body, now, row["id"]))
        elif kind == "project":
            name, notes = parse_project(text)
            old = c.execute("SELECT project FROM notes WHERE project_slug = ? LIMIT 1", (slug,)).fetchone()
            name = name or old["project"]
            c.execute("DELETE FROM notes WHERE project_slug = ?", (slug,))
            for ts, note in notes:
                c.execute("INSERT INTO notes (project, project_slug, ts, text) VALUES (?,?,?,?)",
                          (name, slug, ts, note))
        elif kind == "journal":
            c.execute("UPDATE journal SET text = ? WHERE slug = ?", (text.rstrip("\n") + "\n", slug))
        elif kind == "episode":
            body = "\n".join(ln for ln in text.splitlines() if not ln.startswith("# ")).strip()
            c.execute("UPDATE episodes SET text = ? WHERE id = ?", (body, int(slug)))
    _touch_index()
    return Doc(kind, slug)


def delete_doc(kind: str, slug: str) -> bool:
    if kind not in EDITABLE_KINDS:
        raise ValueError("That cannot be deleted.")
    if doc_path(kind, slug) is None:
        return False
    if kind == "conversation":
        import conversation_log
        return conversation_log.delete_day(slug)
    with closing(memory_db.connect()) as c, c:
        if kind == "memory":
            row = c.execute("SELECT id FROM facts WHERE slug = ?", (slug,)).fetchone()
            c.execute("DELETE FROM facts WHERE id = ?", (row["id"],))
            c.execute("DELETE FROM embeddings WHERE ref = ?", (f"facts:{row['id']}",))
        elif kind == "project":
            c.execute("DELETE FROM embeddings WHERE ref IN (SELECT 'notes:' || id FROM notes "
                      "WHERE project_slug = ?)", (slug,))
            c.execute("DELETE FROM notes WHERE project_slug = ?", (slug,))
        elif kind == "journal":
            c.execute("DELETE FROM journal WHERE slug = ?", (slug,))
        elif kind == "episode":
            c.execute("DELETE FROM episodes WHERE id = ?", (int(slug),))
            c.execute("DELETE FROM embeddings WHERE ref = ?", (f"episodes:{slug}",))
    _touch_index()
    return True


# ---------------------------------------------------------------------------
# Layout, and the one-time move from Markdown folders
# ---------------------------------------------------------------------------

_LEGACY_FOLDERS = ("memory", "projects", "journal", "conversations")


def ensure_layout() -> Path:
    """The brain's home, the database, and MEMORY.md (seeded so the
    persona's `@MEMORY.md` import is never left dangling). Imports any
    Markdown memory folders left from an earlier version, once."""
    home = data_paths.ensure_brain_home()
    if memory_db.meta_get("legacy_imported") != "1":
        import_legacy_folders(home)
        memory_db.meta_set("legacy_imported", "1")
    if not _index_path().exists():
        _render_index()
    return home


def import_markdown(folder: str, name: str, text: str, replace: bool = False) -> str:
    """Take one Markdown document from the old folder layout (or an old
    export) into the database. Returns "added", "replaced" or "kept":
    without `replace`, what is already here wins."""
    stem = name[:-3] if name.endswith(".md") else name
    now = time.time()
    if folder == "conversations":
        import conversation_log
        return conversation_log.import_day(stem, text, replace)
    with closing(memory_db.connect()) as c, c:
        if folder == "memory":
            title, body = parse_fact(text, stem)
            norm = _normalize_title(title)
            row = _fact_by_norm(c, norm) or c.execute(
                "SELECT * FROM facts WHERE slug = ?", (stem,)).fetchone()
            if row and (row["body"] and not replace):
                return "kept"
            if row:
                c.execute("UPDATE facts SET title = ?, body = ?, updated = ? WHERE id = ?",
                          (title, body, now, row["id"]))
                return "replaced" if row["body"] else "added"
            slug = _free_slug(c, slugify(stem) if _SLUG_RE.fullmatch(stem) else slugify(title))
            c.execute("INSERT INTO facts (slug, norm, title, body, hook, core, created, updated) "
                      "VALUES (?,?,?,?,?,0,?,?)", (slug, norm, title, body, "", now, now))
            return "added"
        if folder == "projects":
            name_, notes = parse_project(text)
            slug = slugify(stem)
            have = {(round(r["ts"] / 60), r["text"]) for r in c.execute(
                "SELECT ts, text FROM notes WHERE project_slug = ?", (slug,))}
            if have and replace:
                c.execute("DELETE FROM notes WHERE project_slug = ?", (slug,))
                have = set()
            added = 0
            for ts, note in notes:
                if (round(ts / 60), note) in have:
                    continue
                c.execute("INSERT INTO notes (project, project_slug, ts, text) VALUES (?,?,?,?)",
                          (name_ or stem, slug, ts, note))
                added += 1
            return "added" if added else "kept"
        if folder == "journal":
            m = _JOURNAL_NAME_RE.fullmatch(f"{stem}.md")
            if not m:
                return "kept"
            stamp, reason = m.groups()
            row = c.execute("SELECT id FROM journal WHERE slug = ?", (stem,)).fetchone()
            if row and not replace:
                return "kept"
            if row:
                c.execute("UPDATE journal SET text = ? WHERE id = ?", (text, row["id"]))
                return "replaced"
            src = re.search(r"had read (.+?) that day\.", text.split("\n\n", 2)[1]
                            if text.count("\n\n") >= 2 else "")
            c.execute("INSERT INTO journal (slug, stamp, reason, untrusted_source, ts, text) "
                      "VALUES (?,?,?,?,?,?)", (stem, stamp, reason, src.group(1) if src else None,
                                               _stamp_to_epoch(stamp), text))
            return "added"
    return "kept"


def import_index(text: str, replace: bool = False) -> None:
    """An old MEMORY.md: its entries become core (merged with the current
    core list unless `replace`), its prose is kept."""
    if replace:
        write_index(text)
        return
    have = {e["slug"] for e in index_entries()}
    merged = index_text().rstrip("\n").splitlines()
    extra = [ln for ln in text.splitlines()
             if (m := _INDEX_LINE_RE.fullmatch(ln.strip())) and m.group("slug") not in have]
    if extra:
        write_index("\n".join(merged + extra) + "\n")


def import_legacy_folders(home: Path) -> int:
    """Pull the old Markdown folders into the database, then move them aside
    (never deleted) into `legacy-markdown-<date>/`."""
    moved = 0
    found = [f for f in _LEGACY_FOLDERS if (home / f).is_dir() and any((home / f).glob("*.md"))]
    index = home / INDEX_NAME
    legacy_index = index.is_file() and memory_db.meta_get("index_hash") == ""
    if not found and not legacy_index:
        return 0
    for folder in found:
        for path in sorted((home / folder).glob("*.md")):
            if path.is_symlink() or not path.is_file():
                continue
            try:
                import_markdown(folder, path.name, path.read_text(encoding="utf-8", errors="replace"))
                moved += 1
            except Exception:
                continue
    if legacy_index:
        try:
            write_index(index.read_text(encoding="utf-8", errors="replace"), render=False)
        except ValueError:
            pass
    aside = home / f"legacy-markdown-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    aside.mkdir(exist_ok=True)
    for folder in found:
        os.replace(home / folder, aside / folder)
    if legacy_index:
        import shutil
        shutil.copy2(index, aside / INDEX_NAME)
    _render_index()
    return moved
