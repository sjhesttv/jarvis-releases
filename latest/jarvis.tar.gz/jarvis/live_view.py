"""Live, interactive web pages in JARVIS's windows.

A real Chromium page runs on the SERVER. Its screen is streamed to the
window as JPEG frames (Chromium's own screencast, which sends a frame only
when something changes), and the user's clicks, scrolling and typing are sent
back and replayed on it. So a window shows a live page — a dev server JARVIS
started on the droplet, a dashboard, any site — and the user can use it, with
none of it running inside the signed-in JARVIS page.

One headless Chromium is shared; every live window is its own browser
context (its own cookies and storage), closed with the window. At most
`MAX_SESSIONS` at once, and one nobody has watched for `IDLE_CLOSE_SEC` is
closed.

Navigation is held to http(s): a page that tries to send the view to
`file://` or anything else is turned back to about:blank.

The wire protocol (server.py `/ws/live/{id}`):
    server → page  {"t":"frame","data":<base64 jpeg>,"w":…,"h":…}
                   {"t":"url","url":…,"title":…}
                   {"t":"ended"}
    page → server  {"t":"down"|"up"|"move","x":0..1,"y":0..1,"button":…}
                   {"t":"wheel","dx":…,"dy":…}
                   {"t":"key","key":"Enter"} · {"t":"text","text":"a"}
                   {"t":"resize","w":…,"h":…} · {"t":"back"|"forward"|"reload"}
"""

from __future__ import annotations

import asyncio
import logging
import secrets
import time
from dataclasses import dataclass, field
from typing import Optional

log = logging.getLogger("jarvis.live")

MAX_SESSIONS = 3
IDLE_CLOSE_SEC = 10 * 60
DEFAULT_VIEWPORT = (1280, 800)
MIN_VIEWPORT = (360, 240)
MAX_VIEWPORT = (1920, 1200)
JPEG_QUALITY = 70
LOAD_TIMEOUT_MS = 20_000
USER_AGENT = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
              "Chrome/131.0 Safari/537.36 JARVIS")

# The keys a user can press that are not text. Anything else non-printable
# is dropped rather than passed through.
NAMED_KEYS = frozenset({
    "Enter", "Tab", "Backspace", "Delete", "Escape", "ArrowUp", "ArrowDown",
    "ArrowLeft", "ArrowRight", "Home", "End", "PageUp", "PageDown", "Space",
})
MODIFIED_KEYS = frozenset("acvxzy")       # Ctrl/Cmd + these: select all, copy…


class LiveProblem(Exception):
    """Said to the brain or the page as is."""


def clean_input(ev: dict) -> Optional[dict]:
    """The one event in `ev` the page may send, normalised, or None."""
    if not isinstance(ev, dict):
        return None
    t = ev.get("t")

    def frac(v) -> Optional[float]:
        try:
            f = float(v)
        except (TypeError, ValueError):
            return None
        return min(1.0, max(0.0, f))

    if t in ("down", "up", "move"):
        x, y = frac(ev.get("x")), frac(ev.get("y"))
        if x is None or y is None:
            return None
        button = ev.get("button") if ev.get("button") in ("left", "right", "middle") else "left"
        return {"t": t, "x": x, "y": y, "button": button}
    if t == "wheel":
        try:
            dx = max(-2000.0, min(2000.0, float(ev.get("dx") or 0)))
            dy = max(-2000.0, min(2000.0, float(ev.get("dy") or 0)))
        except (TypeError, ValueError):
            return None
        return {"t": t, "dx": dx, "dy": dy}
    if t == "key":
        key = str(ev.get("key") or "")
        mod = str(ev.get("mod") or "")
        if key in NAMED_KEYS:
            return {"t": t, "key": key}
        if mod in ("Control", "Meta") and key.lower() in MODIFIED_KEYS:
            return {"t": t, "key": f"ControlOrMeta+{key.lower()}"}
        return None
    if t == "text":
        text = str(ev.get("text") or "")
        if 0 < len(text) <= 256 and text.isprintable():
            return {"t": t, "text": text}
        return None
    if t == "resize":
        try:
            w = int(ev.get("w")); h = int(ev.get("h"))
        except (TypeError, ValueError):
            return None
        w = max(MIN_VIEWPORT[0], min(MAX_VIEWPORT[0], w))
        h = max(MIN_VIEWPORT[1], min(MAX_VIEWPORT[1], h))
        return {"t": t, "w": w, "h": h}
    if t in ("back", "forward", "reload"):
        return {"t": t}
    return None


@dataclass
class LiveSession:
    id: str
    url: str
    context: object = None
    page: object = None
    cdp: object = None
    viewport: tuple[int, int] = DEFAULT_VIEWPORT
    last_frame: Optional[dict] = None
    title: str = ""
    watchers: set = field(default_factory=set)
    last_watched: float = field(default_factory=time.time)
    closed: bool = False

    # -- broadcasting --------------------------------------------------------
    def _broadcast(self, msg: dict) -> None:
        for q in list(self.watchers):
            if q.full():
                try:
                    q.get_nowait()             # drop the stalest; keep it live
                except asyncio.QueueEmpty:
                    pass
            try:
                q.put_nowait(msg)
            except asyncio.QueueFull:
                pass

    def watch(self) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=4)
        self.watchers.add(q)
        self.last_watched = time.time()
        if self.last_frame:
            q.put_nowait(self.last_frame)
        q.put_nowait({"t": "url", "url": self.current_url(), "title": self.title})
        return q

    def unwatch(self, q: asyncio.Queue) -> None:
        self.watchers.discard(q)
        self.last_watched = time.time()

    def current_url(self) -> str:
        try:
            return str(self.page.url)
        except Exception:
            return self.url

    # -- the page's side --------------------------------------------------------
    def _on_frame(self, params: dict) -> None:
        data = params.get("data")
        meta = params.get("metadata") or {}
        sid = params.get("sessionId")
        if sid is not None and self.cdp is not None:
            asyncio.ensure_future(self._ack(sid))
        if not data:
            return
        self.last_frame = {"t": "frame", "data": data,
                           "w": int(meta.get("deviceWidth") or self.viewport[0]),
                           "h": int(meta.get("deviceHeight") or self.viewport[1])}
        self._broadcast(self.last_frame)

    async def _ack(self, sid) -> None:
        try:
            await self.cdp.send("Page.screencastFrameAck", {"sessionId": sid})
        except Exception:
            pass

    async def _on_navigated(self, frame) -> None:
        if self.closed or frame != self.page.main_frame:
            return
        url = str(frame.url or "")
        if url and not url.startswith(("http://", "https://", "about:blank")):
            log.warning("live %s: refused navigation to %s", self.id, url[:80])
            try:
                await self.page.goto("about:blank")
            except Exception:
                pass
            return
        try:
            self.title = (await self.page.title())[:200]
        except Exception:
            pass
        self._broadcast({"t": "url", "url": url, "title": self.title})

    async def start_screencast(self) -> None:
        self.cdp = await self.context.new_cdp_session(self.page)
        self.cdp.on("Page.screencastFrame", self._on_frame)
        await self.cdp.send("Page.startScreencast", {
            "format": "jpeg", "quality": JPEG_QUALITY,
            "maxWidth": self.viewport[0], "maxHeight": self.viewport[1],
            "everyNthFrame": 1})

    # -- input --------------------------------------------------------------------
    async def act(self, ev: dict) -> None:
        if self.closed:
            return
        self.last_watched = time.time()
        page = self.page
        w, h = self.viewport
        t = ev["t"]
        if t in ("down", "up", "move"):
            x, y = ev["x"] * w, ev["y"] * h
            await page.mouse.move(x, y)
            if t == "down":
                await page.mouse.down(button=ev["button"])
            elif t == "up":
                await page.mouse.up(button=ev["button"])
        elif t == "wheel":
            await page.mouse.wheel(ev["dx"], ev["dy"])
        elif t == "key":
            await page.keyboard.press(" " if ev["key"] == "Space" else ev["key"])
        elif t == "text":
            await page.keyboard.insert_text(ev["text"])
        elif t == "resize":
            if (ev["w"], ev["h"]) != self.viewport:
                self.viewport = (ev["w"], ev["h"])
                await page.set_viewport_size({"width": ev["w"], "height": ev["h"]})
                if self.cdp is not None:
                    await self.cdp.send("Page.stopScreencast")
                    await self.cdp.send("Page.startScreencast", {
                        "format": "jpeg", "quality": JPEG_QUALITY,
                        "maxWidth": ev["w"], "maxHeight": ev["h"], "everyNthFrame": 1})
        elif t == "back":
            await page.go_back(timeout=LOAD_TIMEOUT_MS)
        elif t == "forward":
            await page.go_forward(timeout=LOAD_TIMEOUT_MS)
        elif t == "reload":
            await page.reload(timeout=LOAD_TIMEOUT_MS)

    async def screenshot(self) -> bytes:
        return await self.page.screenshot(type="png", full_page=False)

    async def close(self) -> None:
        if self.closed:
            return
        self.closed = True
        self._broadcast({"t": "ended"})
        try:
            await self.context.close()
        except Exception:
            pass


class LiveManager:
    def __init__(self) -> None:
        self._pw = None
        self._browser = None
        self._lock = asyncio.Lock()
        self.sessions: dict[str, LiveSession] = {}
        self._reaper: Optional[asyncio.Task] = None

    async def _ensure_browser(self):
        if self._browser is not None and self._browser.is_connected():
            return self._browser
        from playwright.async_api import async_playwright
        if self._pw is None:
            self._pw = await async_playwright().start()
        self._browser = await self._pw.chromium.launch(headless=True)
        return self._browser

    async def open(self, url: str) -> LiveSession:
        async with self._lock:
            while len(self.sessions) >= MAX_SESSIONS:
                oldest = min(self.sessions.values(), key=lambda s: s.last_watched)
                await self.close(oldest.id)
            browser = await self._ensure_browser()
            context = await browser.new_context(
                user_agent=USER_AGENT,
                viewport={"width": DEFAULT_VIEWPORT[0], "height": DEFAULT_VIEWPORT[1]})
            page = await context.new_page()
            session = LiveSession(id=secrets.token_hex(8), url=url, context=context, page=page)
            page.on("framenavigated", lambda frame: asyncio.ensure_future(session._on_navigated(frame)))
            # Every new tab the page opens comes back into this one view.
            context.on("page", lambda p: asyncio.ensure_future(self._fold_popup(session, p)))
            try:
                await page.goto(url, wait_until="domcontentloaded", timeout=LOAD_TIMEOUT_MS)
            except Exception as e:
                await context.close()
                raise LiveProblem(f"that page wouldn't load ({type(e).__name__})") from e
            await session.start_screencast()
            try:
                session.title = (await page.title())[:200]
            except Exception:
                pass
            self.sessions[session.id] = session
            if self._reaper is None or self._reaper.done():
                self._reaper = asyncio.ensure_future(self._reap())
            return session

    async def _fold_popup(self, session: LiveSession, popup) -> None:
        if popup is session.page:
            return
        try:
            target = popup.url
            await popup.close()
            if target and target.startswith(("http://", "https://")):
                await session.page.goto(target, timeout=LOAD_TIMEOUT_MS)
        except Exception:
            pass

    def get(self, sid: str) -> Optional[LiveSession]:
        s = self.sessions.get(sid)
        return s if s is not None and not s.closed else None

    async def close(self, sid: str) -> bool:
        s = self.sessions.pop(sid, None)
        if s is None:
            return False
        await s.close()
        return True

    async def close_all(self) -> None:
        for sid in list(self.sessions):
            await self.close(sid)
        if self._browser is not None:
            try:
                await self._browser.close()
            except Exception:
                pass
            self._browser = None
        if self._pw is not None:
            try:
                await self._pw.stop()
            except Exception:
                pass
            self._pw = None

    async def _reap(self) -> None:
        while self.sessions:
            await asyncio.sleep(30)
            now = time.time()
            for s in list(self.sessions.values()):
                if not s.watchers and now - s.last_watched > IDLE_CLOSE_SEC:
                    log.info("live %s: closed after %ds unwatched", s.id, IDLE_CLOSE_SEC)
                    await self.close(s.id)
