"""The owner's password and browser sessions (issue #1).

JARVIS is single-user. When a password is configured — always, in cloud mode;
optionally on a Mac — every request must prove it is the owner: a browser by
a session cookie it got from `/login`, a local client (the brain's MCP child,
a script) by the tool token. `web_auth.OriginGuard` enforces it; this module
holds the primitives.

**Password.** Stored as one line, `scrypt:<n>:<r>:<p>:<salt>:<hash>` (base64),
in `<data>/auth/password` at mode 0600 inside a 0700 directory. stdlib
`hashlib.scrypt` only: no new dependency. Set it with

    python3 auth_store.py set-password

which the cloud setup wizard (`deploy/jarvis-setup`) calls for you.

**Sessions.** Stateless signed cookies: `v1.<expires>.<nonce>.<mac>`, the MAC
an HMAC-SHA256 under a per-install secret (`<data>/auth/session-secret`) over
the expiry, the nonce and a fingerprint of the password hash. So:

* a server restart keeps you logged in;
* changing the password logs out every browser at once (the fingerprint
  changes), and `python3 auth_store.py logout-everywhere` does the same by
  rotating the secret.

**Brute force.** scrypt makes each guess cost ~50 ms of CPU, and
`LoginLimiter` refuses an address after `PER_ADDRESS_FAILURES` misses in
`WINDOW_SECONDS`, and everyone after `GLOBAL_FAILURES` (a distributed guess
cannot outrun it; the price is that the owner may have to wait out the
window too, which is the right trade for a box that can run code).
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import logging
import os
import secrets
import stat
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Optional

import data_paths

log = logging.getLogger("jarvis.auth_store")

MIN_PASSWORD_LENGTH = 12
MAX_PASSWORD_LENGTH = 1024          # scrypt on a megabyte is a DoS, not a password

# scrypt cost: 2**14 * 8 * 128 = 16 MiB and ~50 ms per guess. OWASP's floor.
SCRYPT_N = 2 ** 14
SCRYPT_R = 8
SCRYPT_P = 1
_SCRYPT_MAXMEM = 64 * 1024 * 1024

SESSION_COOKIE = "jarvis_session"
SESSION_SECONDS = 30 * 24 * 3600

PER_ADDRESS_FAILURES = 10
GLOBAL_FAILURES = 50
WINDOW_SECONDS = 15 * 60


# ---------------------------------------------------------------------------
# Private files
# ---------------------------------------------------------------------------

def auth_dir() -> Path:
    path = data_paths.data_dir() / "auth"
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    try:
        os.chmod(path, 0o700)
    except OSError:                                         # pragma: no cover
        pass
    return path


def password_path() -> Path:
    override = os.getenv("JARVIS_PASSWORD_FILE")
    return Path(override).expanduser() if override else auth_dir() / "password"


def secret_path() -> Path:
    return auth_dir() / "session-secret"


def write_private(path: Path, text: str) -> None:
    """Replace `path` with `text`, never readable by anyone else.

    The temporary file comes from mkstemp, which creates it 0600 from the
    first byte; `os.replace` then swaps it in atomically and does not follow
    a symlink planted at `path` (it replaces the link itself).
    """
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=f".{path.name}-")
    try:
        with os.fdopen(fd, "w") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _read_private(path: Path) -> Optional[str]:
    """The file's text, or None if absent. Refuses anything that is not a
    regular file we own, and tightens a loose mode before reading."""
    try:
        fd = os.open(str(path), os.O_RDONLY | os.O_NOFOLLOW)
    except FileNotFoundError:
        return None
    except OSError as e:
        log.error("auth: cannot open %s (%s)", path, e)
        return None
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid():
            log.error("auth: %s is not a regular file owned by this user; "
                      "ignoring it", path)
            return None
        if info.st_mode & 0o077:
            os.fchmod(fd, 0o600)
        return os.read(fd, 65536).decode("utf-8", "ignore").strip()
    finally:
        os.close(fd)


# ---------------------------------------------------------------------------
# Password
# ---------------------------------------------------------------------------

def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _unb64(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def password_problem(password: str) -> Optional[str]:
    """Why `password` cannot be used, or None."""
    if len(password) < MIN_PASSWORD_LENGTH:
        return f"Use at least {MIN_PASSWORD_LENGTH} characters."
    if len(password) > MAX_PASSWORD_LENGTH:
        return f"Use at most {MAX_PASSWORD_LENGTH} characters."
    return None


def hash_password(password: str, *, n: int = SCRYPT_N, r: int = SCRYPT_R,
                  p: int = SCRYPT_P) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=n, r=r, p=p,
                            maxmem=_SCRYPT_MAXMEM, dklen=32)
    return f"scrypt:{n}:{r}:{p}:{_b64(salt)}:{_b64(digest)}"


def verify_password(password: str, stored: Optional[str]) -> bool:
    if not stored or not isinstance(password, str):
        return False
    if len(password) > MAX_PASSWORD_LENGTH:
        return False
    try:
        kind, n, r, p, salt, digest = stored.split(":")
        if kind != "scrypt":
            return False
        expected = _unb64(digest)
        got = hashlib.scrypt(password.encode("utf-8"), salt=_unb64(salt),
                             n=int(n), r=int(r), p=int(p),
                             maxmem=_SCRYPT_MAXMEM, dklen=len(expected))
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(got, expected)


_cache_lock = threading.Lock()
_cache: dict[str, tuple[float, Optional[str]]] = {}


def stored_hash() -> Optional[str]:
    """The configured hash, or None. Re-read when the file changes, so a
    password set by the wizard takes effect without a restart."""
    path = password_path()
    try:
        mtime = path.lstat().st_mtime
    except FileNotFoundError:
        return None
    except OSError:                                          # pragma: no cover
        return None
    key = str(path)
    with _cache_lock:
        hit = _cache.get(key)
        if hit and hit[0] == mtime:
            return hit[1]
    value = _read_private(path)
    if value is not None and not value.startswith("scrypt:"):
        log.error("auth: %s does not hold a scrypt hash; ignoring it", path)
        value = None
    with _cache_lock:
        _cache[key] = (mtime, value)
    return value


def password_configured() -> bool:
    return stored_hash() is not None


def set_password(password: str) -> None:
    problem = password_problem(password)
    if problem:
        raise ValueError(problem)
    write_private(password_path(), hash_password(password) + "\n")


# ---------------------------------------------------------------------------
# Sessions
# ---------------------------------------------------------------------------

def _secret() -> bytes:
    path = secret_path()
    existing = _read_private(path)
    if existing:
        return existing.encode("ascii", "ignore")
    try:
        fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:                                  # lost a race
        return (_read_private(path) or "").encode("ascii", "ignore")
    value = secrets.token_urlsafe(48)
    try:
        os.write(fd, value.encode("ascii"))
    finally:
        os.close(fd)
    return value.encode("ascii")


def rotate_secret() -> None:
    """Invalidate every session cookie ever issued."""
    write_private(secret_path(), secrets.token_urlsafe(48))


def _fingerprint() -> str:
    return hashlib.sha256((stored_hash() or "").encode("utf-8")).hexdigest()[:16]


def _mac(expires: int, nonce: str) -> str:
    message = f"v1.{expires}.{nonce}.{_fingerprint()}".encode("ascii")
    return _b64(hmac.new(_secret(), message, hashlib.sha256).digest())


def issue_session(now: Optional[float] = None) -> str:
    expires = int((time.time() if now is None else now) + SESSION_SECONDS)
    nonce = secrets.token_urlsafe(12)
    return f"v1.{expires}.{nonce}.{_mac(expires, nonce)}"


def session_valid(value: Optional[str], now: Optional[float] = None) -> bool:
    if not value or len(value) > 256 or not password_configured():
        return False
    parts = value.split(".")
    if len(parts) != 4 or parts[0] != "v1":
        return False
    _, expires_raw, nonce, mac = parts
    try:
        expires = int(expires_raw)
    except ValueError:
        return False
    if expires < (time.time() if now is None else now):
        return False
    return hmac.compare_digest(mac.encode("ascii", "ignore"),
                               _mac(expires, nonce).encode("ascii"))


# ---------------------------------------------------------------------------
# Brute-force limiter
# ---------------------------------------------------------------------------

class LoginLimiter:
    def __init__(self, per_address: int = PER_ADDRESS_FAILURES,
                 overall: int = GLOBAL_FAILURES,
                 window: float = WINDOW_SECONDS):
        self.per_address = per_address
        self.overall = overall
        self.window = window
        self._failures: list[tuple[float, str]] = []
        self._lock = threading.Lock()

    def _prune(self, now: float) -> None:
        cutoff = now - self.window
        self._failures = [f for f in self._failures if f[0] >= cutoff]

    def blocked(self, address: str, now: Optional[float] = None) -> bool:
        now = time.time() if now is None else now
        with self._lock:
            self._prune(now)
            if len(self._failures) >= self.overall:
                return True
            return sum(1 for _, a in self._failures if a == address) >= self.per_address

    def failed(self, address: str, now: Optional[float] = None) -> None:
        with self._lock:
            self._failures.append((time.time() if now is None else now, address))

    def succeeded(self, address: str) -> None:
        with self._lock:
            self._failures = [f for f in self._failures if f[1] != address]

    def reset(self) -> None:
        with self._lock:
            self._failures = []


LIMITER = LoginLimiter()


# ---------------------------------------------------------------------------
# CLI — used by deploy/jarvis-setup, and by hand
# ---------------------------------------------------------------------------

def _main(argv: list[str]) -> int:
    import getpass

    usage = ("usage: auth_store.py set-password [--stdin] | status | "
             "logout-everywhere | clear-password")
    if len(argv) < 1:
        print(usage, file=sys.stderr)
        return 2
    cmd = argv[0]
    if cmd == "set-password":
        if "--stdin" in argv:
            password = sys.stdin.readline().rstrip("\n")
        else:
            password = getpass.getpass("New JARVIS password: ")
            if getpass.getpass("Again: ") != password:
                print("The two did not match. Nothing was changed.", file=sys.stderr)
                return 1
        try:
            set_password(password)
        except ValueError as e:
            print(f"{e} Nothing was changed.", file=sys.stderr)
            return 1
        rotate_secret()
        print(f"Password set ({password_path()}). Every browser has been logged out.")
        return 0
    if cmd == "status":
        print("configured" if password_configured() else "not configured")
        return 0 if password_configured() else 1
    if cmd == "logout-everywhere":
        rotate_secret()
        print("Every browser session has been logged out.")
        return 0
    if cmd == "clear-password":
        try:
            password_path().unlink()
        except FileNotFoundError:
            pass
        print("Password removed. JARVIS will refuse to start in cloud mode until one is set.")
        return 0
    print(usage, file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(_main(sys.argv[1:]))
