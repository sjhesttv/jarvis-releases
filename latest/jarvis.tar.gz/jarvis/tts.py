"""
tts.py — speech synthesis, one request per sentence chunk.

Two engines:
  local   Kokoro on this machine, through the jarvis-ml service
          (ml_client.speak). No account, no network, no per-character bill.
  fish    Fish Audio's API (FISH_API_KEY), the original voice.

JARVIS_TTS picks: `local`, `fish`, or `auto` (the default) — local when the
service has its voice loaded, else Fish when there is a key, else local
anyway (it may be loading). `local` falls back to Fish for a chunk the
service could not speak, if there is a key.

For Fish the response is streamed so time-to-first-byte can be measured;
the chunk is returned whole because the browser decodes one complete file
per chunk.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Optional

import os

import httpx

log = logging.getLogger("jarvis.tts")

ENGINES = ("auto", "local", "fish")


def configured_engine() -> str:
    value = os.getenv("JARVIS_TTS", "auto").strip().lower()
    return value if value in ENGINES else "auto"


async def engine_for_now(fish_key: str) -> str:
    """"local" or "fish", for the next chunk."""
    import ml_client
    choice = configured_engine()
    if choice != "auto":
        return choice
    if await ml_client.ready("tts"):
        return "local"
    return "fish" if fish_key else "local"


async def synthesize(text: str, *, fish_key: str, voice_id: str,
                     client: Optional[httpx.AsyncClient] = None) -> Optional[SynthResult]:
    """One chunk, from whichever engine is in use."""
    import ml_client
    text = (text or "").strip()
    if not text:
        return None
    if await engine_for_now(fish_key) == "local":
        t0 = time.monotonic()
        audio = await ml_client.speak(text, client=client)
        if audio:
            took = time.monotonic() - t0
            return SynthResult(audio, took, took, engine="local")
        if not fish_key:
            return None
        log.info("local voice could not speak that chunk; using Fish for it")
    r = await synthesize_chunk(text, api_key=fish_key, voice_id=voice_id, client=client)
    if r is not None:
        r.engine = "fish"
    return r

FISH_TTS_URL = "https://api.fish.audio/v1/tts"


@dataclass
class SynthResult:
    audio: bytes
    first_byte_sec: float
    total_sec: float
    engine: str = "fish"


async def synthesize_chunk(text: str, *, api_key: str, voice_id: str,
                           client: Optional[httpx.AsyncClient] = None,
                           latency: str = "balanced", timeout: float = 15.0) -> Optional[SynthResult]:
    text = (text or "").strip()
    if not text or not api_key:
        return None
    own = client is None
    client = client or httpx.AsyncClient(timeout=timeout)
    t0 = time.monotonic()
    first: Optional[float] = None
    buf = bytearray()
    try:
        async with client.stream(
            "POST", FISH_TTS_URL,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={"text": text, "reference_id": voice_id, "format": "mp3", "mp3_bitrate": 128, "latency": latency},
            timeout=timeout,
        ) as resp:
            if resp.status_code != 200:
                log.error(f"TTS {resp.status_code} for {text[:40]!r}")
                return None
            async for part in resp.aiter_bytes():
                if first is None:
                    first = time.monotonic() - t0
                buf.extend(part)
    except (httpx.HTTPError, OSError) as e:
        log.error(f"TTS error: {e}")
        return None
    finally:
        if own:
            try:
                await client.aclose()
            except Exception as e:      # never turn a clean None into an exception
                log.debug(f"TTS client close failed: {e}")
    if not buf:
        return None
    return SynthResult(bytes(buf), first if first is not None else 0.0, time.monotonic() - t0)
