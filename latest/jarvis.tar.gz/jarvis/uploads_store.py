"""Files the user gives JARVIS: dropped on the page, kept in a project.

They go into `<projects root>/uploads/`, an ordinary project folder, so every
project tool works on them with nothing new: `read_file` / `search_repo` /
`repo_overview` read them, a run (`spawn_run`) edits them, `share_file` and
`show_file` hand a result back. `look_at_file` lets the brain SEE an
uploaded image.

The name is the user's own file name, flattened to something safe for a
directory (`My Report (final).pdf` → `my-report-final.pdf`), never a path,
and a clash gets a suffix rather than overwriting what is there.
"""

from __future__ import annotations

import os
import re
import stat
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import project_maker

PROJECT_NAME = "uploads"
MAX_UPLOAD_BYTES = 200 * 1024 ** 2
MAX_TOTAL_BYTES = 10 * 1024 ** 3
NAME_RE = re.compile(r"[a-z0-9][a-z0-9._-]{0,120}")
_DROP = re.compile(r"[^a-z0-9.]+")

IMAGE_TYPES = {".png", ".jpg", ".jpeg", ".gif", ".webp"}

_lock = threading.Lock()
# Uploaded since JARVIS last heard about it; the next turn is told.
_unannounced: list[str] = []


class UploadProblem(ValueError):
    """Shown to the user as is."""


@dataclass
class Upload:
    name: str
    size: int
    modified: float

    def as_dict(self) -> dict:
        return {"name": self.name, "size": self.size, "modified": self.modified,
                "image": Path(self.name).suffix.lower() in IMAGE_TYPES,
                "url": f"/api/uploads/{self.name}"}


def folder() -> Path:
    path = project_maker.projects_root() / PROJECT_NAME
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    return path


def safe_name(original: str) -> str:
    base = Path(str(original or "file").replace("\\", "/")).name.lower()
    stem, dot, ext = base.rpartition(".")
    if not dot:
        stem, ext = base, ""
    stem = _DROP.sub("-", stem).strip("-.")[:80] or "file"
    ext = re.sub(r"[^a-z0-9]", "", ext)[:10]
    return f"{stem}.{ext}" if ext else stem


def _used() -> int:
    total = 0
    for p in folder().iterdir():
        try:
            total += p.lstat().st_size
        except OSError:
            pass
    return total


def save(original: str, data: bytes) -> Upload:
    if not data:
        raise UploadProblem("That file is empty.")
    if len(data) > MAX_UPLOAD_BYTES:
        raise UploadProblem("That file is too large (200 MB at most).")
    if _used() + len(data) > MAX_TOTAL_BYTES:
        raise UploadProblem("The uploads folder is full; delete something first.")
    name = safe_name(original)
    with _lock:
        stem, dot, ext = name.rpartition(".")
        if not dot:
            stem, ext = name, ""
        candidate, n = name, 2
        while (folder() / candidate).exists():
            candidate = f"{stem}-{n}.{ext}" if ext else f"{stem}-{n}"
            n += 1
        fd = os.open(str(folder() / candidate), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        _unannounced.append(candidate)
    return entry(candidate)


def path_for(name: str) -> Optional[Path]:
    if not isinstance(name, str) or not NAME_RE.fullmatch(name):
        return None
    path = folder() / name
    try:
        info = path.lstat()
    except OSError:
        return None
    return path if stat.S_ISREG(info.st_mode) else None


def entry(name: str) -> Upload:
    info = (folder() / name).lstat()
    return Upload(name, info.st_size, info.st_mtime)


def list_uploads() -> list[Upload]:
    rows = [entry(p.name) for p in folder().iterdir() if path_for(p.name) is not None]
    rows.sort(key=lambda u: u.modified, reverse=True)
    return rows


def delete(name: str) -> bool:
    path = path_for(name)
    if path is None:
        return False
    path.unlink()
    return True


def take_unannounced() -> list[str]:
    """Names uploaded since the brain was last told, and forget them."""
    with _lock:
        names = [n for n in _unannounced if path_for(n) is not None]
        _unannounced.clear()
    return names


def note_for_brain(names: list[str]) -> str:
    """The line prepended to the user's next utterance. Names are already
    held to NAME_RE, so they are safe to put in JARVIS's own words."""
    shown = ", ".join(names[:10]) + (f" and {len(names) - 10} more" if len(names) > 10 else "")
    return (f"[He has just uploaded {len(names)} file{'s' if len(names) != 1 else ''} "
            f"into the '{PROJECT_NAME}' project: {shown}. Read text files with "
            f"read_file, see images with look_at_file, change them with a run.]")


