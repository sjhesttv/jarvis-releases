"""Export and import JARVIS's memory, for moving to a new server.

An export is one `.tar.gz`:

    manifest.json            what is inside, and from which JARVIS
    memory/memory.db         the whole memory database (memory_db.py)
    brain/MEMORY.md          the core list every conversation sees
    brain/memory/*.md        each fact, readable           } the same memory,
    brain/projects/*.md      per-project notes             } as Markdown a
    brain/journal/*.md       the handover journal          } person can read
    brain/conversations/*.md what was said, by day         }
    brain/CLAUDE.md          the persona, if it has been edited
    settings.env             name, honorific, voice, weather, model
    history/jarvis.db        run history                 (optional)
    brain/connections.json   MCP servers                 (optional: secrets)
    secrets.env              Fish and GitHub keys        (optional: secrets)

An import takes `memory/memory.db` when it is there, and otherwise the
Markdown (an export from before the database, or one edited by hand).
Import never deletes. `merge` (the default) adds what is missing and keeps
what is already here; `replace` first saves the current brain to
`<data>/backups/`, then overwrites. Run history cannot be swapped under a
running server, so it is staged as `jarvis.db.incoming` and taken on the
next start (`apply_staged_history`, called from server.lifespan).

Extraction is an allowlist: regular files only, under the names above, no
links, no `..`, bounded sizes. Anything else in the archive is ignored and
reported.

CLI (run as the service user, with JARVIS's environment):

    python3 memory_archive.py export out.tar.gz [--history] [--secrets]
    python3 memory_archive.py import in.tar.gz [--replace]
"""

from __future__ import annotations

import io
import json
import logging
import os
import re
import shutil
import sqlite3
import sys
import tarfile
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Optional

import auth_store
import data_paths

log = logging.getLogger("jarvis.memory_archive")

FORMAT = "jarvis-memory"
VERSION = 1
MAX_ARCHIVE_BYTES = 300 * 1024 ** 2
MAX_MEMBER_BYTES = 200 * 1024 ** 2
MAX_MEMBERS = 20_000

SAFE_SETTINGS = ("USER_NAME", "HONORIFIC", "FISH_VOICE_ID", "JARVIS_BRAIN_MODEL",
                 "WEATHER_LOCATION_LABEL", "WEATHER_LATITUDE", "WEATHER_LONGITUDE",
                 "WEATHER_UNIT")
SECRET_SETTINGS = ("FISH_API_KEY", "GH_TOKEN")

_MD_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9._ -]{0,150}\.md")
_FOLDERS = ("memory", "projects", "journal", "conversations")


class ArchiveProblem(ValueError):
    """Shown to the user as is."""


@dataclass
class Report:
    added: int = 0
    replaced: int = 0
    kept: int = 0
    ignored: list[str] = field(default_factory=list)
    settings: list[str] = field(default_factory=list)
    history_staged: bool = False
    backup: str = ""
    restart_needed: bool = False

    def as_dict(self) -> dict:
        return dict(self.__dict__)


# ---------------------------------------------------------------------------
# Settings files (KEY=value lines)
# ---------------------------------------------------------------------------

def _settings_path() -> Path:
    override = os.getenv("JARVIS_ENV_FILE", "").strip()
    return Path(override) if override else Path(__file__).parent / ".env"


def _read_settings() -> dict[str, str]:
    out = {}
    try:
        text = _settings_path().read_text()
    except OSError:
        return out
    for line in text.splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def _env_text(values: dict[str, str]) -> str:
    return "".join(f"{k}={v}\n" for k, v in values.items()
                   if v and "\n" not in v and "\r" not in v)


def _parse_env(text: str, allowed: tuple[str, ...]) -> dict[str, str]:
    out = {}
    for line in text.splitlines()[:200]:
        k, sep, v = line.strip().partition("=")
        if sep and k in allowed and v and len(v) <= 4096 \
                and not any(ord(c) < 32 for c in v):
            out[k] = v
    return out


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

def _persona_edited() -> bool:
    try:
        live = data_paths.persona_path().read_bytes()
        shipped = data_paths.persona_template_path().read_bytes()
    except OSError:
        return False
    return live != shipped


def _add_bytes(tar: tarfile.TarFile, name: str, data: bytes) -> None:
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mtime = int(time.time())
    info.mode = 0o600
    tar.addfile(info, io.BytesIO(data))


def _db_snapshot() -> Optional[bytes]:
    """A consistent copy of the live database, via SQLite's own backup."""
    src_path = data_paths.db_path()
    if not src_path.exists():
        return None
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "jarvis.db"
        src = sqlite3.connect(str(src_path))
        dst = sqlite3.connect(str(out))
        try:
            src.backup(dst)
        finally:
            dst.close()
            src.close()
        return out.read_bytes()


def export_archive(include_history: bool = False, include_secrets: bool = False) -> bytes:
    import conversation_log
    import jarvis_memory
    import memory_db

    buf = io.BytesIO()
    contents = []
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        _add_bytes(tar, "memory/memory.db", memory_db.snapshot_bytes())
        contents.append("memory.db")
        _add_bytes(tar, "brain/MEMORY.md", jarvis_memory.index_text().encode())
        contents.append("index")
        listings = {
            "memory": ("memory", [e["slug"] for e in jarvis_memory.memory_entries()]),
            "projects": ("project", [e["slug"] for e in jarvis_memory.project_entries()]),
            "journal": ("journal", [e["slug"] for e in jarvis_memory.journal_entries_meta()]),
            "conversations": ("conversation", [d["slug"] for d in conversation_log.days_meta()]),
        }
        for folder, (kind, slugs) in listings.items():
            count = 0
            for slug in slugs:
                text = jarvis_memory.render(kind, slug)
                if text is not None and _MD_NAME.fullmatch(f"{slug}.md"):
                    _add_bytes(tar, f"brain/{folder}/{slug}.md", text.encode())
                    count += 1
            contents.append(f"{folder}:{count}")
        if _persona_edited():
            _add_bytes(tar, "brain/CLAUDE.md", data_paths.persona_path().read_bytes())
            contents.append("persona")
        settings = _read_settings()
        _add_bytes(tar, "settings.env", _env_text(
            {k: settings[k] for k in SAFE_SETTINGS if k in settings}).encode())
        if include_history:
            db = _db_snapshot()
            if db:
                _add_bytes(tar, "history/jarvis.db", db)
                contents.append("history")
        if include_secrets:
            conn = data_paths.connections_path()
            if conn.is_file():
                _add_bytes(tar, "brain/connections.json", conn.read_bytes())
                contents.append("connections")
            keys = {k: settings.get(k) or os.environ.get(k, "") for k in SECRET_SETTINGS}
            _add_bytes(tar, "secrets.env", _env_text(keys).encode())
            contents.append("secrets")
        manifest = {"format": FORMAT, "version": VERSION, "created": time.time(),
                    "jarvis_version": _version(), "contents": contents}
        _add_bytes(tar, "manifest.json", json.dumps(manifest, indent=2).encode())
    return buf.getvalue()


def _version() -> str:
    try:
        return (Path(__file__).parent / "VERSION").read_text().strip()
    except OSError:
        return "dev"


# ---------------------------------------------------------------------------
# Import
# ---------------------------------------------------------------------------

def _allowed(name: str) -> bool:
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts:
        return False
    parts = path.parts
    if name in ("manifest.json", "settings.env", "secrets.env", "history/jarvis.db",
                "memory/memory.db",
                "brain/MEMORY.md", "brain/CLAUDE.md", "brain/connections.json"):
        return True
    return (len(parts) == 3 and parts[0] == "brain" and parts[1] in _FOLDERS
            and bool(_MD_NAME.fullmatch(parts[2])))


def _members(data: bytes) -> tuple[dict[str, bytes], list[str]]:
    if len(data) > MAX_ARCHIVE_BYTES:
        raise ArchiveProblem("That archive is too large.")
    try:
        tar = tarfile.open(fileobj=io.BytesIO(data), mode="r:gz")
    except (tarfile.TarError, OSError, EOFError):
        raise ArchiveProblem("That is not a JARVIS export (not a .tar.gz).")
    files, ignored = {}, []
    with tar:
        for count, member in enumerate(tar):
            if count >= MAX_MEMBERS:
                raise ArchiveProblem("That archive has too many files in it.")
            if not member.isfile() or not _allowed(member.name) \
                    or member.size > MAX_MEMBER_BYTES:
                ignored.append(member.name[:120])
                continue
            handle = tar.extractfile(member)
            if handle is not None:
                files[member.name] = handle.read(MAX_MEMBER_BYTES + 1)[:MAX_MEMBER_BYTES]
    try:
        manifest = json.loads(files.get("manifest.json", b"{}"))
    except ValueError:
        manifest = {}
    if manifest.get("format") != FORMAT:
        raise ArchiveProblem("That is not a JARVIS memory export.")
    if int(manifest.get("version", 0)) > VERSION:
        raise ArchiveProblem("That export is from a newer JARVIS; update this one first.")
    return files, ignored


def backup_current() -> Path:
    """The whole current brain, as an export with everything, kept on disk."""
    folder = data_paths.data_dir() / "backups"
    folder.mkdir(mode=0o700, exist_ok=True)
    path = folder / time.strftime("before-import-%Y%m%d-%H%M%S.tar.gz")
    data = export_archive(include_history=True, include_secrets=True)
    fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, "wb") as fh:
        fh.write(data)
    return path


def _write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=f".{path.name}-")
    with os.fdopen(fd, "wb") as fh:
        fh.write(data)
    os.replace(tmp, path)


def import_archive(data: bytes, replace: bool = False,
                   with_secrets: bool = True) -> Report:
    import jarvis_memory
    import memory_db

    files, ignored = _members(data)
    report = Report(ignored=ignored)
    jarvis_memory.ensure_layout()
    if replace:
        report.backup = str(backup_current())

    if "memory/memory.db" in files:
        with tempfile.TemporaryDirectory() as tmp:
            incoming = Path(tmp) / "memory.db"
            incoming.write_bytes(files["memory/memory.db"])
            try:
                counts = memory_db.merge_from(incoming, replace=replace)
            except sqlite3.DatabaseError as e:
                raise ArchiveProblem(f"The memory database in that export is damaged ({e}).")
        report.added += counts["added"]
        report.replaced += counts["replaced"]
        report.kept += counts["kept"]
        jarvis_memory.refresh_index()
    else:
        if replace:
            memory_db.clear()
        for name, body in sorted(files.items()):
            parts = PurePosixPath(name).parts
            if len(parts) != 3 or parts[0] != "brain":
                continue
            outcome = jarvis_memory.import_markdown(
                parts[1], parts[2], body.decode("utf-8", "replace"), replace=replace)
            setattr(report, outcome, getattr(report, outcome) + 1)
        if "brain/MEMORY.md" in files:
            jarvis_memory.import_index(files["brain/MEMORY.md"].decode("utf-8", "replace"),
                                       replace=replace)
        jarvis_memory.refresh_index()

    if "brain/CLAUDE.md" in files and (replace or not _persona_edited()):
        _write(data_paths.persona_path(), files["brain/CLAUDE.md"])
        report.restart_needed = True

    if with_secrets and "brain/connections.json" in files:
        conn = data_paths.connections_path()
        if replace or not conn.exists() or not _has_servers(conn):
            try:
                json.loads(files["brain/connections.json"])
            except ValueError:
                report.ignored.append("brain/connections.json (not valid JSON)")
            else:
                auth_store.write_private(conn, files["brain/connections.json"].decode())
                report.restart_needed = True

    current = _read_settings()
    wanted = _parse_env(files.get("settings.env", b"").decode("utf-8", "replace"), SAFE_SETTINGS)
    if with_secrets:
        wanted.update(_parse_env(files.get("secrets.env", b"").decode("utf-8", "replace"),
                                 SECRET_SETTINGS))
    changed = {k: v for k, v in wanted.items() if replace or not current.get(k)}
    if changed:
        merged = dict(current)
        merged.update(changed)
        lines = [ln for ln in (_settings_path().read_text().splitlines()
                               if _settings_path().exists() else [])
                 if ln.strip().partition("=")[0].strip() not in changed]
        lines += [f"{k}={v}" for k, v in changed.items()]
        auth_store.write_private(_settings_path(), "\n".join(lines) + "\n")
        report.settings = sorted(changed)
        report.restart_needed = True

    if "history/jarvis.db" in files:
        staged = data_paths.data_dir() / "jarvis.db.incoming"
        _write(staged, files["history/jarvis.db"])
        os.chmod(staged, 0o600)
        report.history_staged = True
        report.restart_needed = True
    return report


def _has_servers(path: Path) -> bool:
    try:
        return bool(json.loads(path.read_text()).get("mcpServers"))
    except (OSError, ValueError, AttributeError):
        return False


def apply_staged_history() -> bool:
    """Called once at startup, before the database is opened."""
    staged = data_paths.data_dir() / "jarvis.db.incoming"
    if not staged.exists():
        return False
    try:
        check = sqlite3.connect(str(staged))
        try:
            check.execute("SELECT count(*) FROM runs").fetchone()
        finally:
            check.close()
    except sqlite3.DatabaseError as e:
        log.error("staged run history is not a usable database (%s); ignored", e)
        staged.rename(staged.with_suffix(".rejected"))
        return False
    live = data_paths.db_path()
    if live.exists():
        folder = data_paths.data_dir() / "backups"
        folder.mkdir(mode=0o700, exist_ok=True)
        shutil.copy2(live, folder / time.strftime("jarvis-%Y%m%d-%H%M%S.db"))
    for suffix in ("-wal", "-shm"):
        side = live.with_name(live.name + suffix)
        if side.exists():
            side.unlink()
    os.replace(staged, live)
    log.info("imported run history applied")
    return True


def _main(argv: list[str]) -> int:
    if len(argv) < 2 or argv[0] not in ("export", "import"):
        print(__doc__.split("CLI")[1].strip(), file=sys.stderr)
        return 2
    path = Path(argv[1])
    if argv[0] == "export":
        data = export_archive("--history" in argv, "--secrets" in argv)
        fd = os.open(str(path), os.O_CREAT | os.O_TRUNC | os.O_WRONLY, 0o600)
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        print(f"Exported {len(data)} bytes to {path}.")
        return 0
    try:
        report = import_archive(path.read_bytes(), replace="--replace" in argv)
    except ArchiveProblem as e:
        print(e, file=sys.stderr)
        return 1
    print(json.dumps(report.as_dict(), indent=2))
    if report.restart_needed:
        print("Restart JARVIS to finish:  sudo systemctl restart jarvis")
    return 0


if __name__ == "__main__":
    sys.exit(_main(sys.argv[1:]))
