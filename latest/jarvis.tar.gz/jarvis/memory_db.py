"""JARVIS's memory, in SQLite: `<data>/memory.db`.

Layered the way assistant memory systems usually are:

  core        facts flagged `core` — the short list read into EVERY
              conversation (rendered to MEMORY.md, which the persona imports)
  facts       everything he has been asked to remember, one row each
  episodes    a short summary of each stretch of conversation, written by
              the brain after a quiet spell (server.review_conversation)
  history     every exchange, word for word
  notes       per-project notes, one row per note
  journal     the handover a brain generation leaves the next

Search is hybrid. Every table has an FTS5 index (keyword relevance, BM25),
and facts, notes and episodes also carry an embedding from a small local
model (ml_client.py → the jarvis-ml service), so "what did we decide about
pricing?" finds an episode that only ever said "cost". Without the model the
keyword half still works; embeddings are filled in whenever it is up.

One file: a memory export (memory_archive.py) carries it whole, and the
dashboard's Memory tab is its editor.
"""

from __future__ import annotations

import array
import hashlib
import math
import sqlite3
import threading
import time
from contextlib import closing
from typing import Iterable

import data_paths

SCHEMA_VERSION = 1
_lock = threading.RLock()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS facts (
    id INTEGER PRIMARY KEY, slug TEXT NOT NULL UNIQUE, norm TEXT NOT NULL,
    title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '', hook TEXT NOT NULL DEFAULT '',
    core INTEGER NOT NULL DEFAULT 0, core_order REAL,
    created REAL NOT NULL, updated REAL NOT NULL);
CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY, project TEXT NOT NULL, project_slug TEXT NOT NULL,
    ts REAL NOT NULL, text TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS notes_by_project ON notes(project_slug, ts);
CREATE TABLE IF NOT EXISTS journal (
    id INTEGER PRIMARY KEY, slug TEXT NOT NULL UNIQUE, stamp TEXT NOT NULL,
    reason TEXT NOT NULL, untrusted_source TEXT, ts REAL NOT NULL, text TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS exchanges (
    id INTEGER PRIMARY KEY, ts REAL NOT NULL, day TEXT NOT NULL,
    you TEXT NOT NULL, jarvis TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS exchanges_by_day ON exchanges(day, ts);
CREATE TABLE IF NOT EXISTS episodes (
    id INTEGER PRIMARY KEY, start REAL NOT NULL, end REAL NOT NULL,
    day TEXT NOT NULL, text TEXT NOT NULL, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS embeddings (
    ref TEXT PRIMARY KEY, model TEXT NOT NULL, text_hash TEXT NOT NULL, vec BLOB NOT NULL);

CREATE VIRTUAL TABLE IF NOT EXISTS facts_fts USING fts5(title, hook, body, content='facts', content_rowid='id');
CREATE VIRTUAL TABLE IF NOT EXISTS notes_fts USING fts5(project, text, content='notes', content_rowid='id');
CREATE VIRTUAL TABLE IF NOT EXISTS journal_fts USING fts5(reason, text, content='journal', content_rowid='id');
CREATE VIRTUAL TABLE IF NOT EXISTS exchanges_fts USING fts5(you, jarvis, content='exchanges', content_rowid='id');
CREATE VIRTUAL TABLE IF NOT EXISTS episodes_fts USING fts5(text, content='episodes', content_rowid='id');
"""

# Keep each FTS index in step with its table.
_FTS = {"facts": ("title", "hook", "body"), "notes": ("project", "text"),
        "journal": ("reason", "text"), "exchanges": ("you", "jarvis"), "episodes": ("text",)}


def _triggers() -> str:
    out = []
    for table, cols in _FTS.items():
        new = ", ".join(f"new.{c}" for c in cols)
        old = ", ".join(f"old.{c}" for c in cols)
        names = ", ".join(cols)
        out.append(f"""
CREATE TRIGGER IF NOT EXISTS {table}_ai AFTER INSERT ON {table} BEGIN
  INSERT INTO {table}_fts(rowid, {names}) VALUES (new.id, {new}); END;
CREATE TRIGGER IF NOT EXISTS {table}_ad AFTER DELETE ON {table} BEGIN
  INSERT INTO {table}_fts({table}_fts, rowid, {names}) VALUES ('delete', old.id, {old}); END;
CREATE TRIGGER IF NOT EXISTS {table}_au AFTER UPDATE ON {table} BEGIN
  INSERT INTO {table}_fts({table}_fts, rowid, {names}) VALUES ('delete', old.id, {old});
  INSERT INTO {table}_fts(rowid, {names}) VALUES (new.id, {new}); END;""")
    return "\n".join(out)


_ready: set[str] = set()


def path():
    return data_paths.data_dir() / "memory.db"


def connect() -> sqlite3.Connection:
    p = str(path())
    conn = sqlite3.connect(p, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    if p not in _ready:
        with _lock:
            conn.executescript(_SCHEMA + _triggers())
            conn.execute("INSERT OR IGNORE INTO meta VALUES ('schema', ?)", (str(SCHEMA_VERSION),))
            conn.commit()
            _ready.add(p)
    return conn


def meta_get(key: str, default: str = "") -> str:
    with closing(connect()) as c:
        r = c.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return r["value"] if r else default


def meta_set(key: str, value: str) -> None:
    with closing(connect()) as c, c:
        c.execute("INSERT OR REPLACE INTO meta VALUES (?, ?)", (key, value))


# ---------------------------------------------------------------------------
# Keyword search
# ---------------------------------------------------------------------------

def fts_query(words: Iterable[str]) -> str:
    """An FTS5 MATCH string that ORs the words, each as a prefix, quoted so
    no word can be read as an FTS operator."""
    terms = []
    for w in words:
        w = "".join(ch for ch in w if ch.isalnum())
        if w:
            terms.append(f'"{w}"*')
    return " OR ".join(terms)


def keyword(table: str, words: Iterable[str], limit: int = 20) -> list[tuple[int, float]]:
    """(rowid, relevance) best first; relevance is higher-is-better."""
    q = fts_query(words)
    if not q or table not in _FTS:
        return []
    with closing(connect()) as c:
        try:
            rows = c.execute(f"SELECT rowid, bm25({table}_fts) AS s FROM {table}_fts "
                             f"WHERE {table}_fts MATCH ? ORDER BY s LIMIT ?", (q, limit)).fetchall()
        except sqlite3.OperationalError:
            return []
    return [(r["rowid"], -float(r["s"])) for r in rows]


# ---------------------------------------------------------------------------
# Meaning search: embeddings
# ---------------------------------------------------------------------------

EMBEDDED = ("facts", "notes", "episodes")


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def _pack(vec: list[float]) -> bytes:
    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return array.array("f", (v / norm for v in vec)).tobytes()


def _unpack(blob: bytes) -> array.array:
    a = array.array("f")
    a.frombytes(blob)
    return a


def embed_text(table: str, row: sqlite3.Row) -> str:
    if table == "facts":
        return f"{row['title']}. {row['hook']}. {row['body']}"
    if table == "notes":
        return f"{row['project']}: {row['text']}"
    return row["text"]


def missing_embeddings(model: str, limit: int = 64) -> list[tuple[str, str]]:
    """(ref, text) for rows with no embedding, or one made from older text."""
    out = []
    with closing(connect()) as c:
        have = {r["ref"]: (r["model"], r["text_hash"])
                for r in c.execute("SELECT ref, model, text_hash FROM embeddings")}
        for table in EMBEDDED:
            for row in c.execute(f"SELECT * FROM {table} ORDER BY id DESC"):
                ref = f"{table}:{row['id']}"
                text = embed_text(table, row)
                if have.get(ref) != (model, _hash(text)):
                    out.append((ref, text))
                    if len(out) >= limit:
                        return out
    return out


def store_embeddings(model: str, items: list[tuple[str, str]], vectors: list[list[float]]) -> None:
    with closing(connect()) as c, c:
        for (ref, text), vec in zip(items, vectors):
            c.execute("INSERT OR REPLACE INTO embeddings VALUES (?, ?, ?, ?)",
                      (ref, model, _hash(text), _pack(vec)))


def nearest(query_vec: list[float], model: str, limit: int = 12) -> list[tuple[str, float]]:
    """(ref, cosine) best first. Brute force: facts, notes and episodes run
    to thousands at most, which is milliseconds."""
    q = _unpack(_pack(query_vec))
    scored = []
    with closing(connect()) as c:
        live = set()
        for table in EMBEDDED:
            live |= {f"{table}:{r['id']}" for r in c.execute(f"SELECT id FROM {table}")}
        for r in c.execute("SELECT ref, vec FROM embeddings WHERE model = ?", (model,)):
            if r["ref"] not in live:
                continue
            v = _unpack(r["vec"])
            if len(v) != len(q):
                continue
            scored.append((r["ref"], sum(a * b for a, b in zip(q, v))))
    scored.sort(key=lambda t: t[1], reverse=True)
    return scored[:limit]


def forget_embedding(ref: str) -> None:
    with closing(connect()) as c, c:
        c.execute("DELETE FROM embeddings WHERE ref = ?", (ref,))


# ---------------------------------------------------------------------------
# Episodes (conversation summaries)
# ---------------------------------------------------------------------------

def add_episode(start: float, end: float, text: str) -> int:
    text = " ".join(str(text or "").split())[:4000]
    if not text:
        return 0
    day = time.strftime("%Y-%m-%d", time.localtime(end))
    with closing(connect()) as c, c:
        cur = c.execute("INSERT INTO episodes (start, end, day, text, created) VALUES (?,?,?,?,?)",
                        (start, end, day, text, time.time()))
        return int(cur.lastrowid)


def episodes(limit: int = 200) -> list[dict]:
    with closing(connect()) as c:
        rows = c.execute("SELECT * FROM episodes ORDER BY end DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]


def stats() -> dict:
    with closing(connect()) as c:
        out = {t: c.execute(f"SELECT count(*) FROM {t}").fetchone()[0]
               for t in ("facts", "notes", "journal", "exchanges", "episodes", "embeddings")}
        out["core"] = c.execute("SELECT count(*) FROM facts WHERE core = 1").fetchone()[0]
    return out


def snapshot_bytes() -> bytes:
    """A consistent copy of the whole database (for exports)."""
    import tempfile
    from pathlib import Path
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "memory.db"
        with closing(connect()) as src, closing(sqlite3.connect(str(out))) as dst:
            src.backup(dst)
        return out.read_bytes()



# ---------------------------------------------------------------------------
# Imports (memory_archive.py)
# ---------------------------------------------------------------------------

_CONTENT_TABLES = ("facts", "notes", "journal", "exchanges", "episodes", "embeddings")


def clear() -> None:
    """Empty every memory table (an import with `replace`, after its backup)."""
    with closing(connect()) as c, c:
        for t in _CONTENT_TABLES:
            c.execute(f"DELETE FROM {t}")
        c.execute("DELETE FROM meta WHERE key IN ('index_preamble', 'index_postscript')")


def merge_from(source, replace: bool = False, core_max: int = 80) -> dict:
    """Take another memory.db (an export) into this one.

    Merge (the default) adds what is missing and keeps what is here: a fact
    by its normalised title, a journal entry by its name, a note, exchange
    or episode by its time and text. `replace` empties this one first.
    Embeddings are not copied; the backfill makes them again for this
    machine's model. Core facts beyond `core_max` arrive as ordinary ones.
    """
    counts = {"added": 0, "replaced": 0, "kept": 0}
    src = sqlite3.connect(f"file:{source}?mode=ro", uri=True)
    src.row_factory = sqlite3.Row
    try:
        tables = {r[0] for r in src.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "facts" not in tables:
            raise sqlite3.DatabaseError("no facts table")
        if replace:
            clear()
        with closing(connect()) as c, c:
            core = c.execute("SELECT count(*) FROM facts WHERE core = 1").fetchone()[0]
            for r in src.execute("SELECT * FROM facts ORDER BY id"):
                have = c.execute("SELECT id FROM facts WHERE norm = ?", (r["norm"],)).fetchone()
                if have:
                    counts["kept"] += 1
                    continue
                is_core = bool(r["core"]) and core < core_max
                core += int(is_core)
                slug, n = r["slug"], 2
                while c.execute("SELECT 1 FROM facts WHERE slug = ?", (slug,)).fetchone():
                    slug, n = f"{r['slug']}-{n}", n + 1
                c.execute("INSERT INTO facts (slug, norm, title, body, hook, core, core_order, created, updated) "
                          "VALUES (?,?,?,?,?,?,?,?,?)",
                          (slug, r["norm"], r["title"], r["body"], r["hook"], int(is_core),
                           r["core_order"] if is_core else None, r["created"], r["updated"]))
                counts["added"] += 1
            for r in src.execute("SELECT * FROM notes ORDER BY ts, id"):
                if c.execute("SELECT 1 FROM notes WHERE project_slug = ? AND ts = ? AND text = ?",
                             (r["project_slug"], r["ts"], r["text"])).fetchone():
                    counts["kept"] += 1
                    continue
                c.execute("INSERT INTO notes (project, project_slug, ts, text) VALUES (?,?,?,?)",
                          (r["project"], r["project_slug"], r["ts"], r["text"]))
                counts["added"] += 1
            for r in src.execute("SELECT * FROM journal ORDER BY stamp, id"):
                if c.execute("SELECT 1 FROM journal WHERE slug = ?", (r["slug"],)).fetchone():
                    counts["kept"] += 1
                    continue
                c.execute("INSERT INTO journal (slug, stamp, reason, untrusted_source, ts, text) "
                          "VALUES (?,?,?,?,?,?)", (r["slug"], r["stamp"], r["reason"],
                                                   r["untrusted_source"], r["ts"], r["text"]))
                counts["added"] += 1
            for r in src.execute("SELECT * FROM exchanges ORDER BY ts, id"):
                if c.execute("SELECT 1 FROM exchanges WHERE ts = ? AND you = ?",
                             (r["ts"], r["you"])).fetchone():
                    continue                       # history: not counted as documents
                c.execute("INSERT INTO exchanges (ts, day, you, jarvis) VALUES (?,?,?,?)",
                          (r["ts"], r["day"], r["you"], r["jarvis"]))
            for r in src.execute("SELECT * FROM episodes ORDER BY end, id"):
                if c.execute("SELECT 1 FROM episodes WHERE start = ? AND text = ?",
                             (r["start"], r["text"])).fetchone():
                    continue
                c.execute("INSERT INTO episodes (start, end, day, text, created) VALUES (?,?,?,?,?)",
                          (r["start"], r["end"], r["day"], r["text"], r["created"]))
            if "meta" in tables:
                for key in ("index_preamble", "index_postscript"):
                    row = src.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
                    mine = c.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
                    if row and (replace or not mine):
                        c.execute("INSERT OR REPLACE INTO meta VALUES (?, ?)", (key, row["value"]))
    finally:
        src.close()
    return counts
