"""Browser push notifications: how JARVIS reaches the user when no page is open.

Standard Web Push, implemented here on `cryptography` alone:

* VAPID (RFC 8292): the server's own P-256 key pair, made once and kept 0600
  in `<data>/push/vapid.json`; every send carries a short-lived ES256 JWT.
* Payload encryption (RFC 8291, aes128gcm): each message is encrypted to the
  subscribing browser's own key, so the push service relays bytes it cannot
  read.

A "subscription" is what a browser's PushManager hands out: an endpoint at
its push service (Google, Mozilla, Apple, Microsoft) plus two keys. Only
those services' hosts are accepted as endpoints, so a subscription can never
make the server post to an address of an attacker's choosing.

On an iPhone, Safari only offers push to a site added to the Home Screen.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import os
import struct
import time
import threading
from pathlib import Path
from typing import Optional
from urllib.parse import urlsplit

import auth_store
import data_paths

log = logging.getLogger("jarvis.push")

PUSH_HOSTS = ("fcm.googleapis.com", "updates.push.services.mozilla.com",
              "push.services.mozilla.com", "web.push.apple.com",
              "notify.windows.com")
MAX_SUBSCRIPTIONS = 12
MAX_PAYLOAD = 3000
_lock = threading.Lock()


class PushProblem(ValueError):
    """Shown to the user as is."""


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _unb64(text: str) -> bytes:
    return base64.urlsafe_b64decode(str(text) + "=" * (-len(str(text)) % 4))


def _dir() -> Path:
    path = data_paths.data_dir() / "push"
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    return path


# ---------------------------------------------------------------------------
# The server's VAPID key
# ---------------------------------------------------------------------------

def _vapid_private():
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives import serialization
    path = _dir() / "vapid.json"
    try:
        body = json.loads(path.read_text())
        raw = _unb64(body["private"])
        return ec.derive_private_key(int.from_bytes(raw, "big"), ec.SECP256R1())
    except (OSError, ValueError, KeyError):
        pass
    key = ec.generate_private_key(ec.SECP256R1())
    raw = key.private_numbers().private_value.to_bytes(32, "big")
    auth_store.write_private(path, json.dumps({"private": _b64(raw)}))
    return key


def _point(public_key) -> bytes:
    from cryptography.hazmat.primitives import serialization
    return public_key.public_bytes(serialization.Encoding.X962,
                                   serialization.PublicFormat.UncompressedPoint)


def public_key() -> str:
    """What the browser's PushManager.subscribe needs as applicationServerKey."""
    return _b64(_point(_vapid_private().public_key()))


def _vapid_header(endpoint: str, subject: str) -> str:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature
    parts = urlsplit(endpoint)
    claims = {"aud": f"{parts.scheme}://{parts.netloc}", "exp": int(time.time()) + 12 * 3600,
              "sub": subject}
    signing = (_b64(json.dumps({"typ": "JWT", "alg": "ES256"}, separators=(",", ":")).encode())
               + "." + _b64(json.dumps(claims, separators=(",", ":")).encode()))
    key = _vapid_private()
    der = key.sign(signing.encode("ascii"), ec.ECDSA(hashes.SHA256()))
    r, s = decode_dss_signature(der)
    jwt = signing + "." + _b64(r.to_bytes(32, "big") + s.to_bytes(32, "big"))
    return f"vapid t={jwt}, k={_b64(_point(key.public_key()))}"


# ---------------------------------------------------------------------------
# RFC 8291 message encryption
# ---------------------------------------------------------------------------

def _hkdf_one_block(salt: bytes, ikm: bytes, info: bytes, length: int) -> bytes:
    prk = hmac.new(salt, ikm, hashlib.sha256).digest()
    return hmac.new(prk, info + b"\x01", hashlib.sha256).digest()[:length]


def encrypt(plaintext: bytes, p256dh: str, auth: str, *, _salt: Optional[bytes] = None,
            _server_key=None) -> bytes:
    """The aes128gcm body for one message to one browser."""
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    ua_public = _unb64(p256dh)
    auth_secret = _unb64(auth)
    if len(ua_public) != 65 or ua_public[0] != 4 or len(auth_secret) != 16:
        raise PushProblem("That subscription's keys are not usable.")
    peer = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), ua_public)
    server = _server_key or ec.generate_private_key(ec.SECP256R1())
    as_public = _point(server.public_key())
    shared = server.exchange(ec.ECDH(), peer)
    ikm = _hkdf_one_block(auth_secret, shared, b"WebPush: info\x00" + ua_public + as_public, 32)
    salt = _salt or os.urandom(16)
    cek = _hkdf_one_block(salt, ikm, b"Content-Encoding: aes128gcm\x00", 16)
    nonce = _hkdf_one_block(salt, ikm, b"Content-Encoding: nonce\x00", 12)
    body = AESGCM(cek).encrypt(nonce, plaintext + b"\x02", None)
    return salt + struct.pack("!IB", 4096, len(as_public)) + as_public + body


def decrypt(message: bytes, ua_private, auth: str) -> bytes:
    """The browser's side of `encrypt`. Used by the tests to prove a round trip."""
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    salt, (rs, idlen) = message[:16], struct.unpack("!IB", message[16:21])
    as_public = message[21:21 + idlen]
    ciphertext = message[21 + idlen:]
    ua_public = _point(ua_private.public_key())
    peer = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), as_public)
    shared = ua_private.exchange(ec.ECDH(), peer)
    ikm = _hkdf_one_block(_unb64(auth), shared, b"WebPush: info\x00" + ua_public + as_public, 32)
    cek = _hkdf_one_block(salt, ikm, b"Content-Encoding: aes128gcm\x00", 16)
    nonce = _hkdf_one_block(salt, ikm, b"Content-Encoding: nonce\x00", 12)
    padded = AESGCM(cek).decrypt(nonce, ciphertext, None)
    return padded.rstrip(b"\x00")[:-1]


# ---------------------------------------------------------------------------
# Subscriptions
# ---------------------------------------------------------------------------

def _subs_path() -> Path:
    return _dir() / "subscriptions.json"


def subscriptions() -> list[dict]:
    try:
        rows = json.loads(_subs_path().read_text())
    except (OSError, ValueError):
        return []
    return [r for r in rows if isinstance(r, dict)] if isinstance(rows, list) else []


def _save(rows: list[dict]) -> None:
    auth_store.write_private(_subs_path(), json.dumps(rows, indent=2))


def endpoint_allowed(endpoint: str) -> bool:
    parts = urlsplit(str(endpoint or ""))
    host = (parts.hostname or "").lower()
    return parts.scheme == "https" and any(host == h or host.endswith("." + h) for h in PUSH_HOSTS)


def subscribe(sub: dict, label: str = "") -> dict:
    endpoint = str(sub.get("endpoint") or "")
    keys = sub.get("keys") if isinstance(sub.get("keys"), dict) else {}
    if not endpoint_allowed(endpoint):
        raise PushProblem("That browser's push service isn't one JARVIS recognises.")
    p256dh, auth = str(keys.get("p256dh") or ""), str(keys.get("auth") or "")
    try:
        encrypt(b"x", p256dh, auth)          # proves the keys are well formed
    except PushProblem:
        raise
    except Exception:
        raise PushProblem("That subscription's keys are not usable.")
    with _lock:
        rows = [r for r in subscriptions() if r.get("endpoint") != endpoint]
        entry = {"endpoint": endpoint, "p256dh": p256dh, "auth": auth,
                 "label": str(label or "")[:60], "added": time.time()}
        rows.append(entry)
        _save(rows[-MAX_SUBSCRIPTIONS:])
    return entry


def unsubscribe(endpoint: str) -> bool:
    with _lock:
        rows = subscriptions()
        kept = [r for r in rows if r.get("endpoint") != endpoint]
        _save(kept)
        return len(kept) != len(rows)


def describe() -> list[dict]:
    out = []
    for r in subscriptions():
        host = urlsplit(r["endpoint"]).hostname or ""
        service = ("Chrome / Android" if "google" in host else "Firefox" if "mozilla" in host
                   else "Safari / iPhone" if "apple" in host else "Edge" if "windows" in host else host)
        out.append({"id": hashlib.sha256(r["endpoint"].encode()).hexdigest()[:12],
                    "label": r.get("label") or service, "service": service, "added": r.get("added")})
    return out


def remove_by_id(sub_id: str) -> bool:
    for r in subscriptions():
        if hashlib.sha256(r["endpoint"].encode()).hexdigest()[:12] == sub_id:
            return unsubscribe(r["endpoint"])
    return False


# ---------------------------------------------------------------------------
# Sending
# ---------------------------------------------------------------------------

async def send(title: str, body: str, url: str = "/", tag: str = "", client=None) -> dict:
    """Send to every subscribed browser. Gone subscriptions are dropped."""
    import httpx
    rows = subscriptions()
    if not rows:
        return {"sent": 0, "failed": 0, "devices": 0}
    payload = json.dumps({"title": str(title)[:120], "body": str(body)[:1000],
                          "url": url if str(url).startswith("/") else "/", "tag": tag[:60]}).encode()
    if len(payload) > MAX_PAYLOAD:
        payload = payload[:MAX_PAYLOAD]
    subject = os.getenv("JARVIS_PUBLIC_URL") or "mailto:jarvis@localhost"
    owned = client is None
    client = client or httpx.AsyncClient(timeout=15.0)
    sent = failed = 0
    gone = []
    try:
        for r in rows:
            try:
                data = encrypt(payload, r["p256dh"], r["auth"])
                resp = await client.post(r["endpoint"], content=data, headers={
                    "Content-Encoding": "aes128gcm", "Content-Type": "application/octet-stream",
                    "TTL": "86400", "Urgency": "normal",
                    "Authorization": _vapid_header(r["endpoint"], subject)})
            except Exception as e:
                log.warning("push to %s failed: %s", urlsplit(r["endpoint"]).hostname, e)
                failed += 1
                continue
            if resp.status_code in (404, 410):
                gone.append(r["endpoint"])
            elif resp.status_code >= 400:
                log.warning("push service %s answered %s: %s", urlsplit(r["endpoint"]).hostname,
                            resp.status_code, resp.text[:200])
                failed += 1
            else:
                sent += 1
    finally:
        if owned:
            await client.aclose()
    for endpoint in gone:
        unsubscribe(endpoint)
    return {"sent": sent, "failed": failed, "devices": len(rows), "removed": len(gone)}
