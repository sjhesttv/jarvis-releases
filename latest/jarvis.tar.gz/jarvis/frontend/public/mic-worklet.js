// The microphone, as raw samples: an AudioWorklet that hands the main thread
// blocks of ~1024 mono float32 samples at the AudioContext's own rate.
// Served as a file of its own (not a blob: URL) so the page's script-src
// 'self' covers it. listen.ts does the rest.
class MicTap extends AudioWorkletProcessor {
  constructor() {
    super();
    this.buf = new Float32Array(1024);
    this.n = 0;
  }
  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (ch) {
      for (let i = 0; i < ch.length; i++) {
        this.buf[this.n++] = ch[i];
        if (this.n === this.buf.length) {
          this.port.postMessage(this.buf.slice(0));
          this.n = 0;
        }
      }
    }
    return true;
  }
}
registerProcessor("mic-tap", MicTap);
