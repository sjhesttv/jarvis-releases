/**
 * Signing in, from the page's side.
 *
 * When the owner has set a password (always, on a cloud server), the server
 * answers 401 with `x-jarvis-login: required` to any request without a valid
 * session, and closes a WebSocket before it opens. The fix in both cases is
 * the same: go to /login and come back here afterwards.
 *
 * Installed once, as a wrapper around `fetch`, so no call site has to know.
 */

let redirecting = false;

export function goToLogin(): void {
  if (redirecting) return;
  redirecting = true;
  const here = location.pathname + location.search;
  location.assign(`/login?next=${encodeURIComponent(here)}`);
}

function needsLogin(res: Response): boolean {
  return res.status === 401 && res.headers.get("x-jarvis-login") === "required";
}

const nativeFetch = window.fetch.bind(window);

window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
  const res = await nativeFetch(input, init);
  if (needsLogin(res)) goToLogin();
  return res;
};

/** A socket closed before it ever opened: is that because we are signed out? */
export async function checkSession(): Promise<void> {
  try {
    const res = await nativeFetch("/api/auth/status", { cache: "no-store" });
    if (needsLogin(res)) goToLogin();
  } catch {
    // The server is down, not us signed out; the socket's own retry handles it.
  }
}

/** Sign out of this browser. */
export async function signOut(): Promise<void> {
  await nativeFetch("/logout", { method: "POST" });
  goToLogin();
}
