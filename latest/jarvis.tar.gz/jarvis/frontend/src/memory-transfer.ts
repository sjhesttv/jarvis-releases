/**
 * Settings → Memory: download everything JARVIS remembers as one archive, and
 * load one back (for a new server). Talks to memory_archive.py through
 * GET /api/memory/export and POST /api/memory/import.
 *
 * createElement / textContent only.
 */

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
}

function check(label: string): { root: HTMLElement; box: HTMLInputElement } {
  const root = el("label", "memory-check");
  const box = document.createElement("input");
  box.type = "checkbox";
  root.append(box, document.createTextNode(" " + label));
  return { root, box };
}

interface ImportReport {
  added: number; replaced: number; kept: number; ignored: string[];
  settings: string[]; history_staged: boolean; backup: string; restart_needed: boolean;
}

export function renderMemoryTransfer(root: HTMLElement): void {
  root.replaceChildren();

  // -- export --------------------------------------------------------------
  const history = check("Include run history");
  const secrets = check("Include keys and connections (Fish, GitHub, MCP secrets)");
  const exportBtn = el("button", "settings-btn primary", "Download export");
  exportBtn.addEventListener("click", () => {
    const q = `history=${history.box.checked ? 1 : 0}&secrets=${secrets.box.checked ? 1 : 0}`;
    const a = document.createElement("a");
    a.href = `/api/memory/export?${q}`;
    a.download = "";
    document.body.appendChild(a);
    a.click();
    a.remove();
  });
  root.append(
    el("p", "settings-hint",
      "Everything JARVIS remembers — memories, project notes, the journal, your " +
      "persona edits and preferences — as one file. Keep it somewhere safe; with " +
      "keys included it is as sensitive as your passwords."),
    history.root, secrets.root,
    (() => { const d = el("div", "settings-actions"); d.append(exportBtn); return d; })());

  // -- import --------------------------------------------------------------
  const file = document.createElement("input");
  file.type = "file";
  file.accept = ".tar.gz,.tgz,application/gzip";
  file.className = "memory-file";
  const mode = document.createElement("select");
  for (const [value, label] of [["merge", "Merge: add what is missing, keep what is here"],
                                ["replace", "Replace: overwrite (current memory is backed up first)"]]) {
    const o = document.createElement("option");
    o.value = value;
    o.textContent = label;
    mode.append(o);
  }
  const importBtn = el("button", "settings-btn primary", "Import");
  const msg = el("p", "connectors-msg");
  importBtn.addEventListener("click", async () => {
    const chosen = file.files?.[0];
    if (!chosen) { msg.textContent = "Choose an export file first."; msg.className = "connectors-msg bad"; return; }
    importBtn.disabled = true;
    msg.className = "connectors-msg";
    msg.textContent = "Importing…";
    try {
      const res = await fetch(`/api/memory/import?mode=${mode.value}`, {
        method: "POST", headers: { "Content-Type": "application/gzip" }, body: chosen,
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error || `HTTP ${res.status}`);
      const r = body as ImportReport;
      const parts = [`${r.added} added`, `${r.replaced} replaced`, `${r.kept} kept`];
      if (r.settings.length) parts.push(`settings: ${r.settings.join(", ")}`);
      if (r.history_staged) parts.push("run history on next restart");
      if (r.ignored.length) parts.push(`${r.ignored.length} ignored`);
      msg.textContent = `Imported — ${parts.join("; ")}.` +
        (r.backup ? " The previous memory was backed up on the server." : "");
      if (r.restart_needed) {
        const restart = el("button", "settings-btn", "Restart now to finish");
        restart.addEventListener("click", async () => {
          restart.disabled = true;
          await fetch("/api/restart", { method: "POST" });
          setTimeout(() => location.reload(), 6000);
        });
        msg.append(document.createElement("br"), restart);
      }
    } catch (e) {
      msg.className = "connectors-msg bad";
      msg.textContent = e instanceof Error ? e.message : "The import failed.";
    } finally {
      importBtn.disabled = false;
    }
  });
  const field = el("div", "settings-field");
  field.append(el("label", undefined, "Import an export"), file);
  const modeField = el("div", "settings-field");
  modeField.append(el("label", undefined, "How"), mode);
  const actions = el("div", "settings-actions");
  actions.append(importBtn);
  root.append(field, modeField, actions, msg);
}
