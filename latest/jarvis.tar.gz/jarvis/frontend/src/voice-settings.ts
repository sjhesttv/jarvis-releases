/**
 * Settings → Voice: how JARVIS speaks and listens.
 *
 *   Speaking   local (Kokoro, on the server) or Fish Audio; auto prefers local.
 *   Voice      a Kokoro voice, or a blend of up to four (the style vectors
 *              are mixed — "bm_george:0.7,bm_lewis:0.3"), and a speed.
 *   Listening  on the server (Whisper; every browser) or the browser's own
 *              recogniser (Chrome only, via Google).
 *
 * Saved through POST /api/voice/settings, which applies it at once.
 * createElement / textContent only.
 */

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
}

interface VoiceConfig {
  listen: string; listen_setting: string; speak: string; speak_setting: string;
  voice: string; speed: number; fish: boolean;
  local: { up: boolean; ready: Record<string, boolean>; errors: Record<string, string>; stt_model: string };
}

// Kokoro's voices, by accent. The British ones first: he is a butler.
const VOICE_NAMES: Record<string, string> = {
  bm_george: "George (British)", bm_lewis: "Lewis (British)", bm_daniel: "Daniel (British)",
  bm_fable: "Fable (British)", bf_emma: "Emma (British)", bf_isabella: "Isabella (British)",
  bf_alice: "Alice (British)", bf_lily: "Lily (British)", am_michael: "Michael (American)",
  am_adam: "Adam (American)", am_onyx: "Onyx (American)", am_fenrir: "Fenrir (American)",
  am_puck: "Puck (American)", af_heart: "Heart (American)", af_bella: "Bella (American)",
};

function select(options: [string, string][], value: string): HTMLSelectElement {
  const s = el("select");
  for (const [v, label] of options) {
    const o = el("option", undefined, label);
    o.value = v;
    s.append(o);
  }
  s.value = value;
  return s;
}

function field(label: string, control: HTMLElement, hint?: string): HTMLElement {
  const f = el("div", "settings-field");
  f.append(el("label", undefined, label), control);
  if (hint) f.append(el("p", "settings-hint", hint));
  return f;
}

export async function renderVoiceSettings(root: HTMLElement): Promise<void> {
  root.replaceChildren(el("p", "settings-hint", "Loading…"));
  let cfg: VoiceConfig;
  let names: string[] = [];
  try {
    cfg = await (await fetch("/api/voice/config")).json();
    names = ((await (await fetch("/api/voice/voices")).json()).voices ?? []) as string[];
  } catch {
    root.replaceChildren(el("p", "settings-hint", "Could not read the voice settings."));
    return;
  }
  root.replaceChildren();

  const ready = cfg.local.ready || {};
  const state = !cfg.local.up
    ? "The local voice service is not running on the server (sudo systemctl status jarvis-ml)."
    : `Local models: voice ${ready.tts ? "ready" : "loading"}, listening ${ready.stt ? `ready (${cfg.local.stt_model})` : "loading"}, memory search ${ready.embed ? "ready" : "loading"}.`;
  root.append(el("p", "settings-hint", state));
  for (const [k, v] of Object.entries(cfg.local.errors || {})) {
    root.append(el("p", "settings-hint", `${k}: ${v}`));
  }

  const speak = select([["auto", "Automatic (local when it is running)"], ["local", "Local voice (Kokoro, on this server)"],
    ["fish", "Fish Audio" + (cfg.fish ? "" : " — no key set")]], cfg.speak_setting);
  root.append(field("Speaking", speak, `In use now: ${cfg.speak === "local" ? "local voice" : "Fish Audio"}.`));

  // A blend is "name:weight,name:weight"; the first two are editable here.
  const parts = cfg.voice.split(",").map((p) => p.split(":"));
  const known = names.length ? names : Object.keys(VOICE_NAMES);
  const opts: [string, string][] = known.map((n) => [n, VOICE_NAMES[n] ?? n]);
  const v1 = select(opts, parts[0]?.[0] ?? "bm_george");
  const v2 = select([["", "— none —"], ...opts], parts[1]?.[0] ?? "");
  const mix = el("input") as HTMLInputElement;
  mix.type = "range"; mix.min = "0"; mix.max = "100"; mix.step = "5";
  mix.value = String(Math.round(100 * Number(parts[1]?.[1] ?? 0.3)));
  const mixLabel = el("span", "settings-hint");
  const showMix = () => {
    mix.disabled = !v2.value;
    mixLabel.textContent = v2.value ? `${100 - Number(mix.value)}% / ${mix.value}%` : "";
  };
  mix.addEventListener("input", showMix);
  v2.addEventListener("change", showMix);
  showMix();
  const blendRow = el("div", "settings-input-row");
  blendRow.append(v1, v2);
  const mixRow = el("div", "settings-input-row");
  mixRow.append(mix, mixLabel);
  root.append(field("Voice", blendRow, "Blend two voices to make one of his own."), field("Blend", mixRow));

  const speed = el("input") as HTMLInputElement;
  speed.type = "range"; speed.min = "0.8"; speed.max = "1.3"; speed.step = "0.05";
  speed.value = String(cfg.speed);
  const speedLabel = el("span", "settings-hint", `${cfg.speed.toFixed(2)}×`);
  speed.addEventListener("input", () => { speedLabel.textContent = `${Number(speed.value).toFixed(2)}×`; });
  const speedRow = el("div", "settings-input-row");
  speedRow.append(speed, speedLabel);
  root.append(field("Speed", speedRow));

  const listen = select([["auto", "Automatic (on the server when it is running)"],
    ["server", "On the server (Whisper) — every browser, stays private"],
    ["browser", "The browser's own (Chrome only; sent to Google)"]], cfg.listen_setting);
  root.append(field("Listening", listen, `In use now: ${cfg.listen === "server" ? "on the server" : "the browser's own"}. A change takes effect when the page is reloaded.`));

  const voiceSpec = () => {
    if (!v2.value || v2.value === v1.value) return v1.value;
    const w2 = Number(mix.value) / 100;
    return `${v1.value}:${(1 - w2).toFixed(2)},${v2.value}:${w2.toFixed(2)}`;
  };

  const msg = el("p", "connectors-msg");
  const hear = el("button", "settings-btn", "Hear it");
  hear.addEventListener("click", async () => {
    hear.disabled = true;
    msg.className = "connectors-msg";
    msg.textContent = "Speaking…";
    try {
      const res = await fetch("/api/voice/preview", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ voice: voiceSpec(), speed: Number(speed.value) }),
      });
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`);
      const url = URL.createObjectURL(await res.blob());
      const audio = new Audio(url);
      audio.addEventListener("ended", () => URL.revokeObjectURL(url));
      await audio.play();
      msg.textContent = "";
    } catch (e) {
      msg.className = "connectors-msg bad";
      msg.textContent = e instanceof Error ? e.message : "That did not work.";
    } finally {
      hear.disabled = false;
    }
  });
  const save = el("button", "settings-btn primary", "Save voice");
  save.addEventListener("click", async () => {
    save.disabled = true;
    try {
      const res = await fetch("/api/voice/settings", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ speak: speak.value, voice: voiceSpec(), speed: Number(speed.value), listen: listen.value }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
      msg.className = "connectors-msg";
      msg.textContent = "Saved. His next sentence uses it.";
    } catch (e) {
      msg.className = "connectors-msg bad";
      msg.textContent = e instanceof Error ? e.message : "That did not save.";
    } finally {
      save.disabled = false;
    }
  });
  const actions = el("div", "settings-actions connectors-actions");
  actions.append(hear, save);
  root.append(actions, msg);
}
