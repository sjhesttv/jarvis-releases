/**
 * Settings → Voice: how JARVIS speaks and listens.
 *
 *   Speaking   local (on the server) or Fish Audio; auto prefers local.
 *   Voice      his own Piper voice ("piper:jarvis", made with
 *              voice_training/ and uploaded below), or a Kokoro voice or a
 *              blend of two, and a speed. A Piper voice also has two
 *              variation settings (Piper's noise_scale and noise_w).
 *   Listening  on the server (Whisper; every browser) or the browser's own
 *              recogniser (Chrome only, via Google).
 *
 * Saved through POST /api/voice/settings, which applies it at once.
 * Uploads go to PUT /api/voice/piper/<name>/{model,config} and then
 * /activate, which the voice service only accepts once the pair speaks.
 * createElement / textContent only.
 */

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
}

interface VoiceConfig {
  listen: string; listen_setting: string; speak: string; speak_setting: string;
  voice: string; speed: number; fish: boolean;
  piper_noise: number | null; piper_noise_w: number | null;
  local: {
    up: boolean; ready: Record<string, boolean>; errors: Record<string, string>; stt_model: string;
    kokoro: boolean; piper: string[];
  };
}

// Kokoro's voices, by accent. The British ones first: he is a butler.
const VOICE_NAMES: Record<string, string> = {
  bm_george: "George (British)", bm_lewis: "Lewis (British)", bm_daniel: "Daniel (British)",
  bm_fable: "Fable (British)", bf_emma: "Emma (British)", bf_isabella: "Isabella (British)",
  bf_alice: "Alice (British)", bf_lily: "Lily (British)", am_michael: "Michael (American)",
  am_adam: "Adam (American)", am_onyx: "Onyx (American)", am_fenrir: "Fenrir (American)",
  am_puck: "Puck (American)", af_heart: "Heart (American)", af_bella: "Bella (American)",
};

const PIPER_NOISE_DEFAULT = 0.667;
const PIPER_NOISE_W_DEFAULT = 0.8;

function piperLabel(name: string): string {
  return name === "jarvis" ? "JARVIS — your own voice" : `${name} — your own voice`;
}

function select(options: [string, string][], value: string): HTMLSelectElement {
  const s = el("select");
  for (const [v, label] of options) {
    const o = el("option", undefined, label);
    o.value = v;
    s.append(o);
  }
  s.value = value;
  if (s.value !== value && options.length) s.value = options[0][0];
  return s;
}

function field(label: string, control: HTMLElement, hint?: string): HTMLElement {
  const f = el("div", "settings-field");
  f.append(el("label", undefined, label), control);
  if (hint) f.append(el("p", "settings-hint", hint));
  return f;
}

function slider(min: number, max: number, step: number, value: number, fmt: (v: number) => string) {
  const input = el("input") as HTMLInputElement;
  input.type = "range"; input.min = String(min); input.max = String(max); input.step = String(step);
  input.value = String(value);
  const label = el("span", "settings-hint", fmt(value));
  input.addEventListener("input", () => { label.textContent = fmt(Number(input.value)); });
  const row = el("div", "settings-input-row");
  row.append(input, label);
  return { input, row };
}

/** PUT one file with progress (fetch has no upload progress). */
function putFile(url: string, file: File, onProgress: (pct: number) => void): Promise<void> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("PUT", url);
    xhr.setRequestHeader("Content-Type", "application/octet-stream");
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(Math.round((100 * e.loaded) / e.total)); };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) return resolve();
      let msg = `HTTP ${xhr.status}`;
      try { msg = JSON.parse(xhr.responseText).error || msg; } catch { /* not JSON */ }
      reject(new Error(msg));
    };
    xhr.onerror = () => reject(new Error("The upload was interrupted."));
    xhr.send(file);
  });
}

async function postJson(url: string, body?: unknown): Promise<any> {
  const res = await fetch(url, {
    method: "POST", headers: body ? { "Content-Type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

function uploadBlock(root: HTMLElement, cfg: VoiceConfig): HTMLElement {
  const box = el("div", "settings-field");
  box.append(el("label", undefined, "Your own voice (Piper)"));
  box.append(el("p", "settings-hint",
    "Choose both files the training produced: jarvis.onnx and jarvis.onnx.json. " +
    "They are checked by having the voice speak a sentence before anything is replaced."));
  const files = el("input") as HTMLInputElement;
  files.type = "file";
  files.multiple = true;
  files.accept = ".onnx,.json";
  const name = el("input") as HTMLInputElement;
  name.type = "text";
  name.value = "jarvis";
  name.placeholder = "jarvis";
  name.setAttribute("aria-label", "Voice name");
  const go = el("button", "settings-btn primary", "Upload");
  const row = el("div", "settings-input-row");
  row.append(name, go);
  const msg = el("p", "connectors-msg");
  box.append(files, row, msg);

  files.addEventListener("change", () => {
    const onnx = Array.from(files.files ?? []).find((f) => f.name.endsWith(".onnx"));
    if (onnx) name.value = onnx.name.replace(/\.onnx$/, "").toLowerCase().replace(/[^a-z0-9_-]+/g, "-").slice(0, 40) || "jarvis";
  });

  go.addEventListener("click", async () => {
    const picked = Array.from(files.files ?? []);
    const model = picked.find((f) => f.name.endsWith(".onnx"));
    const config = picked.find((f) => f.name.endsWith(".json"));
    msg.className = "connectors-msg";
    if (!model || !config) {
      msg.className = "connectors-msg bad";
      msg.textContent = "Choose both files: the .onnx and the .onnx.json (hold ⌘ to pick two).";
      return;
    }
    const n = name.value.trim().toLowerCase();
    if (!/^[a-z0-9][a-z0-9_-]{0,39}$/.test(n)) {
      msg.className = "connectors-msg bad";
      msg.textContent = "A voice name is lowercase letters, digits, - or _ (like jarvis).";
      return;
    }
    go.disabled = true;
    try {
      const base = `/api/voice/piper/${encodeURIComponent(n)}`;
      await putFile(`${base}/model`, model, (p) => { msg.textContent = `Uploading the voice… ${p}%`; });
      msg.textContent = "Uploading its settings…";
      await putFile(`${base}/config`, config, () => undefined);
      msg.textContent = "Checking it speaks…";
      const r = await postJson(`${base}/activate`);
      await postJson("/api/voice/settings", { voice: r.installed, speak: cfg.speak_setting === "fish" ? "auto" : cfg.speak_setting });
      msg.textContent = `Installed. He speaks with ${piperLabel(n)} from his next sentence.`;
      setTimeout(() => void renderVoiceSettings(root), 1500);
    } catch (e) {
      msg.className = "connectors-msg bad";
      msg.textContent = e instanceof Error ? e.message : "The upload did not work.";
    } finally {
      go.disabled = false;
    }
  });
  return box;
}

export async function renderVoiceSettings(root: HTMLElement): Promise<void> {
  root.replaceChildren(el("p", "settings-hint", "Loading…"));
  let cfg: VoiceConfig;
  let names: string[] = [];
  let pipers: string[] = [];
  try {
    cfg = await (await fetch("/api/voice/config")).json();
    const v = await (await fetch("/api/voice/voices")).json();
    names = (v.voices ?? []) as string[];
    pipers = (v.piper ?? cfg.local.piper ?? []) as string[];
  } catch {
    root.replaceChildren(el("p", "settings-hint", "Could not read the voice settings."));
    return;
  }
  root.replaceChildren();

  const ready = cfg.local.ready || {};
  const state = !cfg.local.up
    ? "The local voice service is not running on the server (sudo systemctl status jarvis-ml)."
    : `Local models: voice ${ready.tts ? "ready" : "loading"}, listening ${ready.stt ? `ready (${cfg.local.stt_model})` : "loading"}, memory search ${ready.embed ? "ready" : "loading"}.`;
  root.append(el("p", "settings-hint", state));
  for (const [k, v] of Object.entries(cfg.local.errors || {})) {
    if (k === "tts" && pipers.length) continue;          // Kokoro missing does not matter with his own voice
    root.append(el("p", "settings-hint", `${k}: ${v}`));
  }

  const speak = select([["auto", "Automatic (local when it is running)"], ["local", "Local voice (on this server)"],
    ["fish", "Fish Audio" + (cfg.fish ? "" : " — no key set")]], cfg.speak_setting);
  root.append(field("Speaking", speak, `In use now: ${cfg.speak === "local" ? "local voice" : "Fish Audio"}.`));

  // His own voices first, then Kokoro's. A Kokoro blend is "a:w,b:w".
  const parts = cfg.voice.split(",").map((p) => p.split(":"));
  const isPiper = cfg.voice.startsWith("piper:");
  const kokoro = names.length ? names : (cfg.local.kokoro ? Object.keys(VOICE_NAMES) : []);
  const opts: [string, string][] = [
    ...pipers.map((n): [string, string] => [`piper:${n}`, piperLabel(n)]),
    ...kokoro.map((n): [string, string] => [n, VOICE_NAMES[n] ?? n]),
  ];
  if (!opts.length) opts.push(["bm_george", VOICE_NAMES.bm_george]);
  const v1 = select(opts, isPiper ? cfg.voice : (parts[0]?.[0] ?? "bm_george"));
  const v2 = select([["", "— none —"], ...kokoro.map((n): [string, string] => [n, VOICE_NAMES[n] ?? n])],
    isPiper ? "" : (parts[1]?.[0] ?? ""));
  const mix = slider(0, 100, 5, Math.round(100 * Number(isPiper ? 0.3 : (parts[1]?.[1] ?? 0.3))),
    (v) => `${100 - v}% / ${v}%`);
  const voiceRow = el("div", "settings-input-row");
  voiceRow.append(v1, v2);
  const blendField = field("Blend", mix.row, "Blend two Kokoro voices to make one of his own.");

  const noise = slider(0, 1, 0.05, cfg.piper_noise ?? PIPER_NOISE_DEFAULT, (v) => v.toFixed(2));
  const noiseW = slider(0, 1, 0.05, cfg.piper_noise_w ?? PIPER_NOISE_W_DEFAULT, (v) => v.toFixed(2));
  const piperFields = el("div");
  piperFields.append(
    field("Variation", noise.row, "How much his tone varies. Lower is steadier and flatter; Piper's default is 0.67."),
    field("Timing variation", noiseW.row, "How much his rhythm varies. Lower is more even; the default is 0.80."),
  );

  const showVoice = () => {
    const piper = v1.value.startsWith("piper:");
    v2.hidden = piper;
    blendField.hidden = piper || !v2.value;
    piperFields.hidden = !piper;
  };
  v1.addEventListener("change", showVoice);
  v2.addEventListener("change", showVoice);
  root.append(field("Voice", voiceRow), blendField, piperFields);
  showVoice();

  const speed = slider(0.8, 1.3, 0.05, cfg.speed, (v) => `${v.toFixed(2)}×`);
  root.append(field("Speed", speed.row));

  const listen = select([["auto", "Automatic (on the server when it is running)"],
    ["server", "On the server (Whisper) — every browser, stays private"],
    ["browser", "The browser's own (Chrome only; sent to Google)"]], cfg.listen_setting);
  root.append(field("Listening", listen, `In use now: ${cfg.listen === "server" ? "on the server" : "the browser's own"}. A change takes effect when the page is reloaded.`));

  const voiceSpec = () => {
    if (v1.value.startsWith("piper:")) return v1.value;
    if (!v2.value || v2.value === v1.value) return v1.value;
    const w2 = Number(mix.input.value) / 100;
    return `${v1.value}:${(1 - w2).toFixed(2)},${v2.value}:${w2.toFixed(2)}`;
  };
  const piperExtras = () => v1.value.startsWith("piper:")
    ? { piper_noise: Number(noise.input.value), piper_noise_w: Number(noiseW.input.value) } : {};

  const msg = el("p", "connectors-msg");
  const hear = el("button", "settings-btn", "Hear it");
  hear.addEventListener("click", async () => {
    hear.disabled = true;
    msg.className = "connectors-msg";
    msg.textContent = "Speaking…";
    try {
      const res = await fetch("/api/voice/preview", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ voice: voiceSpec(), speed: Number(speed.input.value), ...piperExtras() }),
      });
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`);
      const url = URL.createObjectURL(await res.blob());
      const audio = new Audio(url);
      audio.addEventListener("ended", () => URL.revokeObjectURL(url));
      await audio.play();
      msg.textContent = "";
    } catch (e) {
      msg.className = "connectors-msg bad";
      msg.textContent = e instanceof Error ? e.message : "That did not work.";
    } finally {
      hear.disabled = false;
    }
  });
  const save = el("button", "settings-btn primary", "Save voice");
  save.addEventListener("click", async () => {
    save.disabled = true;
    try {
      await postJson("/api/voice/settings", {
        speak: speak.value, voice: voiceSpec(), speed: Number(speed.input.value), listen: listen.value,
        ...piperExtras(),
      });
      msg.className = "connectors-msg";
      msg.textContent = "Saved. His next sentence uses it.";
    } catch (e) {
      msg.className = "connectors-msg bad";
      msg.textContent = e instanceof Error ? e.message : "That did not save.";
    } finally {
      save.disabled = false;
    }
  });
  const actions = el("div", "settings-actions connectors-actions");
  actions.append(hear, save);
  root.append(actions, msg);

  // Your own voices: upload, and remove.
  if (cfg.local.up) {
    for (const n of pipers) {
      const remove = el("button", "settings-btn", "Remove");
      remove.addEventListener("click", async () => {
        remove.disabled = true;
        const res = await fetch(`/api/voice/piper/${encodeURIComponent(n)}`, { method: "DELETE" });
        if (!res.ok) {
          msg.className = "connectors-msg bad";
          msg.textContent = (await res.json().catch(() => ({}))).error || "Only an uploaded voice can be removed here.";
          remove.disabled = false;
          return;
        }
        void renderVoiceSettings(root);
      });
      const r = el("div", "connectors-row");
      const text = el("div", "connectors-row-text");
      text.append(el("div", "connectors-row-name", piperLabel(n)), el("div", "connectors-row-detail", `piper:${n}`));
      r.append(el("span", "status-dot status-green"), text, remove);
      root.append(r);
    }
    root.append(uploadBlock(root, cfg));
  }
}
