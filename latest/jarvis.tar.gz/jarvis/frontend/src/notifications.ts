/**
 * Settings → Notifications: let this browser receive JARVIS's pushes
 * (scheduled jobs, "tell me when…", "send that to my phone").
 *
 * Registers /sw.js, asks for permission, subscribes with the server's VAPID
 * key and hands the subscription to /api/push/subscribe. Lists every device
 * that is signed up, with Remove, and sends a test.
 *
 * On an iPhone or iPad, Safari only offers push once JARVIS has been added
 * to the Home Screen and opened from there; the section says so.
 *
 * createElement / textContent only.
 */

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
}

function b64ToBytes(b64: string): Uint8Array<ArrayBuffer> {
  const pad = "=".repeat((4 - (b64.length % 4)) % 4);
  const raw = atob((b64 + pad).replace(/-/g, "+").replace(/_/g, "/"));
  const out = new Uint8Array(new ArrayBuffer(raw.length));
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}

const isIOS = () => /iPad|iPhone|iPod/.test(navigator.userAgent) ||
  (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
const isStandalone = () => window.matchMedia("(display-mode: standalone)").matches ||
  (navigator as unknown as { standalone?: boolean }).standalone === true;

function deviceLabel(): string {
  const ua = navigator.userAgent;
  const browser = /Firefox\//.test(ua) ? "Firefox" : /Edg\//.test(ua) ? "Edge"
    : /Chrome\//.test(ua) ? "Chrome" : /Safari\//.test(ua) ? "Safari" : "Browser";
  const os = /iPhone|iPad/.test(ua) ? "iPhone/iPad" : /Android/.test(ua) ? "Android"
    : /Mac OS X/.test(ua) ? "Mac" : /Windows/.test(ua) ? "Windows" : /Linux/.test(ua) ? "Linux" : "";
  return os ? `${browser} on ${os}` : browser;
}

interface Device { id: string; label: string; service: string; added: number }

async function json(method: string, url: string, body?: unknown): Promise<any> {
  const res = await fetch(url, {
    method, headers: body ? { "Content-Type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

export async function renderNotifications(root: HTMLElement): Promise<void> {
  root.replaceChildren();
  const msg = el("p", "connectors-msg");
  const supported = "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;

  if (!supported) {
    root.append(el("p", "settings-hint", isIOS() && !isStandalone()
      ? "On iPhone and iPad: tap Share, then Add to Home Screen, and open JARVIS from the Home Screen. Notifications can be turned on from there."
      : "This browser can't receive notifications."));
  } else {
    const enable = el("button", "settings-btn primary", "Turn on notifications here");
    enable.addEventListener("click", async () => {
      enable.disabled = true;
      msg.className = "connectors-msg";
      msg.textContent = "Asking…";
      try {
        const permission = await Notification.requestPermission();
        if (permission !== "granted") throw new Error("Notifications were not allowed in this browser.");
        const reg = await navigator.serviceWorker.register("/sw.js", { scope: "/" });
        await navigator.serviceWorker.ready;
        const { key } = await json("GET", "/api/push/key");
        const existing = await reg.pushManager.getSubscription();
        const sub = existing ?? await reg.pushManager.subscribe({
          userVisibleOnly: true, applicationServerKey: b64ToBytes(key),
        });
        await json("POST", "/api/push/subscribe", { subscription: sub.toJSON(), label: deviceLabel() });
        msg.textContent = "On. JARVIS can reach this device now.";
        void renderNotifications(root);
      } catch (e) {
        msg.className = "connectors-msg bad";
        msg.textContent = e instanceof Error ? e.message : "That did not work.";
      } finally {
        enable.disabled = false;
      }
    });
    const test = el("button", "settings-btn", "Send a test");
    test.addEventListener("click", async () => {
      try {
        const r = await json("POST", "/api/push/test");
        msg.className = "connectors-msg";
        msg.textContent = r.devices ? `Sent to ${r.sent} of ${r.devices} devices.` : "No device is signed up yet.";
      } catch (e) {
        msg.className = "connectors-msg bad";
        msg.textContent = e instanceof Error ? e.message : "The test failed.";
      }
    });
    const actions = el("div", "settings-actions connectors-actions");
    actions.append(test, enable);
    root.append(el("p", "settings-hint",
      "For scheduled jobs and anything JARVIS needs to tell you when no JARVIS page is open. Turn it on once on each phone or computer."));
    if (isIOS() && !isStandalone()) {
      root.append(el("p", "settings-hint",
        "On iPhone and iPad, add JARVIS to the Home Screen first (Share → Add to Home Screen) and open it from there."));
    }
    root.append(actions);
  }

  try {
    const { devices } = await json("GET", "/api/push/devices") as { devices: Device[] };
    const list = el("div", "connectors-list");
    for (const d of devices) {
      const remove = el("button", "settings-btn", "Remove");
      remove.addEventListener("click", async () => {
        await json("DELETE", `/api/push/devices/${encodeURIComponent(d.id)}`).catch(() => undefined);
        void renderNotifications(root);
      });
      const text = el("div", "connectors-row-text");
      text.append(el("div", "connectors-row-name", d.label),
        el("div", "connectors-row-detail", `${d.service} · added ${new Date(d.added * 1000).toLocaleDateString()}`));
      const row = el("div", "connectors-row");
      row.append(el("span", "status-dot status-green"), text, remove);
      list.append(row);
    }
    if (devices.length) root.append(list);
  } catch {
    // no list, no harm
  }
  root.append(msg);
}
