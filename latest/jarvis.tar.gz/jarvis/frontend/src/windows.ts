/**
 * Windows on the voice page — JARVIS's, not the user's.
 *
 * The server (window_manager.py) decides what is open and where; this file
 * only draws it. Messages:
 *
 *   {"type":"window","action":"open",   id, kind, title, url, position, size, name?, source?, z}
 *   {"type":"window","action":"place",  id, position, size, z}
 *   {"type":"window","action":"focus",  id, z}
 *   {"type":"window","action":"update", id, url}       a refreshed web view
 *   {"type":"window","action":"close",  id}
 *
 * A layout is words ("left", "medium"); it becomes a rectangle here, for this
 * viewport, inside a safe area that keeps clear of the controls above and
 * the caption bar below, and is recomputed when the window is resized. Every
 * change animates: windows rise in, glide between places, and fade out.
 *
 * There are no handles to drag or resize. A faint × (and a download button)
 * shows on hover, for the rare window the user wants gone; closing one tells
 * the server so JARVIS's own list stays true.
 *
 * Kinds: image · markdown (the dashboard's createElement renderer) · text ·
 * html (fetched as TEXT and rendered in an iframe sandboxed to allow-scripts
 * only — an opaque origin that cannot reach this page, its cookies or the
 * API) · page (a picture of a web page, refreshed by JARVIS) · download.
 *
 * createElement / textContent throughout.
 */

import { markdown } from "./dashboard/markdown";

export interface WindowSpec {
  id?: string;
  kind: string;
  title: string;
  url: string;
  position?: string;
  size?: string;
  name?: string;
  source?: string;
  z?: number;
}

const TEXT_LIMIT = 400_000;
const LEAVE_MS = 320;
const SIZES: Record<string, [number, number]> = {
  small: [0.34, 0.42], medium: [0.48, 0.6], large: [0.68, 0.82], full: [1, 1],
};

interface Live { root: HTMLElement; body: HTMLElement; spec: WindowSpec }

const live = new Map<string, Live>();
let layer: HTMLElement | null = null;
let report: ((id: string) => void) | null = null;
let localCount = 0;
let topZ = 30;

/** How the page tells the server the user closed a window. */
export function onUserClose(fn: (id: string) => void): void {
  report = fn;
}

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
}

function ensureLayer(): HTMLElement {
  if (!layer) {
    layer = el("div");
    layer.id = "window-layer";
    document.body.appendChild(layer);
    window.addEventListener("resize", () => {
      for (const w of live.values()) placeNow(w);
    });
  }
  return layer;
}

/** The rectangle for a layout, inside the safe area of this viewport. */
function rect(position = "center", size = "medium") {
  const left = 16, top = 64;
  const W = Math.max(280, window.innerWidth - 32);
  const H = Math.max(200, window.innerHeight - 64 - 140);
  if (position === "full") size = "full";
  const [fw, fh] = SIZES[size] ?? SIZES.medium;
  const w = Math.max(260, Math.round(W * fw));
  const h = Math.max(160, Math.round(H * fh));
  const cx = left + (W - w) / 2, cy = top + (H - h) / 2;
  const x = { left, right: left + W - w, center: cx }[
    position.includes("left") ? "left" : position.includes("right") ? "right" : "center"];
  const y = { top, bottom: top + H - h, center: cy }[
    position.startsWith("top") ? "top" : position.startsWith("bottom") ? "bottom" : "center"];
  return { x: Math.round(x), y: Math.round(y), w, h };
}

function placeNow(w: Live): void {
  const r = rect(w.spec.position, w.spec.size);
  Object.assign(w.root.style, {
    left: `${r.x}px`, top: `${r.y}px`, width: `${r.w}px`, height: `${r.h}px`,
  });
  w.root.classList.toggle("jw--full", w.spec.position === "full" || w.spec.size === "full");
}

async function fill(body: HTMLElement, spec: WindowSpec): Promise<void> {
  if (spec.kind === "image" || spec.kind === "page") {
    const img = el("img", "jw-img");
    img.alt = spec.title;
    img.decoding = "async";
    img.src = spec.url;
    // Swap only once the new picture has loaded, so a refresh never flashes.
    await img.decode().catch(() => undefined);
    body.replaceChildren(img);
    return;
  }
  if (spec.kind === "download") {
    const a = el("a", "jw-link", "Download this file");
    a.href = `${spec.url}?download=1`;
    a.setAttribute("download", spec.name ?? "");
    body.replaceChildren(el("p", "jw-note", "This kind of file can't be shown here."), a);
    return;
  }
  body.replaceChildren(el("p", "jw-note", "Loading…"));
  let text: string;
  try {
    const res = await fetch(spec.url, { cache: "no-store" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    text = (await res.text()).slice(0, TEXT_LIMIT);
  } catch {
    body.replaceChildren(el("p", "jw-note", "Could not load it."));
    return;
  }
  if (spec.kind === "markdown") {
    body.replaceChildren(markdown(text, "md jw-md"));
  } else if (spec.kind === "html") {
    const frame = el("iframe", "jw-frame");
    // allow-scripts, and deliberately NOT allow-same-origin: see the header.
    frame.setAttribute("sandbox", "allow-scripts");
    frame.setAttribute("referrerpolicy", "no-referrer");
    frame.srcdoc = text;
    body.replaceChildren(frame);
  } else {
    body.replaceChildren(el("pre", "jw-pre", text));
  }
}

function hostOf(url: string): string {
  try { return new URL(url).host; } catch { return url; }
}

function build(id: string, spec: WindowSpec): Live {
  const root = el("section", `jw jw--${spec.kind} jw-enter`);
  root.setAttribute("role", "dialog");
  root.setAttribute("aria-label", spec.title);
  root.dataset.id = id;
  const bar = el("header", "jw-bar");
  const title = el("span", "jw-title", spec.title);
  const meta = el("span", "jw-meta", spec.kind === "page" && spec.source ? hostOf(spec.source) : "");
  const actions = el("span", "jw-actions");
  if (spec.kind !== "download") {
    const dl = el("a", "jw-btn", "⤓");
    dl.title = "Download";
    dl.href = `${spec.url}?download=1`;
    dl.setAttribute("download", spec.name ?? "");
    actions.append(dl);
  }
  const close = el("button", "jw-btn", "×");
  close.type = "button";
  close.title = "Close";
  close.addEventListener("click", () => {
    closeWindow(id);
    if (!id.startsWith("local-")) report?.(id);
  });
  actions.append(close);
  bar.append(title, meta, actions);
  const body = el("div", "jw-body");
  root.append(bar, body);
  return { root, body, spec };
}

export function openWindow(spec: WindowSpec): string {
  const id = spec.id ?? `local-${++localCount}`;
  const existing = live.get(id);
  if (existing) {
    existing.spec = { ...existing.spec, ...spec };
    placeNow(existing);
    void fill(existing.body, existing.spec);
    return id;
  }
  const w = build(id, { position: "center", size: "large", ...spec });
  live.set(id, w);
  w.root.style.zIndex = String(spec.z ? 30 + spec.z : ++topZ);
  topZ = Math.max(topZ, Number(w.root.style.zIndex));
  placeNow(w);
  ensureLayer().append(w.root);
  // Two frames: the browser must paint the entering state before it can
  // transition out of it.
  requestAnimationFrame(() => requestAnimationFrame(() => w.root.classList.remove("jw-enter")));
  void fill(w.body, w.spec);
  return id;
}

export function placeWindow(id: string, position?: string, size?: string, z?: number): void {
  const w = live.get(id);
  if (!w) return;
  if (position) w.spec.position = position;
  if (size) w.spec.size = size;
  if (z) w.root.style.zIndex = String(30 + z);
  placeNow(w);
}

export function focusWindow(id: string, z?: number): void {
  const w = live.get(id);
  if (!w) return;
  w.root.style.zIndex = String(z ? 30 + z : ++topZ);
  w.root.classList.remove("jw-pulse");
  void w.root.offsetWidth;            // restart the animation
  w.root.classList.add("jw-pulse");
}

export function updateWindow(id: string, url: string): void {
  const w = live.get(id);
  if (!w) return;
  w.spec.url = url;
  void fill(w.body, w.spec);
}

export function closeWindow(id: string): void {
  const w = live.get(id);
  if (!w) return;
  live.delete(id);
  w.root.classList.add("jw-leave");
  window.setTimeout(() => w.root.remove(), LEAVE_MS);
}

/** One server message. */
export function handleWindowMessage(msg: Record<string, unknown>): void {
  const id = String(msg.id ?? "");
  const action = String(msg.action ?? "open");
  const url = String(msg.url ?? "");
  const safeUrl = (u: string) => /^\/api\/(files|uploads|views)\//.test(u);
  if (action === "open" && id && safeUrl(url)) {
    openWindow({
      id, url, kind: String(msg.kind ?? "download"), title: String(msg.title ?? "JARVIS"),
      position: String(msg.position ?? "center"), size: String(msg.size ?? "large"),
      name: msg.name ? String(msg.name) : undefined,
      source: msg.source ? String(msg.source) : undefined, z: Number(msg.z ?? 0),
    });
  } else if (action === "place") {
    placeWindow(id, msg.position ? String(msg.position) : undefined,
      msg.size ? String(msg.size) : undefined, Number(msg.z ?? 0));
  } else if (action === "focus") {
    focusWindow(id, Number(msg.z ?? 0));
  } else if (action === "update" && safeUrl(url)) {
    updateWindow(id, url);
  } else if (action === "close") {
    closeWindow(id);
  }
}

/** The window kind for a file name, mirroring server._window_kind. */
export function kindFor(name: string): string {
  const ext = (name.match(/\.[a-z0-9]+$/i)?.[0] ?? "").toLowerCase();
  if ([".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg"].includes(ext)) return "image";
  if ([".md", ".markdown"].includes(ext)) return "markdown";
  if ([".html", ".htm"].includes(ext)) return "html";
  if ([".txt", ".csv", ".json", ".py", ".js", ".ts", ".sh", ".yaml", ".yml", ".toml",
       ".xml", ".sql", ".log", ".css"].includes(ext)) return "text";
  return "download";
}
