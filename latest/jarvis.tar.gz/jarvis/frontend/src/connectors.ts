/**
 * The Connections section of the settings panel: GitHub, and the owner's own
 * MCP servers (connections.json). Talks to /api/connectors (connectors.py).
 *
 * Built with createElement / textContent only: server names, URLs and error
 * messages are the owner's or a remote service's text, never markup.
 */

interface GitHubState {
  connected: boolean;
  login: string;
  error: string;
  managed_by_server: boolean;
}

interface McpServer {
  name: string;
  kind: "url" | "command";
  target: string;
  secrets: string[];
  connected: boolean;
}

interface ConnectorsResponse {
  github: GitHubState;
  mcp: McpServer[];
  problems: string[];
  restart_needed: boolean;
  file: string;
  mode: string;
}

// Presets fill the form; nothing is connected until the owner presses Add.
const PRESETS: Record<string, { name: string; url?: string; command?: string;
                                 args?: string; secret?: string; hint: string }> = {
  github: {
    name: "github",
    url: "https://api.githubcopilot.com/mcp/",
    secret: "Authorization",
    hint: "GitHub's own MCP server. Value: Bearer <your token> (a fine-grained token works).",
  },
  linear: {
    name: "linear",
    url: "https://mcp.linear.app/mcp",
    hint: "Linear's hosted MCP server.",
  },
  notion: {
    name: "notion",
    command: "npx",
    args: "-y @notionhq/notion-mcp-server",
    secret: "NOTION_TOKEN",
    hint: "Runs on the server. Value: your Notion integration secret.",
  },
};

function el<K extends keyof HTMLElementTagNameMap>(
  tag: K, opts: { cls?: string; text?: string; attrs?: Record<string, string> } = {},
  ...children: (Node | null)[]
): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  if (opts.cls) node.className = opts.cls;
  if (opts.text !== undefined) node.textContent = opts.text;
  for (const [k, v] of Object.entries(opts.attrs ?? {})) node.setAttribute(k, v);
  for (const c of children) if (c) node.appendChild(c);
  return node;
}

function field(label: string, input: HTMLElement, hint?: string): HTMLElement {
  return el("div", { cls: "settings-field" },
    el("label", { text: label }), input,
    hint ? el("p", { cls: "settings-hint", text: hint }) : null);
}

function input(type: string, placeholder: string): HTMLInputElement {
  return el("input", { attrs: { type, placeholder, autocomplete: "off", spellcheck: "false" } });
}

function dot(state: "green" | "red" | "yellow" | "off"): HTMLElement {
  return el("span", { cls: state === "off" ? "status-dot" : `status-dot status-${state}` });
}

async function call(method: string, url: string, body?: unknown): Promise<{ ok: boolean; data: any }> {
  try {
    const res = await fetch(url, {
      method,
      headers: body === undefined ? undefined : { "Content-Type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    let data: any = {};
    try { data = await res.json(); } catch { /* empty body */ }
    return { ok: res.ok, data };
  } catch {
    return { ok: false, data: { error: "No answer from the server." } };
  }
}

function setMessage(node: HTMLElement, text: string, bad = false) {
  node.textContent = text;
  node.className = bad ? "connectors-msg bad" : "connectors-msg";
}

// ---------------------------------------------------------------------------

function githubCard(state: GitHubState, rerender: () => void): HTMLElement {
  const status = el("div", { cls: "status-row" },
    dot(state.connected ? "green" : state.error ? "red" : "off"),
    el("span", { text: state.connected
      ? `Connected as ${state.login ? "@" + state.login : "an unnamed account"}`
      : state.error ? `Token not accepted: ${state.error}` : "Not connected" }));

  const token = input("password", state.connected ? "Paste a new token to replace it" : "github_pat_…");
  const name = input("text", "JARVIS");
  const email = input("text", "you@example.com");
  const msg = el("p", { cls: "connectors-msg" });

  const save = el("button", { cls: "settings-btn primary", text: state.connected ? "Update" : "Connect" });
  save.addEventListener("click", async () => {
    setMessage(msg, "Checking with GitHub…");
    save.disabled = true;
    const r = await call("POST", "/api/connectors/github", {
      token: token.value.trim(), git_name: name.value.trim(), git_email: email.value.trim(),
    });
    save.disabled = false;
    if (!r.ok) { setMessage(msg, r.data.error || "That did not work.", true); return; }
    token.value = "";
    const notes: string[] = r.data.notes || [];
    setMessage(msg, `Connected as @${r.data.login}.` + (notes.length ? ` ${notes.join(" ")}` : ""));
    rerender();
  });

  const remove = el("button", { cls: "settings-btn", text: "Disconnect" });
  remove.addEventListener("click", async () => {
    const r = await call("DELETE", "/api/connectors/github");
    if (!r.ok) { setMessage(msg, r.data.error || "That did not work.", true); return; }
    rerender();
  });

  const link = el("a", { text: "Create a fine-grained token", attrs: {
    href: "https://github.com/settings/personal-access-tokens/new",
    target: "_blank", rel: "noopener noreferrer" } });
  const hint = el("p", { cls: "settings-hint" },
    link, document.createTextNode(
      " limited to the repositories JARVIS should touch (Contents: read and write, " +
      "Metadata: read). Used for repository lookups and for git clone and push in runs. " +
      "Takes effect immediately."));

  return el("div", { cls: "connectors-card" },
    el("h4", { text: "GitHub" }), status,
    state.managed_by_server
      ? el("p", { cls: "settings-hint", text: "This token is set in the server's configuration; run sudo jarvis-setup to change it." })
      : null,
    field("Token", token),
    el("div", { cls: "connectors-two" },
      field("Commit name (optional)", name), field("Commit email (optional)", email)),
    hint,
    el("div", { cls: "settings-actions connectors-actions" },
      state.connected && !state.managed_by_server ? remove : null, save),
    msg);
}

function mcpList(data: ConnectorsResponse, rerender: () => void): HTMLElement {
  const box = el("div", { cls: "connectors-list" });
  if (!data.mcp.length) {
    box.appendChild(el("p", { cls: "settings-hint", text: "No MCP servers yet." }));
  }
  for (const s of data.mcp) {
    const remove = el("button", { cls: "settings-btn", text: "Remove" });
    remove.addEventListener("click", async () => {
      remove.disabled = true;
      await call("DELETE", `/api/connectors/mcp/${encodeURIComponent(s.name)}`);
      rerender();
    });
    const detail = s.secrets.length ? `${s.target}  ·  secrets: ${s.secrets.join(", ")}` : s.target;
    box.appendChild(el("div", { cls: "connectors-row" },
      dot(s.connected ? "green" : "yellow"),
      el("div", { cls: "connectors-row-text" },
        el("div", { cls: "connectors-row-name", text: s.name }),
        el("div", { cls: "connectors-row-detail", text: detail })),
      remove));
  }
  for (const p of data.problems) {
    box.appendChild(el("p", { cls: "connectors-msg bad", text: p }));
  }
  return box;
}

function mcpForm(rerender: () => void): HTMLElement {
  const preset = el("select", {},
    el("option", { text: "Custom", attrs: { value: "" } }),
    el("option", { text: "GitHub (remote)", attrs: { value: "github" } }),
    el("option", { text: "Linear (remote)", attrs: { value: "linear" } }),
    el("option", { text: "Notion (runs on the server)", attrs: { value: "notion" } }));
  const kind = el("select", {},
    el("option", { text: "Remote URL", attrs: { value: "url" } }),
    el("option", { text: "Command on the server", attrs: { value: "command" } }));
  const name = input("text", "e.g. notion");
  const url = input("text", "https://…/mcp");
  const command = input("text", "npx");
  const args = input("text", "-y @scope/some-mcp-server");
  const secretName = input("text", "Authorization  or  API_TOKEN");
  const secretValue = input("password", "value (stored on the server, never shown again)");
  const hint = el("p", { cls: "settings-hint" });
  const msg = el("p", { cls: "connectors-msg" });

  const urlField = field("URL", url);
  const cmdField = field("Command", command);
  const argsField = field("Arguments (space-separated)", args);
  const secretLabel = el("label");

  function syncKind() {
    const isUrl = kind.value === "url";
    urlField.style.display = isUrl ? "" : "none";
    cmdField.style.display = isUrl ? "none" : "";
    argsField.style.display = isUrl ? "none" : "";
    secretLabel.textContent = isUrl ? "Header (optional)" : "Environment variable (optional)";
  }
  kind.addEventListener("change", syncKind);
  preset.addEventListener("change", () => {
    const p = PRESETS[preset.value];
    if (!p) { hint.textContent = ""; return; }
    name.value = p.name;
    kind.value = p.url ? "url" : "command";
    url.value = p.url ?? "";
    command.value = p.command ?? "";
    args.value = p.args ?? "";
    secretName.value = p.secret ?? "";
    hint.textContent = p.hint;
    syncKind();
  });

  const add = el("button", { cls: "settings-btn primary", text: "Add" });
  add.addEventListener("click", async () => {
    const isUrl = kind.value === "url";
    const secrets: Record<string, string> = {};
    if (secretName.value.trim() && secretValue.value) secrets[secretName.value.trim()] = secretValue.value;
    const body = {
      name: name.value.trim(),
      url: isUrl ? url.value.trim() : "",
      command: isUrl ? "" : command.value.trim(),
      args: isUrl ? [] : args.value.trim().split(/\s+/).filter(Boolean),
      headers: isUrl ? secrets : {},
      env: isUrl ? {} : secrets,
    };
    add.disabled = true;
    const r = await call("POST", "/api/connectors/mcp", body);
    add.disabled = false;
    if (!r.ok) { setMessage(msg, r.data.error || "That did not work.", true); return; }
    secretValue.value = "";
    rerender();
  });

  syncKind();
  return el("details", { cls: "connectors-add" },
    el("summary", { text: "Add an MCP server" }),
    field("Start from", preset), hint,
    field("Name", name),
    field("Kind", kind),
    urlField, cmdField, argsField,
    el("div", { cls: "settings-field" }, secretLabel,
      el("div", { cls: "connectors-two" }, secretName, secretValue)),
    el("p", { cls: "settings-hint", text:
      "Whatever a connected service returns is treated as untrusted, like a web page. " +
      "Prefer read-only tokens." }),
    el("div", { cls: "settings-actions" }, add),
    msg);
}

function restartBanner(rerender: () => void): HTMLElement {
  const btn = el("button", { cls: "settings-btn primary", text: "Restart now" });
  const msg = el("span", { text: "Restart JARVIS to connect the MCP changes." });
  btn.addEventListener("click", async () => {
    btn.disabled = true;
    msg.textContent = "Restarting…";
    // Reloads the brain on the same conversation; no page reload needed.
    const r = await call("POST", "/api/connectors/apply");
    msg.textContent = r.ok ? "Connected." : "The restart failed; the server log says why.";
    setTimeout(rerender, 800);
  });
  return el("div", { cls: "connectors-restart" }, msg, btn);
}

export async function renderConnectors(root: HTMLElement): Promise<void> {
  const rerender = () => void renderConnectors(root);
  const r = await call("GET", "/api/connectors");
  root.replaceChildren();
  if (!r.ok) {
    root.appendChild(el("p", { cls: "connectors-msg bad", text: r.data.error || "Could not load connections." }));
    return;
  }
  const data = r.data as ConnectorsResponse;
  root.appendChild(githubCard(data.github, rerender));
  const mcp = el("div", { cls: "connectors-card" },
    el("h4", { text: "MCP servers" }),
    el("p", { cls: "settings-hint", text:
      "Services JARVIS's brain can use as tools. Green is connected; amber waits for a restart." }),
    mcpList(data, rerender));
  if (data.restart_needed) mcp.appendChild(restartBanner(rerender));
  mcp.appendChild(mcpForm(rerender));
  root.appendChild(mcp);
}
