/**
 * Giving JARVIS files: drop them anywhere on the voice page, or use the
 * paperclip. Each goes to POST /api/uploads (raw body, no multipart) and lands
 * in the `uploads` project on the server; JARVIS is told about it with your
 * next words.
 *
 * XMLHttpRequest rather than fetch only for upload progress.
 * createElement / textContent only.
 */

import { openWindow, kindFor } from "./windows";

const MAX_BYTES = 200 * 1024 * 1024;
let overlay: HTMLElement | null = null;
let tray: HTMLElement | null = null;
let depth = 0;

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
}

function ensure(): void {
  if (overlay) return;
  overlay = el("div", "drop-overlay");
  const box = el("div", "drop-box");
  box.append(el("div", "drop-title", "Drop to give it to JARVIS"),
    el("div", "drop-sub", "Files go to the uploads project on the server, where he can read, look at and change them."));
  overlay.append(box);
  document.body.appendChild(overlay);
  tray = document.getElementById("file-cards");
  if (!tray) {
    tray = el("div");
    tray.id = "file-cards";
    document.body.appendChild(tray);
  }
}

function size(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 ** 2) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
}

function uploadOne(file: File): void {
  ensure();
  const card = el("div", "file-card upload-card");
  const text = el("div", "file-text");
  const name = el("div", "file-name", file.name);
  const meta = el("div", "file-meta", `uploading · ${size(file.size)}`);
  const bar = el("div", "upload-bar");
  const fillBar = el("div", "upload-fill");
  bar.append(fillBar);
  text.append(name, meta, bar);
  const actions = el("div", "file-actions");
  const close = el("button", undefined, "×");
  close.type = "button";
  close.addEventListener("click", () => card.remove());
  actions.append(close);
  card.append(text, actions);
  tray!.prepend(card);

  if (file.size > MAX_BYTES) {
    meta.textContent = "too large (200 MB at most)";
    card.classList.add("upload-card--bad");
    return;
  }
  const xhr = new XMLHttpRequest();
  xhr.open("POST", `/api/uploads?name=${encodeURIComponent(file.name)}`);
  xhr.setRequestHeader("Content-Type", "application/octet-stream");
  xhr.upload.onprogress = (e) => {
    if (e.lengthComputable) fillBar.style.width = `${Math.round((100 * e.loaded) / e.total)}%`;
  };
  xhr.onload = () => {
    let data: any = {};
    try { data = JSON.parse(xhr.responseText); } catch { /* not JSON */ }
    if (xhr.status === 401) { location.assign("/login"); return; }
    if (xhr.status < 200 || xhr.status >= 300) {
      meta.textContent = data.error || `failed (HTTP ${xhr.status})`;
      card.classList.add("upload-card--bad");
      return;
    }
    bar.remove();
    name.textContent = data.name;
    meta.textContent = "given to JARVIS — he'll know when you next speak";
    const view = el("button", "upload-view", "View");
    view.type = "button";
    view.addEventListener("click", () => openWindow({
      kind: kindFor(data.name), title: data.name, url: data.url, name: data.name, source: "uploads",
    }));
    actions.prepend(view);
    window.setTimeout(() => card.remove(), 20_000);
  };
  xhr.onerror = () => {
    meta.textContent = "upload failed — is the server reachable?";
    card.classList.add("upload-card--bad");
  };
  xhr.send(file);
}

export function uploadFiles(files: FileList | File[]): void {
  for (const f of Array.from(files)) uploadOne(f);
}

/** Wire the whole page as a drop target, and the paperclip button. */
export function initUploads(button: HTMLElement | null): void {
  ensure();
  const hasFiles = (e: DragEvent) => Array.from(e.dataTransfer?.types ?? []).includes("Files");
  window.addEventListener("dragenter", (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    depth++;
    overlay!.classList.add("visible");
  });
  window.addEventListener("dragover", (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    if (e.dataTransfer) e.dataTransfer.dropEffect = "copy";
  });
  window.addEventListener("dragleave", (e) => {
    if (!hasFiles(e)) return;
    depth = Math.max(0, depth - 1);
    if (depth === 0) overlay!.classList.remove("visible");
  });
  window.addEventListener("drop", (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    depth = 0;
    overlay!.classList.remove("visible");
    if (e.dataTransfer?.files.length) uploadFiles(e.dataTransfer.files);
  });
  if (button) {
    const picker = el("input");
    picker.type = "file";
    picker.multiple = true;
    picker.hidden = true;
    picker.addEventListener("change", () => {
      if (picker.files?.length) uploadFiles(picker.files);
      picker.value = "";
    });
    document.body.appendChild(picker);
    button.addEventListener("click", (e) => { e.stopPropagation(); picker.click(); });
  }
}
