import { openWindow, kindFor } from "./windows";
/**
 * The caption bar along the bottom of the voice page, and the "file ready"
 * cards above it.
 *
 * Captions follow the VOICE, not the writing. Each `audio` frame carries the
 * text of its chunk; it is held until the audio player reports that chunk has
 * started playing (`captionChunkStarted`, with its real duration), and then
 * its words are revealed across that duration — each word at the moment it
 * is being said, as nearly as text alone allows. Fish Audio returns no word
 * timings, so a word's share of the chunk is estimated from its length, with
 * extra time after a comma or a full stop, where a speaker pauses.
 *
 * Each word fades in softly; the bar fades out slowly a few seconds after the
 * last chunk finishes. A barge-in stops the reveal where it is.
 *
 * Files: `{"type":"file", name, url, inline, what}` when JARVIS hands
 * something over. A card with a download link (and a thumbnail for images).
 *
 * textContent and createElement only: this is model output and file names.
 */

const HOLD_AFTER_MS = 2600;        // how long the last words stay before fading
const MAX_WORDS = 60;              // keep the bar to about two lines
const MAX_CARDS = 3;
const LEAD_MS = 60;                // show a word a hair before it is heard

let bar: HTMLElement | null = null;
let line: HTMLElement | null = null;
let currentUtt: number | null = null;
let fadeTimer: number | undefined;
let wordTimers: number[] = [];
let cards: HTMLElement | null = null;
const chunkText = new Map<string, string>();   // "utt:idx" -> its text

function ensure(): void {
  if (bar) return;
  bar = document.createElement("div");
  bar.id = "caption-bar";
  bar.setAttribute("aria-live", "polite");
  line = document.createElement("div");
  line.className = "caption-line";
  bar.appendChild(line);
  document.body.appendChild(bar);
  cards = document.getElementById("file-cards") ?? document.createElement("div");
  if (!cards.id) {
    cards.id = "file-cards";
    document.body.appendChild(cards);
  }
}

function plain(text: string): string {
  // What TTS strips before speaking, so the caption reads like the voice.
  return text.replace(/[*_`#>]+/g, "");
}

function show(): void {
  ensure();
  window.clearTimeout(fadeTimer);
  bar!.classList.add("visible");
}

function fadeSoon(after = HOLD_AFTER_MS): void {
  window.clearTimeout(fadeTimer);
  fadeTimer = window.setTimeout(() => bar?.classList.remove("visible"), after);
}

function addWord(word: string): void {
  const span = document.createElement("span");
  span.className = "caption-word";
  span.textContent = word + " ";
  line!.appendChild(span);
  while (line!.childElementCount > MAX_WORDS) line!.firstElementChild?.remove();
}

/** How long a word takes to say, relative to its neighbours. */
function weight(word: string): number {
  const letters = word.replace(/[^\p{L}\p{N}]/gu, "").length;
  let w = 1.2 + letters;                       // every word costs something
  if (/[,;:]$/.test(word)) w += 3;             // a short pause
  if (/[.!?…]$/.test(word)) w += 5;            // a longer one
  if (/\d/.test(word)) w += letters * 0.8;     // numbers are read out long
  return w;
}

function clearTimers(): void {
  for (const t of wordTimers) window.clearTimeout(t);
  wordTimers = [];
}

/** An `audio` frame arrived: remember its text until it plays. */
export function captionQueue(utt: number, idx: number, text: string): void {
  if (!text) return;
  chunkText.set(`${utt}:${idx}`, plain(text));
  if (chunkText.size > 200) chunkText.delete(chunkText.keys().next().value as string);
}

/** The player started a chunk: reveal its words across its real length. */
export function captionChunkStarted(utt: number, idx: number, duration: number): void {
  const key = `${utt}:${idx}`;
  const text = chunkText.get(key);
  chunkText.delete(key);
  if (!text) return;
  show();
  if (currentUtt !== utt) {
    currentUtt = utt;
    clearTimers();
    line!.replaceChildren();
  }
  const words = text.split(/\s+/).filter(Boolean);
  const weights = words.map(weight);
  const total = weights.reduce((a, b) => a + b, 0) || 1;
  // Leave the tail of the chunk for its trailing silence.
  const span = Math.max(0.2, duration * 0.94) * 1000;
  let at = 0;
  words.forEach((word, i) => {
    const when = Math.max(0, (at / total) * span - LEAD_MS);
    wordTimers.push(window.setTimeout(() => addWord(word), when));
    at += weights[i];
  });
}

/** Text with no audio (TTS could not voice it): shown at once. */
export function captionText(text: string): void {
  show();
  currentUtt = null;
  clearTimers();
  line!.replaceChildren();
  for (const w of plain(text).split(/\s+/).filter(Boolean)) addWord(w);
  fadeSoon(HOLD_AFTER_MS * 2);
}

/** Playback stopped (barged in on): stop revealing, then fade. */
export function captionStop(): void {
  clearTimers();
  chunkText.clear();
  fadeSoon(900);
}

/** The player ran out of chunks: let the last words linger, then fade. */
export function captionIdle(): void {
  if (!bar) return;
  // Words still due to appear are part of the chunk that just ended.
  const pending = wordTimers.length ? 400 : 0;
  fadeSoon(HOLD_AFTER_MS + pending);
}

function humanSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
}

/** JARVIS handed over a file. */
export function fileReady(msg: Record<string, unknown>): void {
  ensure();
  const name = String(msg.name ?? "");
  const url = String(msg.url ?? "");
  if (!name || !url.startsWith("/api/files/")) return;
  const card = document.createElement("div");
  card.className = "file-card";

  if (msg.inline) {
    const img = document.createElement("img");
    img.src = url;
    img.alt = "";
    img.className = "file-thumb";
    const view = document.createElement("a");
    view.href = url;
    view.target = "_blank";
    view.rel = "noopener";
    view.appendChild(img);
    card.appendChild(view);
  }
  const text = document.createElement("div");
  text.className = "file-text";
  const title = document.createElement("div");
  title.className = "file-name";
  title.textContent = name.replace(/^\d{8}-\d{6}-/, "");
  const meta = document.createElement("div");
  meta.className = "file-meta";
  meta.textContent = `${String(msg.what ?? "file")} · ${humanSize(Number(msg.size ?? 0))}`;
  text.append(title, meta);

  const actions = document.createElement("div");
  actions.className = "file-actions";
  const view = document.createElement("button");
  view.type = "button";
  view.className = "upload-view";
  view.textContent = "Open";
  view.addEventListener("click", () => openWindow({
    kind: kindFor(name), title: name.replace(/^\d{8}-\d{6}-/, ""), url, name,
  }));
  const dl = document.createElement("a");
  dl.href = `${url}?download=1`;
  dl.textContent = "Download";
  dl.setAttribute("download", name);
  const close = document.createElement("button");
  close.type = "button";
  close.textContent = "×";
  close.title = "Dismiss";
  close.addEventListener("click", () => card.remove());
  actions.append(view, dl, close);

  card.append(text, actions);
  cards!.prepend(card);
  while (cards!.childElementCount > MAX_CARDS) cards!.lastElementChild?.remove();
  fadeAway(card, 15_000);
}

/** Cards are notices, not furniture: they leave on their own. */
function fadeAway(card: HTMLElement, after: number): void {
  window.setTimeout(() => {
    card.classList.add("leaving");
    window.setTimeout(() => card.remove(), 400);
  }, after);
}


/** JARVIS has memories for the user to review on the dashboard. */
export function proposalsReady(count: number): void {
  ensure();
  if (!count) return;
  cards!.querySelector(".file-card--memory")?.remove();
  const card = document.createElement("div");
  card.className = "file-card file-card--memory";
  const text = document.createElement("div");
  text.className = "file-text";
  const title = document.createElement("div");
  title.className = "file-name";
  title.textContent = `${count} thing${count === 1 ? "" : "s"} worth remembering`;
  const meta = document.createElement("div");
  meta.className = "file-meta";
  meta.textContent = "Approve or dismiss them in the dashboard's Memory tab";
  text.append(title, meta);
  const actions = document.createElement("div");
  actions.className = "file-actions";
  const open = document.createElement("a");
  open.href = "/dashboard";
  open.target = "_blank";
  open.rel = "noopener";
  open.textContent = "Review";
  const close = document.createElement("button");
  close.type = "button";
  close.textContent = "×";
  close.addEventListener("click", () => card.remove());
  actions.append(open, close);
  card.append(text, actions);
  cards!.prepend(card);
}
