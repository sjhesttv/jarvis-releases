/**
 * The Memory view: what JARVIS carries into every conversation, and the
 * editor for everything behind it (memory.db). Ask Memory runs the same
 * search `recall` does, so the owner can see what JARVIS would find.
 *
 * Every string here — titles, hooks, and especially journal/memory body
 * text — can contain content JARVIS copied out of someone else's Claude
 * Code session. Attacker-influenced, same discipline as Sessions: always
 * textContent, never innerHTML.
 */
import {
  getMemory, getMemoryDoc, ApiError,
  getMemoryIndexText, putMemoryIndex, putMemoryDoc, deleteMemoryDoc, createMemory,
  approveProposal, dismissProposal, reviewConversationNow, searchMemory,
  type MemorySnapshot, type MemoryKind,
  type MemoryIndexEntry, type MemoryFileEntry, type ProjectNoteEntry, type JournalEntry,
  type ConversationDay, type MemoryProposal, type EpisodeEntry, type MemoryHit,
} from "./api";
import { el, row, button, emptyState } from "./ui";

let started = false;
let openDocToken = 0;

function fmtWhen(epochSec: number): string {
  if (!epochSec) return "—";
  return new Date(epochSec * 1000).toLocaleString([], {
    month: "short", day: "numeric", hour: "2-digit", minute: "2-digit",
  });
}

function section(id: string): HTMLElement | null {
  return document.getElementById(id);
}

function setMeta(id: string, count: number): void {
  const meta = section(id);
  if (meta) meta.textContent = count > 0 ? String(count) : "";
}

function showBanner(text: string | null): void {
  const banner = section("memory-banner");
  if (!banner) return;
  if (text === null) {
    banner.hidden = true;
    return;
  }
  banner.hidden = false;
  banner.textContent = text;
}

function setUnavailable(unavailable: boolean): void {
  const notice = section("memory-unavailable");
  const body = section("memory-body");
  if (notice) notice.hidden = !unavailable;
  if (body) body.hidden = unavailable;
}

/** A single clickable row: title, a muted subtitle, and a "when" on the
 * right — the shape shared by memories, projects and journal entries. */
function docRow(
  titleText: string, subText: string, whenText: string,
  onOpen: () => void, highlight = false,
): HTMLElement {
  const r = row({
    onOpen,
    label: titleText,
    tone: highlight ? "accent" : undefined,
  });
  r.setTitle(titleText);
  if (subText) r.setSub(subText);
  r.addMeta(whenText, { cls: "memory-row-when" });
  return r.root;
}

/** Open one document in the side pane, readable and — because this folder
 * is the user's — editable and deletable. `kind` "index" is MEMORY.md. */
function openDoc(kind: MemoryKind | "index", slug: string, titleText: string): void {
  const pane = section("memory-detail");
  if (!pane) return;
  const token = ++openDocToken;

  pane.hidden = false;
  pane.replaceChildren();

  const head = el("header", "pane-head");
  const close = button("Close", closeDoc, { quiet: true });
  close.classList.add("pane-close");
  head.append(el("h2", "pane-title", titleText), close);

  const body = el("div", "pane-body");
  const doc = el("pre", "doc", "Loading…");
  const editor = el("textarea", "memory-editor");
  editor.hidden = true;
  editor.spellcheck = true;
  const status = el("div", "memory-edit-status");
  const actions = el("div", "memory-edit-actions");
  let loadedText = "";

  const edit = button("Edit", () => {
    editor.value = loadedText;
    editor.hidden = false;
    doc.hidden = true;
    actions.replaceChildren(save, cancel);
    editor.focus();
  });
  const save = button("Save", async () => {
    save.disabled = true;
    status.textContent = "Saving…";
    try {
      if (kind === "index") await putMemoryIndex(editor.value);
      else await putMemoryDoc(kind, slug, editor.value);
      loadedText = editor.value;
      doc.textContent = loadedText;
      status.textContent = "Saved. JARVIS reads it fresh in the next conversation.";
      showRead();
      void reconcile();
    } catch (e) {
      status.textContent = e instanceof Error ? e.message : "Could not save.";
    } finally {
      save.disabled = false;
    }
  }, { tone: "accent" });
  const cancel = button("Cancel", () => { showRead(); status.textContent = ""; }, { quiet: true });
  let armed = false;
  const del = button("Delete", async () => {
    if (!armed) {
      armed = true;
      del.textContent = "Delete — sure?";
      setTimeout(() => { armed = false; del.textContent = "Delete"; }, 4000);
      return;
    }
    try {
      await deleteMemoryDoc(kind as MemoryKind, slug);
      closeDoc();
      void reconcile();
    } catch (e) {
      status.textContent = e instanceof Error ? e.message : "Could not delete.";
    }
  }, { quiet: true, tone: "bad" });

  function showRead(): void {
    editor.hidden = true;
    doc.hidden = false;
    actions.replaceChildren(edit, ...(kind === "index" ? [] : [del]));
  }
  showRead();

  body.append(el("div", "pane-meta", kind === "index" ? "MEMORY.md · read into every conversation" : `${kind} · ${slug}`),
    actions, status, doc, editor);
  pane.append(head, body);

  const load = kind === "index" ? getMemoryIndexText() : getMemoryDoc(kind, slug);
  load
    .then((loaded) => {
      if (token !== openDocToken) return; // superseded by another open/close
      loadedText = loaded.text;
      doc.textContent = loaded.text;
    })
    .catch((e) => {
      if (token !== openDocToken) return;
      if (!(e instanceof ApiError && e.status === 404)) {
        console.error("[memory] doc fetch failed", e);
      }
      doc.textContent = "Could not load this file. It may have been moved or deleted on disk.";
      edit.disabled = true;
    });
}

/** The pane as a form for a brand-new memory. */
function openNewMemory(): void {
  const pane = section("memory-detail");
  if (!pane) return;
  ++openDocToken;
  pane.hidden = false;
  pane.replaceChildren();
  const head = el("header", "pane-head");
  const close = button("Close", closeDoc, { quiet: true });
  close.classList.add("pane-close");
  head.append(el("h2", "pane-title", "New memory"), close);
  const title = el("input", "memory-input");
  title.placeholder = "Title — e.g. Prefers tea";
  const hook = el("input", "memory-input");
  hook.placeholder = "One line for the index (optional)";
  const text = el("textarea", "memory-editor");
  text.placeholder = "The fact, as JARVIS should know it.";
  const status = el("div", "memory-edit-status");
  const save = button("Save memory", async () => {
    save.disabled = true;
    try {
      await createMemory(title.value, hook.value, text.value);
      closeDoc();
      void reconcile();
    } catch (e) {
      status.textContent = e instanceof Error ? e.message : "Could not save.";
    } finally {
      save.disabled = false;
    }
  }, { tone: "accent" });
  const body = el("div", "pane-body");
  body.append(title, hook, text, el("div", "memory-edit-actions"), status);
  body.children[3].append(save);
  pane.append(head, body);
  title.focus();
}

function headButton(sectionId: string, label: string, onClick: () => void): void {
  const headEl = section(sectionId)?.querySelector(".panel-head");
  if (!headEl || headEl.querySelector(`[data-action="${label}"]`)) return;
  const b = button(label, onClick, { quiet: true });
  b.dataset.action = label;
  b.classList.add("memory-head-btn");
  headEl.append(b);
}

function paintProposals(items: MemoryProposal[], lastReviewed: number): void {
  const list = section("memory-proposals-list");
  if (!list) return;
  list.replaceChildren();
  setMeta("memory-proposals-meta", items.length);
  const reviewNow = button("Review recent conversation now", async () => {
    reviewNow.disabled = true;
    reviewNow.textContent = "Reviewing…";
    try {
      const r = await reviewConversationNow();
      reviewNow.textContent = r.status === "ok" ? `${r.added ?? 0} new` : r.status;
      void reconcile();
    } catch (e) {
      reviewNow.textContent = e instanceof Error ? e.message : "Could not review";
    }
  }, { quiet: true });
  if (items.length === 0) {
    list.append(emptyState(
      "Nothing waiting. After a quiet spell JARVIS looks back over the conversation and " +
      "suggests what is worth remembering; it appears here for you to approve." +
      (lastReviewed ? ` Last reviewed ${fmtWhen(lastReviewed)}.` : ""), true));
    list.append(reviewNow);
    return;
  }
  for (const p of items) {
    const card = el("div", "memory-proposal");
    const t = el("input", "memory-input");
    t.value = p.title;
    const h = el("input", "memory-input");
    h.value = p.hook;
    const b = el("textarea", "memory-editor memory-editor--short");
    b.value = p.body;
    const status = el("div", "memory-edit-status");
    const approve = button("Remember", async () => {
      approve.disabled = true;
      try {
        await approveProposal(p.id, { title: t.value, hook: h.value, body: b.value });
        void reconcile();
      } catch (e) {
        status.textContent = e instanceof Error ? e.message : "Could not save.";
        approve.disabled = false;
      }
    }, { tone: "accent" });
    const dismiss = button("Dismiss", async () => {
      await dismissProposal(p.id).catch(() => undefined);
      void reconcile();
    }, { quiet: true });
    const actions = el("div", "memory-edit-actions");
    actions.append(approve, dismiss);
    card.append(t, h, b, actions, status);
    list.append(card);
  }
  list.append(reviewNow);
}

function paintConversations(days: ConversationDay[]): void {
  const list = section("memory-conversations-list");
  if (!list) return;
  list.replaceChildren();
  setMeta("memory-conversations-meta", days.length);
  if (days.length === 0) {
    list.append(emptyState("No conversations logged yet. Every exchange is kept here, word for word, by day.", true));
    return;
  }
  for (const d of days.slice(0, 60)) {
    list.append(docRow(
      d.slug, `${d.count} exchange${d.count === 1 ? "" : "s"}`, "",
      () => openDoc("conversation", d.slug, `Conversations, ${d.slug}`),
    ));
  }
}

function closeDoc(): void {
  openDocToken++;
  const pane = section("memory-detail");
  if (!pane) return;
  pane.hidden = true;
  pane.replaceChildren();
}

const KIND_LABEL: Record<string, string> = {
  memory: "Memory", project: "Project", journal: "Journal", episode: "Conversation", conversation: "Exchange",
};

let searchToken = 0;

function paintSearch(stats: Record<string, number> | undefined): void {
  const holder = section("memory-path");
  const meta = section("memory-stats-meta");
  if (meta && stats) {
    meta.textContent = `${stats.facts ?? 0} memories · ${stats.episodes ?? 0} conversations · ${stats.exchanges ?? 0} exchanges`;
  }
  if (!holder || holder.dataset.ready) return;
  holder.dataset.ready = "1";

  const input = el("input", "memory-input") as HTMLInputElement;
  input.type = "search";
  input.placeholder = "Ask the way you would ask JARVIS: what did we decide about pricing?";
  input.setAttribute("aria-label", "Search memory");
  const status = el("div", "memory-hint", "");
  const results = el("div", "stack");

  const run = async () => {
    const q = input.value.trim();
    const token = ++searchToken;
    if (!q) {
      results.replaceChildren();
      status.textContent = "";
      return;
    }
    status.textContent = "Searching…";
    try {
      const r = await searchMemory(q);
      if (token !== searchToken) return;
      status.textContent = r.models.up
        ? "Searching by meaning and by word."
        : "Searching by word only — the local model is not running, so meaning search is off.";
      results.replaceChildren();
      if (!r.hits.length) results.append(emptyState("Nothing in memory matches that.", true));
      for (const h of r.hits) results.append(hitRow(h));
    } catch {
      if (token === searchToken) status.textContent = "The search did not work.";
    }
  };
  let timer: number | undefined;
  input.addEventListener("input", () => {
    window.clearTimeout(timer);
    timer = window.setTimeout(() => void run(), 300);
  });
  input.addEventListener("keydown", (e) => { if (e.key === "Enter") void run(); });

  holder.append(input, status, results);
}

function hitRow(h: MemoryHit): HTMLElement {
  const label = KIND_LABEL[h.kind] ?? h.kind;
  const how = h.meaning > 0 ? `${label} · meaning ${Math.round(h.meaning * 100)}%` : label;
  const title = h.kind === "episode" ? `Conversation, ${h.day ?? ""}` : h.name;
  return docRow(title, h.excerpt, how, () => openDoc(h.kind, h.name, title));
}

function paintEpisodes(entries: EpisodeEntry[]): void {
  const list = section("memory-episodes-list");
  if (!list) return;
  list.replaceChildren();
  setMeta("memory-episodes-meta", entries.length);
  if (entries.length === 0) {
    list.append(emptyState(
      "No summaries yet. After a conversation goes quiet, JARVIS writes a few sentences on what it covered, so he can find it again later.", true));
    return;
  }
  for (const e of entries.slice(0, 60)) {
    list.append(docRow(
      e.summary, "", fmtWhen(e.end),
      () => openDoc("episode", e.slug, `Conversation, ${e.day}`),
    ));
  }
}

function paintIndex(entries: MemoryIndexEntry[]): void {
  const list = section("memory-index-list");
  if (!list) return;
  list.replaceChildren();
  setMeta("memory-index-meta", entries.length);
  if (entries.length === 0) {
    list.append(emptyState("Nothing indexed yet.", true));
    return;
  }
  for (const entry of entries) {
    list.append(docRow(
      entry.title, entry.hook, "",
      () => openDoc("memory", entry.slug, entry.title),
    ));
  }
}

function paintMemories(entries: MemoryFileEntry[]): void {
  const list = section("memory-files-list");
  if (!list) return;
  list.replaceChildren();
  setMeta("memory-files-meta", entries.length);
  if (entries.length === 0) {
    list.append(emptyState("No memories yet.", true));
    return;
  }
  const sorted = [...entries].sort((a, b) => b.modified - a.modified);
  for (const m of sorted) {
    list.append(docRow(
      m.title, m.slug, fmtWhen(m.modified),
      () => openDoc("memory", m.slug, m.title),
    ));
  }
}

function paintProjects(entries: ProjectNoteEntry[]): void {
  const list = section("memory-projects-list");
  if (!list) return;
  list.replaceChildren();
  setMeta("memory-projects-meta", entries.length);
  if (entries.length === 0) {
    list.append(emptyState("No project notes yet.", true));
    return;
  }
  const sorted = [...entries].sort((a, b) => b.modified - a.modified);
  for (const p of sorted) {
    list.append(docRow(
      p.title, p.slug, fmtWhen(p.modified),
      () => openDoc("project", p.slug, p.title),
    ));
  }
}

function paintJournalList(entries: JournalEntry[], latestSlug: string | null): void {
  const list = section("memory-journal-list");
  if (!list) return;
  list.replaceChildren();
  setMeta("memory-journal-meta", entries.length);
  if (entries.length === 0) {
    list.append(emptyState("No journal entries yet.", true));
    return;
  }
  const sorted = [...entries].sort((a, b) => b.when - a.when);
  for (const j of sorted) {
    const isLatest = j.slug === latestSlug;
    list.append(docRow(
      j.reason || "(handover)", j.slug, fmtWhen(j.when),
      () => openDoc("journal", j.slug, j.reason || j.slug),
      isLatest,
    ));
  }
}

async function paintLatestJournal(latestSlug: string | null): Promise<void> {
  const wrap = section("journal-latest-section");
  const body = section("journal-latest-body");
  const meta = section("journal-latest-meta");
  if (!wrap || !body) return;

  if (!latestSlug) {
    wrap.hidden = true;
    return;
  }
  wrap.hidden = false;
  if (meta) meta.textContent = latestSlug;
  body.textContent = "Loading…";
  try {
    const doc = await getMemoryDoc("journal", latestSlug);
    body.textContent = doc.text;
  } catch (e) {
    if (!(e instanceof ApiError && e.status === 404)) {
      console.error("[memory] latest journal fetch failed", e);
    }
    body.textContent = "Could not load the latest journal entry.";
  }
}

async function reconcile(): Promise<void> {
  let snap: MemorySnapshot;
  try {
    snap = await getMemory();
  } catch (e) {
    if (e instanceof ApiError && e.status === 404) {
      // Expected until the backend endpoint ships — a calm empty state,
      // not an error. No console noise.
      setUnavailable(true);
      showBanner(null);
      return;
    }
    console.error("[memory] reconcile failed", e);
    showBanner("Cannot reach the JARVIS server.");
    return;
  }

  setUnavailable(false);
  showBanner(null);
  paintSearch(snap.stats);
  paintIndex(snap.index);
  paintMemories(snap.memories);
  paintProjects(snap.projects);
  paintJournalList(snap.journal, snap.latest_journal_slug);
  void paintLatestJournal(snap.latest_journal_slug);
  paintProposals(snap.proposals ?? [], snap.last_reviewed ?? 0);
  paintConversations(snap.conversations ?? []);
  paintEpisodes(snap.episodes ?? []);
  headButton("memory-index-section", "Edit index", () =>
    openDoc("index", "MEMORY", "Carried into every conversation"));
  headButton("memory-files-section", "New memory", openNewMemory);
}

export function initMemory(): void {
  if (started) return;
  started = true;
  void reconcile();
}

/** Re-fetch on demand — e.g. when the user switches back to this tab,
 * since the folder is user-edited on disk and there is no live socket
 * pushing changes the way runs/sessions get. */
export function refreshMemory(): void {
  void reconcile();
}
