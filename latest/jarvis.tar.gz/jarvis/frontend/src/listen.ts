/**
 * Listening on the server: works in every browser (Firefox, Safari on the
 * iPhone, Chrome), and the audio goes to JARVIS's own server, not Google.
 *
 * The microphone is opened with the browser's echo cancellation on, and read
 * sample by sample (public/mic-worklet.js). A small voice-activity detector
 * here decides where an utterance starts and ends — energy over a noise floor
 * it keeps learning — and each finished utterance is sent as a 16 kHz WAV to
 * POST /api/listen, where Whisper turns it into text. That text goes over the
 * voice socket exactly as the browser's own recogniser's would, so the
 * server's echo and barge-in rules are unchanged.
 *
 * Same interface as voice.ts's createVoiceInput, so main.ts can use either.
 */
import type { VoiceInput } from "./voice";

const RATE = 16000;
const FRAME = 320;                 // 20 ms at 16 kHz
const START_FRAMES = 3;            // 60 ms of voice to begin an utterance
const END_FRAMES = 40;             // 800 ms of quiet to end one
const PREROLL_FRAMES = 15;         // keep 300 ms from before the start
const MIN_VOICED_FRAMES = 12;      // under 240 ms of voice is a click, not words
const MAX_FRAMES = 15 * 50;        // 15 s: cut and send, then carry on
const FLOOR_MIN = 0.004;

export function createServerVoiceInput(
  onTranscript: (text: string) => void,
  onError: (msg: string) => void,
  onMicEvent: (event: string) => void = () => {},
  onUtteranceStart: () => void = () => {},
): VoiceInput {
  let ctx: AudioContext | null = null;
  let stream: MediaStream | null = null;
  let node: AudioWorkletNode | null = null;
  let listening = false;
  let paused = false;
  let opening = false;

  // VAD state
  let floor = 0.01;
  let loudRun = 0;
  let quietRun = 0;
  let inSpeech = false;
  let voiced = 0;
  const preroll: Float32Array[] = [];
  let utterance: Float32Array[] = [];
  let carry = new Float32Array(0);
  let sending: Promise<void> = Promise.resolve();

  const mark = (what: string) => {
    console.info(`[listen] ${new Date().toLocaleTimeString()} ${what}`);
    onMicEvent(what);
  };

  function reset() {
    inSpeech = false;
    loudRun = quietRun = voiced = 0;
    utterance = [];
    preroll.length = 0;
  }

  /** Linear-interpolated resample of one block to 16 kHz. */
  function toRate(block: Float32Array, from: number): Float32Array {
    if (from === RATE) return block;
    const n = Math.floor((block.length * RATE) / from);
    const out = new Float32Array(n);
    const step = from / RATE;
    for (let i = 0; i < n; i++) {
      const x = i * step;
      const j = Math.floor(x);
      const f = x - j;
      out[i] = block[j] * (1 - f) + (block[Math.min(j + 1, block.length - 1)] * f);
    }
    return out;
  }

  function onBlock(block: Float32Array) {
    if (!listening || paused || !ctx) return;
    const s = toRate(block, ctx.sampleRate);
    const joined = new Float32Array(carry.length + s.length);
    joined.set(carry);
    joined.set(s, carry.length);
    let i = 0;
    for (; i + FRAME <= joined.length; i += FRAME) onFrame(joined.slice(i, i + FRAME));
    carry = joined.slice(i);
  }

  function onFrame(frame: Float32Array) {
    let sum = 0;
    for (let i = 0; i < frame.length; i++) sum += frame[i] * frame[i];
    const rms = Math.sqrt(sum / frame.length);
    const startAt = Math.max(0.012, floor * 3.5);
    const keepAt = Math.max(0.008, floor * 2.2);

    if (!inSpeech) {
      // Learn the room only while nobody is talking.
      floor = Math.max(FLOOR_MIN, floor * 0.995 + rms * 0.005);
      preroll.push(frame);
      if (preroll.length > PREROLL_FRAMES) preroll.shift();
      loudRun = rms > startAt ? loudRun + 1 : 0;
      if (loudRun >= START_FRAMES) {
        inSpeech = true;
        utterance = preroll.splice(0);
        voiced = loudRun;
        quietRun = 0;
        onUtteranceStart();
      }
      return;
    }

    utterance.push(frame);
    if (rms > keepAt) {
      voiced++;
      quietRun = 0;
    } else {
      quietRun++;
    }
    if (quietRun >= END_FRAMES || utterance.length >= MAX_FRAMES) {
      const done = utterance;
      const enough = voiced >= MIN_VOICED_FRAMES;
      reset();
      if (enough) send(done);
    }
  }

  function wav(frames: Float32Array[]): Blob {
    const samples = frames.reduce((n, f) => n + f.length, 0);
    const buf = new ArrayBuffer(44 + samples * 2);
    const v = new DataView(buf);
    const str = (o: number, t: string) => { for (let i = 0; i < t.length; i++) v.setUint8(o + i, t.charCodeAt(i)); };
    str(0, "RIFF"); v.setUint32(4, 36 + samples * 2, true); str(8, "WAVE");
    str(12, "fmt "); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, RATE, true); v.setUint32(28, RATE * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
    str(36, "data"); v.setUint32(40, samples * 2, true);
    let o = 44;
    for (const f of frames) {
      for (let i = 0; i < f.length; i++, o += 2) {
        const x = Math.max(-1, Math.min(1, f[i]));
        v.setInt16(o, x < 0 ? x * 0x8000 : x * 0x7fff, true);
      }
    }
    return new Blob([buf], { type: "audio/wav" });
  }

  function send(frames: Float32Array[]) {
    const body = wav(frames);
    // One at a time, in order: two sentences must arrive as said.
    sending = sending.then(async () => {
      try {
        const res = await fetch("/api/listen", { method: "POST", body, headers: { "Content-Type": "audio/wav" } });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          onError(data.error || `Listening failed (HTTP ${res.status}).`);
          mark(`listen failed: ${res.status}`);
          return;
        }
        const text = String(data.text || "").trim();
        if (text) onTranscript(text);
      } catch {
        onError("Could not reach the server to transcribe that.");
      }
    });
  }

  async function open() {
    if (opening || stream) return;
    opening = true;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 },
      });
      // Firefox will not connect a microphone to an AudioContext running at
      // a different sample rate, so the context runs at the mic's own rate.
      const micRate = stream.getAudioTracks()[0]?.getSettings().sampleRate;
      try {
        ctx = micRate ? new AudioContext({ sampleRate: micRate }) : new AudioContext();
      } catch {
        ctx = new AudioContext();
      }
      await ctx.audioWorklet.addModule("/mic-worklet.js");
      const source = ctx.createMediaStreamSource(stream);
      node = new AudioWorkletNode(ctx, "mic-tap");
      node.port.onmessage = (e: MessageEvent<Float32Array>) => onBlock(e.data);
      source.connect(node);
      // Safari and Firefox start an AudioContext suspended until a gesture.
      const wake = () => { if (ctx && ctx.state === "suspended") void ctx.resume(); };
      wake();
      for (const ev of ["click", "touchstart", "keydown"]) document.addEventListener(ev, wake);
      mark(`listening on the server (mic at ${ctx.sampleRate} Hz)`);
    } catch (e) {
      const name = e instanceof Error ? e.name : String(e);
      onError(name === "NotAllowedError"
        ? "Microphone blocked — allow it for this site, then reload."
        : "Could not open the microphone.");
      mark(`mic open failed: ${name}`);
      close();
    } finally {
      opening = false;
    }
  }

  function close() {
    node?.disconnect();
    node = null;
    stream?.getTracks().forEach((t) => t.stop());
    stream = null;
    void ctx?.close().catch(() => undefined);
    ctx = null;
    carry = new Float32Array(0);
    reset();
  }

  return {
    start() {
      listening = true;
      paused = false;
      void open();
    },
    stop() {
      listening = false;
      close();
    },
    pause() {
      paused = true;
      reset();
    },
    resume() {
      paused = false;
      if (listening && !stream) void open();
    },
    restart(reason: string) {
      if (!listening) return;
      mark(`reopening the microphone: ${reason}`);
      close();
      void open();
    },
  };
}
