"""jarvis-ml: JARVIS's local models, as a small service beside the server.

    voice out   Kokoro (kokoro-onnx, 82M parameters, CPU): text -> MP3
    voice in    Whisper (faster-whisper, CTranslate2 int8, CPU): WAV -> text
    meaning     bge-small-en-v1.5 (fastembed, ONNX): text -> vector

Separate from server.py on purpose: its dependencies (onnxruntime,
CTranslate2, numpy) are large, and it lives in its own virtualenv
(`/opt/jarvis/ml-venv`) and its own systemd unit (`jarvis-ml`), so the
server installs and restarts in seconds and keeps working, minus these,
if it is not there. It listens on loopback only and has no authentication:
the only caller is the server on the same machine (ml_client.py), and the
egress firewall the installer sets leaves it unreachable from outside.

Models are downloaded by the installer into JARVIS_MODELS_DIR (default
/opt/jarvis/models) and loaded once, in the background, at start; /health
says which are ready. Nothing here phones home after that.

Voices: any Kokoro voice name, or a blend written as "bm_george:0.6,
bm_lewis:0.4" (the style vectors are mixed, which is how a voice of one's
own is made with Kokoro). British male voices are bm_george, bm_lewis,
bm_daniel and bm_fable.

    python3 ml_service.py [--port 8341]
"""

from __future__ import annotations

import io
import logging
import os
import re
import threading
import time
import wave
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response

log = logging.getLogger("jarvis.ml_service")

PORT = int(os.getenv("JARVIS_ML_PORT", "8341"))
MODELS_DIR = os.getenv("JARVIS_MODELS_DIR", "/opt/jarvis/models")
EMBED_MODEL = os.getenv("JARVIS_EMBED_MODEL", "BAAI/bge-small-en-v1.5")
STT_MODEL = os.getenv("JARVIS_STT_MODEL", "small.en")
DEFAULT_VOICE = os.getenv("JARVIS_VOICE", "bm_george:0.7,bm_lewis:0.3")
DEFAULT_SPEED = float(os.getenv("JARVIS_VOICE_SPEED", "1.05"))
THREADS = int(os.getenv("JARVIS_ML_THREADS", "0")) or max(1, (os.cpu_count() or 2) - 1)

MAX_TEXT = 1200          # characters per TTS request (one or two sentences)
MAX_AUDIO_SEC = 30       # per STT request
MAX_BATCH = 64           # texts per embed request

_VOICE_RE = re.compile(r"[a-z]{2}_[a-z]+(?::(?:0|1|0?\.\d+))?(?:,[a-z]{2}_[a-z]+(?::(?:0|1|0?\.\d+))?){0,3}")

# What Whisper says when it hears nothing at all — trained on subtitled
# video, it fills silence and room noise with these. Dropped, not spoken.
HALLUCINATIONS = frozenset(s.lower() for s in (
    "thank you.", "thank you", "thanks for watching!", "thanks for watching.",
    "thank you for watching.", "you", "bye.", ".", "okay.", "so", "uh", "um",
    "please subscribe.", "subtitles by the amara.org community",
))


class NotReady(RuntimeError):
    pass


# ---------------------------------------------------------------------------
# The three engines. Each loads lazily and is swappable (tests pass fakes).
# ---------------------------------------------------------------------------

class Speaker:
    """Kokoro text-to-speech."""
    name = "kokoro"

    def __init__(self, models_dir: str = MODELS_DIR):
        self.models_dir = models_dir
        self._k = None

    def load(self) -> None:
        from kokoro_onnx import Kokoro
        self._k = Kokoro(os.path.join(self.models_dir, "kokoro-v1.0.onnx"),
                         os.path.join(self.models_dir, "voices-v1.0.bin"))

    @property
    def ready(self) -> bool:
        return self._k is not None

    def voices(self) -> list[str]:
        return sorted(self._k.get_voices()) if self._k else []

    def style(self, voice: str):
        """A voice name or a blend, as the style array Kokoro takes."""
        parts = []
        for item in voice.split(","):
            name, _, w = item.partition(":")
            parts.append((name, float(w) if w else 1.0))
        if len(parts) == 1:
            return parts[0][0]
        total = sum(w for _, w in parts) or 1.0
        mix = None
        for name, w in parts:
            v = self._k.get_voice_style(name) * (w / total)
            mix = v if mix is None else mix + v
        return mix

    def speak(self, text: str, voice: str, speed: float) -> tuple[list, int]:
        if self._k is None:
            raise NotReady("voice model still loading")
        lang = "en-gb" if voice[:1] == "b" else "en-us"     # bm_/bf_ are the British voices
        samples, rate = self._k.create(text, voice=self.style(voice), speed=speed, lang=lang)
        return samples, rate


class Listener:
    """faster-whisper speech-to-text."""
    name = "whisper"

    def __init__(self, model: str = STT_MODEL, models_dir: str = MODELS_DIR):
        self.model = model
        self.models_dir = models_dir
        self._w = None

    def load(self) -> None:
        from faster_whisper import WhisperModel
        self._w = WhisperModel(self.model, device="cpu", compute_type="int8", local_files_only=True,
                               cpu_threads=THREADS,
                               download_root=os.path.join(self.models_dir, "whisper"))

    @property
    def ready(self) -> bool:
        return self._w is not None

    def transcribe(self, samples, prompt: str = "") -> dict:
        """`samples`: float32 mono at 16 kHz."""
        if self._w is None:
            raise NotReady("speech model still loading")
        segments, info = self._w.transcribe(
            samples, language="en", beam_size=1, vad_filter=True,
            condition_on_previous_text=False, initial_prompt=prompt or None)
        kept = [s for s in segments if s.no_speech_prob < 0.6 and s.avg_logprob > -1.0]
        text = " ".join(s.text.strip() for s in kept).strip()
        return {"text": text, "duration": round(float(info.duration), 2)}


class Embedder:
    """fastembed sentence embeddings."""
    name = "fastembed"

    def __init__(self, model: str = EMBED_MODEL, models_dir: str = MODELS_DIR):
        self.model = model
        self.models_dir = models_dir
        self._e = None

    def load(self) -> None:
        from fastembed import TextEmbedding
        self._e = TextEmbedding(self.model, cache_dir=os.path.join(self.models_dir, "fastembed"),
                                threads=THREADS, local_files_only=True)

    @property
    def ready(self) -> bool:
        return self._e is not None

    def embed(self, texts: list[str], kind: str) -> list[list[float]]:
        if self._e is None:
            raise NotReady("embedding model still loading")
        fn = self._e.query_embed if kind == "query" else self._e.passage_embed
        return [[float(x) for x in v] for v in fn(texts)]


# ---------------------------------------------------------------------------
# Audio formats
# ---------------------------------------------------------------------------

def to_pcm16(samples) -> bytes:
    import numpy as np
    a = np.clip(np.asarray(samples, dtype="float32"), -1.0, 1.0)
    return (a * 32767.0).astype("<i2").tobytes()


def encode(samples, rate: int, fmt: str = "mp3") -> tuple[bytes, str]:
    """MP3 when lameenc is installed (what the browser already plays and
    speech.py can measure), WAV otherwise."""
    pcm = to_pcm16(samples)
    if fmt == "mp3":
        try:
            import lameenc
            enc = lameenc.Encoder()
            enc.set_bit_rate(96)
            enc.set_in_sample_rate(rate)
            enc.set_channels(1)
            enc.set_quality(2)
            return enc.encode(pcm) + enc.flush(), "audio/mpeg"
        except ImportError:
            pass
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm)
    return buf.getvalue(), "audio/wav"


def decode_wav(data: bytes):
    """float32 mono 16 kHz from a WAV the browser recorded (PCM16, any rate,
    any channel count — resampled and mixed down here)."""
    import numpy as np
    with wave.open(io.BytesIO(data), "rb") as w:
        if w.getsampwidth() != 2:
            raise ValueError("expected 16-bit PCM")
        rate, channels = w.getframerate(), w.getnchannels()
        frames = w.readframes(min(w.getnframes(), rate * MAX_AUDIO_SEC))
    a = np.frombuffer(frames, dtype="<i2").astype("float32") / 32768.0
    if channels > 1:
        a = a.reshape(-1, channels).mean(axis=1)
    if rate != 16000 and len(a):
        n = int(len(a) * 16000 / rate)
        a = np.interp(np.linspace(0, len(a) - 1, n), np.arange(len(a)), a).astype("float32")
    return a


def is_hallucination(text: str) -> bool:
    t = " ".join(text.lower().split())
    return not t or t in HALLUCINATIONS or not any(c.isalpha() for c in t)


# ---------------------------------------------------------------------------
# The app
# ---------------------------------------------------------------------------

def create_app(speaker=None, listener=None, embedder=None, load: bool = True):
    engines = {"tts": speaker or Speaker(), "stt": listener or Listener(),
               "embed": embedder or Embedder()}
    errors: dict[str, str] = {}
    started = time.time()
    locks = {k: threading.Lock() for k in engines}   # one inference at a time per model

    def _load_all():
        for key, eng in engines.items():
            if eng.ready:
                continue
            t0 = time.time()
            try:
                eng.load()
                log.info("%s ready in %.1fs", key, time.time() - t0)
            except Exception as e:           # a missing model must not take the others down
                errors[key] = f"{type(e).__name__}: {e}"[:300]
                log.error("%s failed to load: %s", key, errors[key])

    if load:
        threading.Thread(target=_load_all, daemon=True, name="ml-load").start()

    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)

    def _why(e: NotReady) -> str:
        """Still loading, or failed to load (and why): not the same thing."""
        failed = [f"{k}: {v}" for k, v in errors.items()]
        return f"{e}; failed to load — {'; '.join(failed)}" if failed else str(e)

    def _problem(status: int, msg: str):
        return JSONResponse(status_code=status, content={"error": msg})

    @app.get("/health")
    def health():
        return {"ready": {k: e.ready for k, e in engines.items()}, "errors": errors,
                "embed_model": getattr(engines["embed"], "model", ""),
                "stt_model": getattr(engines["stt"], "model", ""),
                "voice": DEFAULT_VOICE, "up_sec": round(time.time() - started)}

    @app.get("/voices")
    def voices():
        sp = engines["tts"]
        return {"voices": sp.voices() if sp.ready else [], "default": DEFAULT_VOICE}

    @app.post("/embed")
    async def embed(request: Request):
        body = await request.json()
        texts = body.get("texts")
        if not isinstance(texts, list) or not texts or len(texts) > MAX_BATCH \
                or not all(isinstance(t, str) for t in texts):
            return _problem(400, f"texts: 1 to {MAX_BATCH} strings")
        if body.get("model") not in (None, engines["embed"].model):
            return _problem(409, f"this service embeds with {engines['embed'].model}")
        try:
            with locks["embed"]:
                vecs = engines["embed"].embed([t[:4000] for t in texts], str(body.get("kind") or "passage"))
        except NotReady as e:
            return _problem(503, _why(e))
        return {"model": engines["embed"].model, "vectors": vecs}

    @app.post("/tts")
    async def tts(request: Request):
        body = await request.json()
        text = " ".join(str(body.get("text") or "").split())[:MAX_TEXT]
        voice = str(body.get("voice") or DEFAULT_VOICE).replace(" ", "")
        try:
            speed = min(1.6, max(0.6, float(body.get("speed") or DEFAULT_SPEED)))
        except (TypeError, ValueError):
            speed = DEFAULT_SPEED
        if not text:
            return _problem(400, "nothing to say")
        if not _VOICE_RE.fullmatch(voice):
            return _problem(400, "voice: a Kokoro voice name, or a blend like bm_george:0.6,bm_lewis:0.4")
        t0 = time.time()
        try:
            with locks["tts"]:
                samples, rate = engines["tts"].speak(text, voice, speed)
        except NotReady as e:
            return _problem(503, _why(e))
        except KeyError:
            return _problem(400, "no such voice")
        audio, mime = encode(samples, rate, str(body.get("format") or "mp3"))
        return Response(audio, media_type=mime,
                        headers={"X-Synth-Seconds": f"{time.time() - t0:.3f}"})

    @app.post("/stt")
    async def stt(request: Request):
        data = await request.body()
        if not data or len(data) > 16000 * 2 * 2 * MAX_AUDIO_SEC + 1024:
            return _problem(400, f"a WAV of at most {MAX_AUDIO_SEC}s")
        try:
            samples = decode_wav(data)
        except (wave.Error, ValueError, EOFError) as e:
            return _problem(400, f"not a usable WAV ({e})")
        prompt = request.headers.get("X-Prompt", "")[:200]
        t0 = time.time()
        try:
            with locks["stt"]:
                out = engines["stt"].transcribe(samples, prompt)
        except NotReady as e:
            return _problem(503, _why(e))
        if is_hallucination(out["text"]):
            out["text"] = ""
        out["seconds"] = round(time.time() - t0, 3)
        return out

    return app


def main() -> None:
    import argparse
    import uvicorn
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=PORT)
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(message)s")
    uvicorn.run(create_app(), host="127.0.0.1", port=args.port, log_level="warning")


if __name__ == "__main__":
    main()
