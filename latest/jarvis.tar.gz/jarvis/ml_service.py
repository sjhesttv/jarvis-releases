"""jarvis-ml: JARVIS's local models, as a small service beside the server.

    voice out   Kokoro (kokoro-onnx, 82M parameters, CPU): text -> MP3
                Piper (piper-tts): a voice trained for him, e.g. "piper:jarvis"
    voice in    Whisper (faster-whisper, CTranslate2 int8, CPU): WAV -> text
    meaning     bge-small-en-v1.5 (fastembed, ONNX): text -> vector

Separate from server.py on purpose: its dependencies (onnxruntime,
CTranslate2, numpy) are large, and it lives in its own virtualenv
(`/opt/jarvis/ml-venv`) and its own systemd unit (`jarvis-ml`), so the
server installs and restarts in seconds and keeps working, minus these,
if it is not there. It listens on loopback only and has no authentication:
the only caller is the server on the same machine (ml_client.py), and the
egress firewall the installer sets leaves it unreachable from outside.

Models are downloaded by the installer into JARVIS_MODELS_DIR (default
/opt/jarvis/models) and loaded once, in the background, at start; /health
says which are ready. Nothing here phones home after that.

Voices: any Kokoro voice name, or a blend written as "bm_george:0.6,
bm_lewis:0.4" (the style vectors are mixed, which is how a voice of one's
own is made with Kokoro). British male voices are bm_george, bm_lewis,
bm_daniel and bm_fable.

Or a Piper voice of his own (voice_training/ makes one): "piper:<name>",
from <name>.onnx + <name>.onnx.json in PIPER_DIR (/var/lib/jarvis-ml/piper,
the service's own writable state, where Settings -> Voice uploads land and
`jarvis-setup --voice` copies to) or in <models>/piper. Loaded on first
use and again whenever the file changes, so an upload needs no restart.

    python3 ml_service.py [--port 8341]
"""

from __future__ import annotations

import io
import logging
import os
import re
import threading
import time
import wave
from typing import Optional

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response

log = logging.getLogger("jarvis.ml_service")

PORT = int(os.getenv("JARVIS_ML_PORT", "8341"))
MODELS_DIR = os.getenv("JARVIS_MODELS_DIR", "/opt/jarvis/models")
EMBED_MODEL = os.getenv("JARVIS_EMBED_MODEL", "BAAI/bge-small-en-v1.5")
STT_MODEL = os.getenv("JARVIS_STT_MODEL", "small.en")
DEFAULT_VOICE = os.getenv("JARVIS_VOICE", "bm_george:0.7,bm_lewis:0.3")
DEFAULT_SPEED = float(os.getenv("JARVIS_VOICE_SPEED", "1.05"))
PIPER_DIR = os.getenv("JARVIS_PIPER_DIR", "/var/lib/jarvis-ml/piper")
THREADS = int(os.getenv("JARVIS_ML_THREADS", "0")) or max(1, (os.cpu_count() or 2) - 1)

MAX_TEXT = 1200          # characters per TTS request (one or two sentences)
MAX_AUDIO_SEC = 30       # per STT request
MAX_BATCH = 64           # texts per embed request
MAX_PIPER_MODEL = 400 * 1024 * 1024    # a "medium" voice is ~60 MB, "high" ~110 MB
MAX_PIPER_CONFIG = 2 * 1024 * 1024

_KOKORO_RE = re.compile(r"[a-z]{2}_[a-z]+(?::(?:0|1|0?\.\d+))?(?:,[a-z]{2}_[a-z]+(?::(?:0|1|0?\.\d+))?){0,3}")
_PIPER_NAME_RE = re.compile(r"[a-z0-9][a-z0-9_-]{0,39}")
_VOICE_RE = re.compile(rf"piper:{_PIPER_NAME_RE.pattern}|{_KOKORO_RE.pattern}")

# What Whisper says when it hears nothing at all — trained on subtitled
# video, it fills silence and room noise with these. Dropped, not spoken.
HALLUCINATIONS = frozenset(s.lower() for s in (
    "thank you.", "thank you", "thanks for watching!", "thanks for watching.",
    "thank you for watching.", "you", "bye.", ".", "okay.", "so", "uh", "um",
    "please subscribe.", "subtitles by the amara.org community",
))


class NotReady(RuntimeError):
    pass


# ---------------------------------------------------------------------------
# The three engines. Each loads lazily and is swappable (tests pass fakes).
# ---------------------------------------------------------------------------

class Speaker:
    """Kokoro text-to-speech."""
    name = "kokoro"

    def __init__(self, models_dir: str = MODELS_DIR):
        self.models_dir = models_dir
        self._k = None

    def load(self) -> None:
        from kokoro_onnx import Kokoro
        self._k = Kokoro(os.path.join(self.models_dir, "kokoro-v1.0.onnx"),
                         os.path.join(self.models_dir, "voices-v1.0.bin"))

    @property
    def ready(self) -> bool:
        return self._k is not None

    def voices(self) -> list[str]:
        return sorted(self._k.get_voices()) if self._k else []

    def style(self, voice: str):
        """A voice name or a blend, as the style array Kokoro takes."""
        parts = []
        for item in voice.split(","):
            name, _, w = item.partition(":")
            parts.append((name, float(w) if w else 1.0))
        if len(parts) == 1:
            return parts[0][0]
        total = sum(w for _, w in parts) or 1.0
        mix = None
        for name, w in parts:
            v = self._k.get_voice_style(name) * (w / total)
            mix = v if mix is None else mix + v
        return mix

    def speak(self, text: str, voice: str, speed: float) -> tuple[list, int]:
        if self._k is None:
            raise NotReady("voice model still loading")
        lang = "en-gb" if voice[:1] == "b" else "en-us"     # bm_/bf_ are the British voices
        samples, rate = self._k.create(text, voice=self.style(voice), speed=speed, lang=lang)
        return samples, rate


class PiperVoices:
    """Piper voices, by name, loaded on first use.

    A voice is `<name>.onnx` with `<name>.onnx.json` beside it. A voice is
    reloaded when its model file changes (an upload replaced it).
    """
    name = "piper"

    def __init__(self, dirs: Optional[list[str]] = None):
        self.dirs = dirs if dirs is not None else [PIPER_DIR, os.path.join(MODELS_DIR, "piper")]
        self._loaded: dict[str, tuple[float, object]] = {}
        self._lock = threading.Lock()

    def path_of(self, name: str) -> Optional[str]:
        if not _PIPER_NAME_RE.fullmatch(name):
            return None
        for d in self.dirs:
            model = os.path.join(d, f"{name}.onnx")
            if os.path.isfile(model) and os.path.isfile(model + ".json"):
                return model
        return None

    def names(self) -> list[str]:
        out = set()
        for d in self.dirs:
            try:
                for f in os.listdir(d):
                    if f.endswith(".onnx") and self.path_of(f[:-5]):
                        out.add(f[:-5])
            except OSError:
                continue
        return sorted(out)

    @property
    def ready(self) -> bool:
        return bool(self.names())

    def load_file(self, model: str):
        from piper import PiperVoice
        return PiperVoice.load(model, config_path=model + ".json")

    def voice(self, name: str):
        model = self.path_of(name)
        if model is None:
            raise KeyError(name)
        mtime = os.path.getmtime(model)
        with self._lock:
            have = self._loaded.get(name)
            if have and have[0] == mtime:
                return have[1]
            v = self.load_file(model)
            self._loaded[name] = (mtime, v)
            log.info("piper voice %r loaded", name)
            return v

    def forget(self, name: str) -> None:
        with self._lock:
            self._loaded.pop(name, None)

    def speak(self, text: str, name: str, speed: float, noise: Optional[float] = None,
              noise_w: Optional[float] = None) -> tuple[list, int]:
        return self.render(self.voice(name), text, speed, noise, noise_w)

    @staticmethod
    def render(v, text: str, speed: float, noise: Optional[float] = None,
               noise_w: Optional[float] = None) -> tuple[list, int]:
        import numpy as np
        from piper import SynthesisConfig
        cfg = SynthesisConfig(length_scale=1.0 / speed, noise_scale=noise, noise_w_scale=noise_w)
        parts, rate = [], 22050
        for chunk in v.synthesize(text, syn_config=cfg):
            rate = chunk.sample_rate
            if parts:
                parts.append(np.zeros(int(rate * 0.12), dtype="float32"))   # between sentences
            parts.append(np.asarray(chunk.audio_float_array, dtype="float32"))
        if not parts:
            raise ValueError("Piper produced no audio for that text")
        return np.concatenate(parts), rate


def check_piper_config(data: bytes) -> dict:
    """What a Piper voice's .onnx.json must have, or ValueError saying what is wrong."""
    import json
    try:
        cfg = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        raise ValueError("the .onnx.json file is not valid JSON")
    missing = [k for k in ("phoneme_id_map", "audio", "espeak", "num_symbols", "num_speakers")
               if k not in cfg] if isinstance(cfg, dict) else ["everything"]
    if missing or not isinstance(cfg["phoneme_id_map"], dict) \
            or not isinstance(cfg["audio"], dict) or not cfg["audio"].get("sample_rate"):
        raise ValueError("that .onnx.json is not a Piper voice config "
                         f"(missing: {', '.join(missing) or 'audio.sample_rate'})")
    return cfg


class Listener:
    """faster-whisper speech-to-text."""
    name = "whisper"

    def __init__(self, model: str = STT_MODEL, models_dir: str = MODELS_DIR):
        self.model = model
        self.models_dir = models_dir
        self._w = None

    def load(self) -> None:
        from faster_whisper import WhisperModel
        self._w = WhisperModel(self.model, device="cpu", compute_type="int8", local_files_only=True,
                               cpu_threads=THREADS,
                               download_root=os.path.join(self.models_dir, "whisper"))

    @property
    def ready(self) -> bool:
        return self._w is not None

    def transcribe(self, samples, prompt: str = "") -> dict:
        """`samples`: float32 mono at 16 kHz."""
        if self._w is None:
            raise NotReady("speech model still loading")
        segments, info = self._w.transcribe(
            samples, language="en", beam_size=1, vad_filter=True,
            condition_on_previous_text=False, initial_prompt=prompt or None)
        kept = [s for s in segments if s.no_speech_prob < 0.6 and s.avg_logprob > -1.0]
        text = " ".join(s.text.strip() for s in kept).strip()
        return {"text": text, "duration": round(float(info.duration), 2)}


class Embedder:
    """fastembed sentence embeddings."""
    name = "fastembed"

    def __init__(self, model: str = EMBED_MODEL, models_dir: str = MODELS_DIR):
        self.model = model
        self.models_dir = models_dir
        self._e = None

    def load(self) -> None:
        from fastembed import TextEmbedding
        self._e = TextEmbedding(self.model, cache_dir=os.path.join(self.models_dir, "fastembed"),
                                threads=THREADS, local_files_only=True)

    @property
    def ready(self) -> bool:
        return self._e is not None

    def embed(self, texts: list[str], kind: str) -> list[list[float]]:
        if self._e is None:
            raise NotReady("embedding model still loading")
        fn = self._e.query_embed if kind == "query" else self._e.passage_embed
        return [[float(x) for x in v] for v in fn(texts)]


# ---------------------------------------------------------------------------
# Audio formats
# ---------------------------------------------------------------------------

def to_pcm16(samples) -> bytes:
    import numpy as np
    a = np.clip(np.asarray(samples, dtype="float32"), -1.0, 1.0)
    return (a * 32767.0).astype("<i2").tobytes()


def encode(samples, rate: int, fmt: str = "mp3") -> tuple[bytes, str]:
    """MP3 when lameenc is installed (what the browser already plays and
    speech.py can measure), WAV otherwise."""
    pcm = to_pcm16(samples)
    if fmt == "mp3":
        try:
            import lameenc
            enc = lameenc.Encoder()
            enc.set_bit_rate(96)
            enc.set_in_sample_rate(rate)
            enc.set_channels(1)
            enc.set_quality(2)
            return bytes(enc.encode(pcm) + enc.flush()), "audio/mpeg"     # lameenc gives a bytearray
        except ImportError:
            pass
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm)
    return buf.getvalue(), "audio/wav"


def decode_wav(data: bytes):
    """float32 mono 16 kHz from a WAV the browser recorded (PCM16, any rate,
    any channel count — resampled and mixed down here)."""
    import numpy as np
    with wave.open(io.BytesIO(data), "rb") as w:
        if w.getsampwidth() != 2:
            raise ValueError("expected 16-bit PCM")
        rate, channels = w.getframerate(), w.getnchannels()
        frames = w.readframes(min(w.getnframes(), rate * MAX_AUDIO_SEC))
    a = np.frombuffer(frames, dtype="<i2").astype("float32") / 32768.0
    if channels > 1:
        a = a.reshape(-1, channels).mean(axis=1)
    if rate != 16000 and len(a):
        n = int(len(a) * 16000 / rate)
        a = np.interp(np.linspace(0, len(a) - 1, n), np.arange(len(a)), a).astype("float32")
    return a


def is_hallucination(text: str) -> bool:
    t = " ".join(text.lower().split())
    return not t or t in HALLUCINATIONS or not any(c.isalpha() for c in t)


# ---------------------------------------------------------------------------
# The app
# ---------------------------------------------------------------------------

def create_app(speaker=None, listener=None, embedder=None, load: bool = True, piper=None):
    engines = {"tts": speaker or Speaker(), "stt": listener or Listener(),
               "embed": embedder or Embedder()}
    piper = piper or PiperVoices()
    errors: dict[str, str] = {}
    started = time.time()
    locks = {k: threading.Lock() for k in engines}   # one inference at a time per model
    locks["piper"] = threading.Lock()

    def _load_all():
        for key, eng in engines.items():
            if eng.ready:
                continue
            t0 = time.time()
            try:
                eng.load()
                log.info("%s ready in %.1fs", key, time.time() - t0)
            except Exception as e:           # a missing model must not take the others down
                errors[key] = f"{type(e).__name__}: {e}"[:300]
                log.error("%s failed to load: %s", key, errors[key])

    if load:
        threading.Thread(target=_load_all, daemon=True, name="ml-load").start()

    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)

    def _why(e: NotReady) -> str:
        """Still loading, or failed to load (and why): not the same thing."""
        failed = [f"{k}: {v}" for k, v in errors.items()]
        return f"{e}; failed to load — {'; '.join(failed)}" if failed else str(e)

    def _problem(status: int, msg: str):
        return JSONResponse(status_code=status, content={"error": msg})

    @app.get("/health")
    def health():
        ready = {k: e.ready for k, e in engines.items()}
        piper_voices = piper.names()
        kokoro = ready["tts"]
        ready["tts"] = kokoro or bool(piper_voices)      # he can speak with either
        return {"ready": ready, "kokoro": kokoro, "piper": piper_voices, "errors": errors,
                "embed_model": getattr(engines["embed"], "model", ""),
                "stt_model": getattr(engines["stt"], "model", ""),
                "voice": DEFAULT_VOICE, "up_sec": round(time.time() - started)}

    @app.get("/voices")
    def voices():
        sp = engines["tts"]
        return {"voices": sp.voices() if sp.ready else [], "piper": piper.names(),
                "default": DEFAULT_VOICE}

    @app.post("/embed")
    async def embed(request: Request):
        body = await request.json()
        texts = body.get("texts")
        if not isinstance(texts, list) or not texts or len(texts) > MAX_BATCH \
                or not all(isinstance(t, str) for t in texts):
            return _problem(400, f"texts: 1 to {MAX_BATCH} strings")
        if body.get("model") not in (None, engines["embed"].model):
            return _problem(409, f"this service embeds with {engines['embed'].model}")
        try:
            with locks["embed"]:
                vecs = engines["embed"].embed([t[:4000] for t in texts], str(body.get("kind") or "passage"))
        except NotReady as e:
            return _problem(503, _why(e))
        return {"model": engines["embed"].model, "vectors": vecs}

    @app.post("/tts")
    async def tts(request: Request):
        body = await request.json()
        text = " ".join(str(body.get("text") or "").split())[:MAX_TEXT]
        voice = str(body.get("voice") or DEFAULT_VOICE).replace(" ", "")
        try:
            speed = min(1.6, max(0.6, float(body.get("speed") or DEFAULT_SPEED)))
        except (TypeError, ValueError):
            speed = DEFAULT_SPEED
        if not text:
            return _problem(400, "nothing to say")
        if not _VOICE_RE.fullmatch(voice):
            return _problem(400, "voice: piper:<name>, a Kokoro voice name, or a blend like bm_george:0.6,bm_lewis:0.4")
        t0 = time.time()
        try:
            if voice.startswith("piper:"):
                noise, noise_w = _unit(body.get("noise")), _unit(body.get("noise_w"))
                with locks["piper"]:
                    samples, rate = piper.speak(text, voice[6:], speed, noise, noise_w)
            else:
                with locks["tts"]:
                    samples, rate = engines["tts"].speak(text, voice, speed)
        except NotReady as e:
            return _problem(503, _why(e))
        except KeyError:
            return _problem(400, "no such voice")
        audio, mime = encode(samples, rate, str(body.get("format") or "mp3"))
        return Response(audio, media_type=mime,
                        headers={"X-Synth-Seconds": f"{time.time() - t0:.3f}"})

    # --- Piper voice uploads: model, then config, then activate --------------
    #
    # The server streams each file here (Settings -> Voice). Both are staged
    # beside the live voice and only put in place by /activate, once the
    # pair has loaded and spoken a sentence, so a bad upload never replaces
    # a working voice.

    def _staged(name: str, part: str) -> str:
        os.makedirs(PIPER_DIR, mode=0o750, exist_ok=True)
        return os.path.join(PIPER_DIR, f".{name}.onnx{'.json' if part == 'config' else ''}.upload")

    @app.put("/piper/{name}/{part}")
    async def piper_upload(name: str, part: str, request: Request):
        if not _PIPER_NAME_RE.fullmatch(name) or part not in ("model", "config"):
            return _problem(400, "name: lowercase letters, digits, - or _; part: model or config")
        limit = MAX_PIPER_MODEL if part == "model" else MAX_PIPER_CONFIG
        path, size = _staged(name, part), 0
        with open(path, "wb") as fh:
            async for chunk in request.stream():
                size += len(chunk)
                if size > limit:
                    fh.close()
                    os.unlink(path)
                    return _problem(413, f"that file is larger than any Piper voice ({limit // 2**20} MB at most)")
                fh.write(chunk)
        if size == 0:
            os.unlink(path)
            return _problem(400, "that file is empty")
        return {"staged": part, "bytes": size}

    @app.post("/piper/{name}/activate")
    def piper_activate(name: str):
        if not _PIPER_NAME_RE.fullmatch(name):
            return _problem(400, "bad name")
        model, config = _staged(name, "model"), _staged(name, "config")
        if not (os.path.isfile(model) and os.path.isfile(config)):
            return _problem(400, "upload both files (the .onnx and the .onnx.json) first")
        try:
            with open(config, "rb") as fh:
                check_piper_config(fh.read())
            # Piper loads <model>.json beside the model: give the staged pair those names.
            trial = os.path.join(PIPER_DIR, f".{name}.trial.onnx")
            os.replace(model, trial)
            os.replace(config, trial + ".json")
            t0 = time.time()
            with locks["piper"]:
                piper.render(piper.load_file(trial), "Good evening, sir.", 1.0)
            took = time.time() - t0
        except Exception as e:                     # noqa: BLE001 - said back to the person uploading
            for f in (model, config, os.path.join(PIPER_DIR, f".{name}.trial.onnx"),
                      os.path.join(PIPER_DIR, f".{name}.trial.onnx.json")):
                if os.path.exists(f):
                    os.unlink(f)
            return _problem(400, f"that voice does not work: {str(e)[:300]}")
        live = os.path.join(PIPER_DIR, f"{name}.onnx")
        os.replace(trial + ".json", live + ".json")
        os.replace(trial, live)
        piper.forget(name)
        log.info("piper voice %r installed (test sentence in %.2fs)", name, took)
        return {"installed": f"piper:{name}", "test_seconds": round(took, 2)}

    @app.delete("/piper/{name}")
    def piper_delete(name: str):
        if not _PIPER_NAME_RE.fullmatch(name):
            return _problem(400, "bad name")
        live = os.path.join(PIPER_DIR, f"{name}.onnx")
        if not os.path.exists(live):
            return _problem(404, "no uploaded voice by that name")
        for f in (live, live + ".json"):
            if os.path.exists(f):
                os.unlink(f)
        piper.forget(name)
        return {"deleted": f"piper:{name}"}

    @app.post("/stt")
    async def stt(request: Request):
        data = await request.body()
        if not data or len(data) > 16000 * 2 * 2 * MAX_AUDIO_SEC + 1024:
            return _problem(400, f"a WAV of at most {MAX_AUDIO_SEC}s")
        try:
            samples = decode_wav(data)
        except (wave.Error, ValueError, EOFError) as e:
            return _problem(400, f"not a usable WAV ({e})")
        prompt = request.headers.get("X-Prompt", "")[:200]
        t0 = time.time()
        try:
            with locks["stt"]:
                out = engines["stt"].transcribe(samples, prompt)
        except NotReady as e:
            return _problem(503, _why(e))
        if is_hallucination(out["text"]):
            out["text"] = ""
        out["seconds"] = round(time.time() - t0, 3)
        return out

    return app


def _unit(value) -> Optional[float]:
    """A Piper noise setting, 0 to 1.5, or None for the voice's own default."""
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    return min(1.5, max(0.0, v))


def main() -> None:
    import argparse
    import uvicorn
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=PORT)
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(message)s")
    uvicorn.run(create_app(), host="127.0.0.1", port=args.port, log_level="warning")


if __name__ == "__main__":
    main()
