"""What the machine JARVIS runs on is doing: load, memory, disk, processes,
the services JARVIS depends on, and its own recent log.

Read-only and dependency-free: `/proc`, `os`, `shutil`, and `systemctl` /
`journalctl` / `ps` as argument lists. On a Mac (no /proc, no systemd) it
degrades to what `os` and `shutil` can say, and says what it could not see.

`snapshot()` is numbers and names this module computed itself, so the
`system_status` tool is not tainting. `recent_log()` is different: JARVIS's
log quotes what people said, page addresses and run output, so the
`server_logs` tool that returns it IS tainting (server.TAINTING_TOOLS).
"""

from __future__ import annotations

import asyncio
import os
import platform
import shutil
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import data_paths

SERVICES = ("jarvis", "caddy", "jarvis-egress")
TOP_PROCESSES = 5
LOG_LINES_MAX = 60


@dataclass
class Snapshot:
    host: str
    os: str
    uptime_sec: Optional[float]
    cpus: int
    load: Optional[tuple[float, float, float]]
    cpu_percent: Optional[float]
    mem_total: Optional[int]
    mem_available: Optional[int]
    swap_total: Optional[int]
    swap_free: Optional[int]
    disks: list[dict] = field(default_factory=list)
    processes: list[dict] = field(default_factory=list)
    services: dict[str, str] = field(default_factory=dict)
    jarvis_rss: Optional[int] = None
    version: str = ""
    notes: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {k: (list(v) if isinstance(v, tuple) else v)
                for k, v in self.__dict__.items()}


def _meminfo() -> dict[str, int]:
    out = {}
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            key, _, rest = line.partition(":")
            parts = rest.split()
            if parts and parts[0].isdigit():
                out[key] = int(parts[0]) * 1024
    except OSError:
        pass
    return out


def _cpu_times() -> Optional[tuple[int, int]]:
    try:
        first = Path("/proc/stat").read_text().splitlines()[0].split()[1:]
        values = [int(v) for v in first]
    except (OSError, IndexError, ValueError):
        return None
    idle = values[3] + (values[4] if len(values) > 4 else 0)
    return sum(values), idle


async def _cpu_percent(sample: float = 0.4) -> Optional[float]:
    a = _cpu_times()
    if a is None:
        return None
    await asyncio.sleep(sample)
    b = _cpu_times()
    if b is None or b[0] == a[0]:
        return None
    busy = (b[0] - a[0]) - (b[1] - a[1])
    return round(100.0 * busy / (b[0] - a[0]), 1)


def _uptime() -> Optional[float]:
    try:
        return float(Path("/proc/uptime").read_text().split()[0])
    except (OSError, ValueError, IndexError):
        return None


def _rss_of(pid: int) -> Optional[int]:
    try:
        for line in Path(f"/proc/{pid}/status").read_text().splitlines():
            if line.startswith("VmRSS:"):
                return int(line.split()[1]) * 1024
    except (OSError, ValueError, IndexError):
        pass
    return None


async def _run(*args: str, timeout: float = 5.0) -> tuple[int, str]:
    if shutil.which(args[0]) is None:
        return -1, ""
    try:
        proc = await asyncio.create_subprocess_exec(
            *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
        out, _ = await asyncio.wait_for(proc.communicate(), timeout)
    except (OSError, asyncio.TimeoutError):
        return -1, ""
    return proc.returncode or 0, out.decode("utf-8", "replace")


async def _processes() -> list[dict]:
    rc, out = await _run("ps", "-eo", "pid,pcpu,pmem,rss,comm", "--sort=-pcpu")
    if rc != 0:
        # BSD ps (macOS) has no --sort.
        rc, out = await _run("ps", "-Ao", "pid,pcpu,pmem,rss,comm", "-r")
    rows = []
    for line in out.splitlines()[1:TOP_PROCESSES + 1]:
        parts = line.split(None, 4)
        if len(parts) == 5:
            try:
                rows.append({"pid": int(parts[0]), "cpu": float(parts[1]),
                             "mem": float(parts[2]), "rss": int(parts[3]) * 1024,
                             "name": Path(parts[4]).name[:40]})
            except ValueError:
                continue
    return rows


async def _services() -> dict[str, str]:
    if shutil.which("systemctl") is None:
        return {}
    out = {}
    for name in SERVICES:
        _, state = await _run("systemctl", "is-active", f"{name}.service")
        out[name] = state.strip() or "unknown"
    return out


def _disks() -> list[dict]:
    seen, rows = set(), []
    for label, path in (("system", Path("/")), ("data", data_paths.data_dir())):
        try:
            usage = shutil.disk_usage(str(path))
            dev = os.stat(path).st_dev
        except OSError:
            continue
        if dev in seen:
            continue
        seen.add(dev)
        rows.append({"label": label, "path": str(path), "total": usage.total,
                     "used": usage.used, "free": usage.free})
    return rows


def _version() -> str:
    try:
        return (Path(__file__).parent / "VERSION").read_text().strip()
    except OSError:
        return ""


async def snapshot() -> Snapshot:
    mem = _meminfo()
    try:
        load = os.getloadavg()
    except OSError:
        load = None
    cpu, processes, services = await asyncio.gather(
        _cpu_percent(), _processes(), _services())
    snap = Snapshot(
        host=platform.node(), os=f"{platform.system()} {platform.release()}",
        uptime_sec=_uptime(), cpus=os.cpu_count() or 1,
        load=tuple(round(x, 2) for x in load) if load else None,
        cpu_percent=cpu,
        mem_total=mem.get("MemTotal"), mem_available=mem.get("MemAvailable"),
        swap_total=mem.get("SwapTotal"), swap_free=mem.get("SwapFree"),
        disks=_disks(), processes=processes, services=services,
        jarvis_rss=_rss_of(os.getpid()), version=_version())
    if not mem:
        snap.notes.append("memory figures are not available on this system")
    if not services and sys.platform.startswith("linux"):
        snap.notes.append("systemd is not available, so service states are unknown")
    return snap


def _gib(n: Optional[int]) -> str:
    if n is None:
        return "?"
    if n < 1024 ** 3:
        return f"{n / 1024 ** 2:.0f} MiB"
    return f"{n / 1024 ** 3:.1f} GiB"


def _duration(sec: Optional[float]) -> str:
    if sec is None:
        return "unknown"
    days, rem = divmod(int(sec), 86400)
    hours, rem = divmod(rem, 3600)
    return f"{days}d {hours}h" if days else f"{hours}h {rem // 60}m"


def describe(snap: Snapshot) -> str:
    """Compact text for the brain. Numbers, not a dump."""
    lines = [f"{snap.host} ({snap.os}), up {_duration(snap.uptime_sec)}"
             + (f", JARVIS {snap.version}" if snap.version else "") + "."]
    cpu = f"CPU {snap.cpu_percent}% of {snap.cpus} cores" if snap.cpu_percent is not None \
        else f"{snap.cpus} cores"
    if snap.load:
        cpu += f", load {snap.load[0]} / {snap.load[1]} / {snap.load[2]}"
    lines.append(cpu + ".")
    if snap.mem_total:
        used = snap.mem_total - (snap.mem_available or 0)
        line = (f"Memory {_gib(used)} used of {_gib(snap.mem_total)} "
                f"({100 * used // snap.mem_total}%)")
        if snap.swap_total:
            line += f", swap {_gib(snap.swap_total - (snap.swap_free or 0))} used"
        lines.append(line + f"; JARVIS itself {_gib(snap.jarvis_rss)}.")
    for d in snap.disks:
        pct = 100 * d["used"] // d["total"] if d["total"] else 0
        lines.append(f"Disk ({d['label']}) {_gib(d['used'])} used of {_gib(d['total'])} "
                     f"({pct}%), {_gib(d['free'])} free.")
    if snap.services:
        lines.append("Services: " + ", ".join(f"{k} {v}" for k, v in snap.services.items()) + ".")
    if snap.processes:
        lines.append("Busiest: " + "; ".join(
            f"{p['name']} {p['cpu']}% CPU {_gib(p['rss'])}" for p in snap.processes) + ".")
    lines.extend(f"({n})" for n in snap.notes)
    return "\n".join(lines)


_PROBLEM_WORDS = ("error", "fail", "warn", "refused", "traceback", "exception",
                  "denied", "timed out", "timeout")


async def recent_log(lines: int = 30, problems_only: bool = False) -> tuple[bool, str]:
    """(available, text) from JARVIS's own systemd journal.

    The service logs everything at one journal priority, so "problems only"
    is a word filter over a longer window, not `journalctl -p`.
    """
    lines = max(5, min(int(lines or 30), LOG_LINES_MAX))
    if shutil.which("journalctl") is None:
        return False, "There is no system journal on this machine."
    window = 600 if problems_only else lines
    rc, out = await _run("journalctl", "-u", "jarvis", "-n", str(window),
                         "--no-pager", "-o", "short-iso", timeout=8.0)
    if rc != 0:
        return False, ("I can't read the service log — the jarvis user needs "
                       "to be in the systemd-journal group.")
    rows = out.strip().splitlines()
    if problems_only:
        rows = [r for r in rows if any(w in r.lower() for w in _PROBLEM_WORDS)]
    rows = rows[-lines:]
    return True, "\n".join(rows) or "Nothing logged."
