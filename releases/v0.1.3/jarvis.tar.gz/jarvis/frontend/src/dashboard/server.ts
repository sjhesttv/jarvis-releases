// frontend/src/dashboard/server.ts
//
// The Server view: the machine JARVIS runs on (GET /api/system, the same
// snapshot the brain's system_status tool reads) and the files he has handed
// over (GET /api/files). Polls only while the tab is open.
//
// File names and process names are text other programs chose: textContent
// only, like every other view.
import { el, panel, bar, kv, row, button, emptyState, pill } from "./ui";

interface Disk { label: string; path: string; total: number; used: number; free: number }
interface Proc { pid: number; cpu: number; mem: number; rss: number; name: string }
interface SystemSnapshot {
  host: string; os: string; uptime_sec: number | null; cpus: number;
  load: number[] | null; cpu_percent: number | null;
  mem_total: number | null; mem_available: number | null;
  swap_total: number | null; swap_free: number | null;
  disks: Disk[]; processes: Proc[]; services: Record<string, string>;
  jarvis_rss: number | null; version: string; notes: string[];
}
interface FileRow { name: string; size: number; created: number; inline: boolean; url: string }

const POLL_MS = 10_000;
let root: HTMLElement | null = null;
let timer: number | undefined;

function size(bytes: number | null): string {
  if (bytes == null) return "?";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 ** 2) return `${Math.round(bytes / 1024)} KB`;
  if (bytes < 1024 ** 3) return `${Math.round(bytes / 1024 ** 2)} MB`;
  return `${(bytes / 1024 ** 3).toFixed(1)} GB`;
}

function uptime(sec: number | null): string {
  if (sec == null) return "?";
  const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  return d ? `${d}d ${h}h` : `${h}h ${m}m`;
}

function toneFor(pct: number): "ok" | "warn" | "bad" {
  return pct >= 90 ? "bad" : pct >= 75 ? "warn" : "ok";
}

function systemPanel(s: SystemSnapshot): HTMLElement {
  const p = panel("System", { meta: s.host });
  const gauges = el("div", "stack");
  if (s.cpu_percent != null) {
    const g = bar(`CPU · ${s.cpus} cores`, { tone: toneFor(s.cpu_percent) });
    g.set(s.cpu_percent, `${s.cpu_percent}%`);
    gauges.append(g.root);
  }
  if (s.mem_total) {
    const used = s.mem_total - (s.mem_available ?? 0);
    const pct = Math.round((100 * used) / s.mem_total);
    const g = bar("Memory", { tone: toneFor(pct) });
    g.set(pct, `${size(used)} of ${size(s.mem_total)}`);
    gauges.append(g.root);
  }
  for (const d of s.disks) {
    const pct = d.total ? Math.round((100 * d.used) / d.total) : 0;
    const g = bar(`Disk · ${d.label}`, { tone: toneFor(pct) });
    g.set(pct, `${size(d.free)} free of ${size(d.total)}`);
    gauges.append(g.root);
  }
  const facts = kv();
  facts.add("System", s.os);
  facts.add("Up", uptime(s.uptime_sec));
  if (s.load) facts.add("Load", s.load.join(" / "));
  if (s.version) facts.add("JARVIS", s.version);
  facts.add("JARVIS memory", size(s.jarvis_rss));
  for (const [name, state] of Object.entries(s.services)) {
    facts.add(name, state, state === "active" ? "ok" : "bad");
  }
  p.body.append(gauges, facts.root);
  for (const n of s.notes) p.body.append(emptyState(n, true));
  return p.root;
}

function processPanel(s: SystemSnapshot): HTMLElement {
  const p = panel("Busiest Processes", { quiet: true });
  if (!s.processes.length) p.body.append(emptyState("No process list on this system.", true));
  for (const proc of s.processes) {
    const r = row();
    r.setTitle(proc.name);
    r.addMeta(`${proc.cpu}% CPU`, { w: "8ch" });
    r.addMeta(size(proc.rss), { w: "8ch" });
    r.addMeta(`pid ${proc.pid}`, { w: "10ch" });
    p.body.append(r.root);
  }
  return p.root;
}

function filesPanel(files: FileRow[], onChange: () => void): HTMLElement {
  const p = panel("Files", { meta: files.length ? String(files.length) : "" });
  if (!files.length) {
    p.body.append(emptyState(
      "Nothing handed over yet. Ask JARVIS for a screenshot, a report, or a file from a project."));
  }
  for (const f of files) {
    const r = row();
    r.setTitle(f.name.replace(/^\d{8}-\d{6}-/, ""));
    r.setSub(new Date(f.created * 1000).toLocaleString());
    r.addMeta(size(f.size), { w: "8ch" });
    if (f.inline) {
      const view = el("a", "btn--quiet", "View");
      view.href = f.url;
      view.target = "_blank";
      view.rel = "noopener";
      r.addTrail(view);
    }
    const dl = el("a", undefined, "Download");
    dl.href = `${f.url}?download=1`;
    dl.setAttribute("download", f.name);
    r.addTrail(dl);
    r.addTrail(button("Delete", async () => {
      await fetch(f.url, { method: "DELETE" });
      onChange();
    }, { quiet: true, tone: "bad" }));
    p.body.append(r.root);
  }
  return p.root;
}

export async function refreshServer(): Promise<void> {
  if (!root) return;
  try {
    const [sysRes, filesRes] = await Promise.all([fetch("/api/system"), fetch("/api/files")]);
    if (!sysRes.ok || !filesRes.ok) throw new Error("server view fetch failed");
    const snap = (await sysRes.json()) as SystemSnapshot;
    const files = ((await filesRes.json()) as { files: FileRow[] }).files;
    root.replaceChildren(systemPanel(snap), filesPanel(files, () => void refreshServer()),
      processPanel(snap));
  } catch {
    root.replaceChildren(panel("System").root);
    root.firstElementChild?.append(pill("unavailable", "bad"));
  }
}

export function initServer(): void {
  root = document.getElementById("server-view");
}

export function showServer(visible: boolean): void {
  window.clearInterval(timer);
  if (!visible) return;
  void refreshServer();
  timer = window.setInterval(() => void refreshServer(), POLL_MS);
}
