"""Who is allowed to reach JARVIS's HTTP and WebSocket surface.

JARVIS spawns `claude --dangerously-skip-permissions` on request and reads
every conversation on the machine. Until this module existed, anything that
could open a TCP connection could do both: `POST /api/runs` was remote code
execution, and `/ws/voice` accepted a handshake from any web page the user
happened to be visiting and let it speak as them.

There are exactly two legitimate callers, and they prove themselves in
different ways:

**The browser.** It has no secret and must not need one — the user opens
Chrome, clicks once, and talks. But it is same-origin (Vite proxies `/api`
and `/ws` from :5173 to the API port, and the built frontend is served off
the API port itself), so every state-changing request and every WebSocket
handshake it makes carries an `Origin` header the browser sets and no page
can forge. That header is what admits it. A page on `http://evil.example`
— or on `http://localhost:3000`, which is just as much a stranger — sends
its own origin and is refused.

**A local non-browser client**: the brain's MCP child, a debugging script.
It sends no `Origin` at all, but it can read the tool token out of a 0600
file in the data directory, which only this user can open. That token is
what admits it.

So: a request is authorized if its `Origin` is one JARVIS actually serves
from, or if it carries the tool token. A WebSocket with no `Origin` is not a
browser; it is refused unless it has the token, because "no Origin" is
exactly what the LAN exploit looks like, and refusing it outright would
break the local clients that legitimately have no origin to send.

What this does NOT do, and cannot: an `Origin` header is only unforgeable
when a browser sets it. Anything speaking raw HTTP can send whatever origin
it likes. Against a non-browser attacker the defence is the token and the
loopback bind (`server.DEFAULT_BIND_HOST`), not this header.

Reads (`GET`, `HEAD`) are deliberately not gated on `Origin`. A same-origin
`GET` from fetch carries no `Origin` header at all, so gating them would
break the dashboard the moment it asked for `/api/runs`, and the browser has
no token to offer instead. What keeps a hostile page from *reading* those
responses is that JARVIS sends no CORS headers at all any more; what keeps a
LAN client from reading them is the loopback bind.

One thing does gate every request including the reads: `host_allowed`. DNS
rebinding is the way around "no CORS" — point evil.example at 127.0.0.1 and
the page and the response share an origin, so no CORS is needed. The `Host`
header is the only evidence of it, and a rebinding attack must name a domain
it controls, which has a dot in it.

Framing is the *other* way around the Origin check, and it forges nothing.
A hostile page iframes `http://localhost:8340/dashboard`, makes it
invisible, lays bait over the top, and harvests one click. The click lands
on JARVIS's own button, so the request it makes is made by JARVIS's own
page and carries the one `Origin` the guard exists to admit. Every response
therefore says it will not be framed — see `SECURITY_HEADERS`.
"""

from __future__ import annotations

import ipaddress
import logging
import os
import secrets
import sys
from typing import NamedTuple, Optional, Sequence
from urllib.parse import urlsplit

from starlette.responses import JSONResponse

import auth_store
import data_paths

log = logging.getLogger("jarvis.auth")

# The methods that can change something. A GET cannot be gated (see above),
# so anything with a side effect must not be one.
MUTATING_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})

# Every spelling of "this machine" a browser can put in an Origin.
LOOPBACK_HOSTS = ("localhost", "127.0.0.1", "[::1]")

# Vite's dev server. It takes the next free port when 5173 is busy, and the
# user must not have to discover that a second `npm run dev` broke JARVIS —
# so the window is a handful of ports wide, not one. Deliberately not "any
# loopback port": a page on http://localhost:3000 is somebody else's dev
# server and is exactly as much a stranger as evil.example.
#
# Measured, not assumed: with the shipped vite.config.ts the browser's own
# origin is what arrives here. Vite forwards `Origin` verbatim on the POST
# and on the WebSocket upgrade (and sends none on a same-origin GET, which
# is why GETs are not gated).
DEV_SERVER_PORTS = tuple(range(5173, 5181))

DEFAULT_API_PORT = 8340

# Sent on EVERY response JARVIS writes — HTML, JSON, static asset, 404, and
# the guard's own 403s. Not per-route: a header applied per route is a header
# somebody forgets on the route added next month.
#
#   frame-ancestors / X-Frame-Options
#       The clickjacking fix, and the reason this list exists. Both
#       spellings because they are not interchangeable: `X-Frame-Options` is
#       what a browser reads when it has no CSP support to speak of, and
#       `frame-ancestors` is what supersedes it everywhere else — and it is
#       the one that also covers `<object>`, `<embed>` and `<frame>`, so a
#       JSON response cannot be framed either.
#
#   nosniff
#       JARVIS answers with JSON that contains attacker-influenced text
#       (a prompt, a file path, an LLM's own words). Without this a browser
#       is free to decide a response "looks like" HTML and run it.
#
#   Referrer-Policy
#       The dashboard's URLs carry run ids and project paths. `no-referrer`
#       rather than `strict-origin-when-cross-origin`: nothing here has any
#       reason to tell an outside site it was visited from, so the strictest
#       value costs nothing.
#
# Deliberately NOT a full CSP. Every script on both pages is an external
# `<script type="module" src=...>` and every style an external stylesheet
# (verified in the source and the built output), so `script-src 'self'`
# would hold today — but it would only ever apply to the pages served off
# this port (in development they come from Vite, which sends none of this),
# and it would fail closed and silently the first time somebody inlined a
# script. `frame-ancestors` is the directive doing security work here.
SECURITY_HEADERS: tuple[tuple[bytes, bytes], ...] = (
    (b"x-frame-options", b"DENY"),
    (b"content-security-policy", b"frame-ancestors 'none'"),
    (b"x-content-type-options", b"nosniff"),
    (b"referrer-policy", b"no-referrer"),
)

_SECURITY_HEADER_NAMES = frozenset(name for name, _ in SECURITY_HEADERS)

# The one Referrer-Policy a response may choose instead of `no-referrer`.
#
# The sign-in page needs it. Under `no-referrer`, Chrome sends `Origin: null`
# on a plain HTML form POST (the Fetch spec serializes the origin as null for
# a no-cors request whose policy is no-referrer), so the login's own Origin
# check refused every real sign-in. `same-origin` sends nothing to any other
# site, which is all `no-referrer` was buying here, and lets the browser
# state the real Origin to JARVIS itself. Found on the first real droplet;
# reproduced and pinned with Playwright in tests/test_login_browser.py.
SAME_ORIGIN_REFERRER = b"same-origin"


def apply_security_headers(raw_headers) -> list[tuple[bytes, bytes]]:
    """Our values, replacing rather than joining any that are already there.

    Appending would produce `X-Frame-Options: SAMEORIGIN, DENY`, which is
    two conflicting policies and which several browsers resolve by ignoring
    the header entirely. These are the security headers; ours win.
    """
    raw_headers = list(raw_headers or ())
    # A route may make its CSP STRICTER (a download adds `sandbox`, so an
    # HTML or SVG file can never run script on this origin). Ours is joined
    # onto it, never dropped: frame-ancestors still applies.
    own_csp = [value for name, value in raw_headers
               if name.lower() == b"content-security-policy"]
    own_referrer = any(name.lower() == b"referrer-policy"
                       and value.strip().lower() == SAME_ORIGIN_REFERRER
                       for name, value in raw_headers)
    kept = [(name, value) for name, value in raw_headers
            if name.lower() not in _SECURITY_HEADER_NAMES]
    for name, value in SECURITY_HEADERS:
        if name == b"referrer-policy" and own_referrer:
            value = SAME_ORIGIN_REFERRER
        if name == b"content-security-policy" and own_csp:
            value = value + b"; " + b"; ".join(v.strip().rstrip(b";") for v in own_csp)
        kept.append((name, value))
    return kept


# ---------------------------------------------------------------------------
# Where this process is actually listening
# ---------------------------------------------------------------------------
#
# Three things need to know: the origin allowlist, the Host allowlist, and
# the URL the brain's MCP child dials. All three read JARVIS_PORT /
# JARVIS_BIND_HOST / JARVIS_SCHEME, and until now only `server.main()` ever
# wrote them. So `python server.py --port 9000` worked and
#
#     uvicorn server:app --port 9000
#
# did not: nothing set the variables, the allowlist was still built for
# 8340, and the operator's own browser at http://localhost:9000 was refused
# by JARVIS's own guard. `uvicorn server:app` on uvicorn's default port 8000
# had the same problem, and so did the `--host 0.0.0.0` warning, which was
# printed from `__main__` and therefore never seen by the one launch path
# that most needed it.
#
# The app cannot ask uvicorn where it bound: uvicorn runs the ASGI lifespan
# *before* it creates its sockets (`Server.startup` calls
# `lifespan.startup()` first), so at the moment this is needed there is no
# socket to interrogate. What is left is what the process was launched with:
# the environment, then the command line, then the launcher's own documented
# defaults — and, when even that is not enough, saying so out loud instead
# of guessing.

# Uvicorn's own CLI defaults, which are not JARVIS's.
UVICORN_DEFAULT_HOST = "127.0.0.1"
UVICORN_DEFAULT_PORT = 8000

# JARVIS's, per `server.main()`'s argparse defaults.
JARVIS_DEFAULT_HOST = "127.0.0.1"
JARVIS_DEFAULT_PORT = DEFAULT_API_PORT

# Every spelling of "only this machine" that can be *bound* to. Wider than
# LOOPBACK_HOSTS above, which is about what a browser puts in an Origin:
# 127.0.0.0/8 is all loopback, and an operator may well bind 127.0.0.2.
_LOOPBACK_NAMES = frozenset({"localhost"})

# Flags that name a listening socket this cannot reason about as an address.
_OPAQUE_BIND_FLAGS = ("--uds", "--fd")


class Bind(NamedTuple):
    """Where the server is listening, and how confident we are about it.

    `source` is part of the value on purpose. "unknown" is a real answer and
    it must be able to travel: adopting a guessed bind would build an origin
    allowlist for a port nothing is listening on and lock the operator out
    of their own dashboard without a word.
    """

    host: str
    port: int
    scheme: str
    source: str


def is_loopback(host: Optional[str]) -> bool:
    """Does binding here mean "only this machine can reach it"?"""
    if not host:
        return False
    name = host.strip().strip("[]").lower()
    if name in _LOOPBACK_NAMES:
        return True
    try:
        return ipaddress.ip_address(name).is_loopback
    except ValueError:
        return False


def _flag(argv: Sequence[str], name: str) -> Optional[str]:
    """`--name value` or `--name=value`; the last occurrence wins, as click's
    own parsing does."""
    found = None
    for i, arg in enumerate(argv):
        if arg == name and i + 1 < len(argv):
            found = argv[i + 1]
        elif arg.startswith(f"{name}="):
            found = arg[len(name) + 1:]
    return found


def detect_bind(argv: Sequence[str] | None = None,
                environ=None) -> Bind:
    """The address this process is listening on, as well as it can be known.

    The environment first — `server.main()` records its parsed arguments
    there, and an operator behind a launcher this cannot read can set the
    same variables by hand. Then the command line, which covers both
    `python server.py --host ...` and `uvicorn server:app --host ...`
    because both spell it the same way. Then the defaults of whichever
    launcher this looks like.
    """
    argv = list(sys.argv if argv is None else argv)
    environ = os.environ if environ is None else environ

    launcher = (argv[0] if argv else "").rsplit("/", 1)[-1].lower()
    uvicorn_cli = launcher.startswith("uvicorn")
    default_host = UVICORN_DEFAULT_HOST if uvicorn_cli else JARVIS_DEFAULT_HOST
    default_port = UVICORN_DEFAULT_PORT if uvicorn_cli else JARVIS_DEFAULT_PORT

    env_host = (environ.get("JARVIS_BIND_HOST") or "").strip()
    env_port = (environ.get("JARVIS_PORT") or "").strip()
    env_scheme = (environ.get("JARVIS_SCHEME") or "").strip()

    argv_host = _flag(argv, "--host")
    argv_port = _flag(argv, "--port")
    ssl_flagged = any(a == f or a.startswith(f"{f}=") for a in argv
                      for f in ("--ssl-keyfile", "--ssl-certfile", "--ssl"))

    host = env_host or argv_host or default_host
    scheme = env_scheme or ("https" if ssl_flagged else "http")

    port = default_port
    # First that parses wins, in the same order as the host: environment,
    # then command line, then the launcher's default.
    for candidate in (env_port, argv_port):
        if not candidate:
            continue
        try:
            port = int(candidate)
            break
        except (TypeError, ValueError):
            log.warning("ignoring a port that is not a number: %r", candidate)

    if env_host or env_port:
        source = "environment"
    elif any(a == f or a.startswith(f"{f}=") for a in argv
             for f in _OPAQUE_BIND_FLAGS):
        # A unix socket or an inherited fd. Not an address, and pretending
        # otherwise would build the wrong allowlist in silence.
        source = "unknown"
    elif argv_host or argv_port:
        source = "command line"
    elif uvicorn_cli:
        source = "uvicorn default"
    else:
        source = "default"

    return Bind(host, port, scheme, source)


def adopt_bind(bind: Bind) -> None:
    """Publish a detected bind so the allowlists and the MCP URL see it.

    `setdefault`, never overwrite: `server.main()` writes these before
    uvicorn even starts and it is the one launcher that knows for certain.
    A bind whose source is "unknown" is not published at all — the existing
    defaults are a better guess than a wrong certainty.
    """
    if bind.source == "unknown":
        return
    os.environ.setdefault("JARVIS_BIND_HOST", bind.host)
    os.environ.setdefault("JARVIS_PORT", str(bind.port))
    os.environ.setdefault("JARVIS_SCHEME", bind.scheme)


def exposure_warning(bind: Bind) -> list[str]:
    """What to tell the operator, or [] when there is nothing to tell.

    Everything on this surface acts with the user's full authority:
    `/api/runs` spawns `claude --dangerously-skip-permissions`,
    `/api/sessions` reads every conversation on the machine. The Origin
    check makes those safe from a hostile *page*, but an Origin header is
    only unforgeable when a browser sets it — anything speaking raw HTTP can
    claim to be the dashboard. The tool token is the answer for a local
    client; there is no answer for a LAN client except not being on the LAN.
    """
    if bind.source == "unknown":
        return [
            "! JARVIS could not work out what address it is listening on",
            "  from how it was launched, so its own origin and Host checks",
            "  are using defaults that may be wrong — the browser may be",
            "  refused. Set JARVIS_BIND_HOST and JARVIS_PORT to the address",
            "  you are actually serving from.",
        ]
    if is_loopback(bind.host):
        return []
    if auth_required():
        return [
            f"  Bound to {bind.host}, not loopback. A password is set, so",
            "  every request must sign in. Serve it over HTTPS.",
        ]
    return [
        f"! Bound to {bind.host}, not loopback. Anything that can",
        "  reach this port can read every conversation on this",
        "  machine; only the tool token stands in front of the",
        "  endpoints that act. Bind 127.0.0.1 unless you mean it —",
        "  and if you do, set JARVIS_ALLOWED_ORIGINS to the address",
        "  you will open the page at, or the browser will be",
        "  refused too.",
    ]


def api_port() -> int:
    """The port this server is actually bound to, per main()."""
    try:
        return int(os.getenv("JARVIS_PORT", "") or DEFAULT_API_PORT)
    except ValueError:
        return DEFAULT_API_PORT


def allowed_origins() -> frozenset[str]:
    """The origins JARVIS serves its own pages from — and nothing else.

    Recomputed per call rather than cached: the port is only known once
    main() has parsed its arguments, and the test suite moves it.
    """
    ports = {api_port(), *DEV_SERVER_PORTS}
    origins = {
        f"{scheme}://{host}:{port}"
        for scheme in ("http", "https")
        for host in LOOPBACK_HOSTS
        for port in ports
    }
    for extra in os.getenv("JARVIS_ALLOWED_ORIGINS", "").split(","):
        extra = extra.strip().rstrip("/")
        if extra:
            origins.add(extra)
    return frozenset(origins)


def origin_allowed(origin: Optional[str]) -> bool:
    """Exact match only.

    Never a prefix or suffix test: `http://localhost:5173.evil.example` and
    `http://localhost:51730` both start with an allowed origin, and `null`
    (what a sandboxed iframe or a file:// page sends) is not this machine.
    """
    if not origin:
        return False
    return origin in allowed_origins()


def allowed_hosts() -> frozenset[str]:
    """Host names an operator has said this server answers to.

    The bind host counts: `python server.py --host jarvis.example.com` is
    the operator saying that name IS this server, and the brain's own MCP
    child dials whatever main() was given. Every other dotted name has to be
    named in JARVIS_ALLOWED_ORIGINS.
    """
    hosts = set()
    bind = os.getenv("JARVIS_BIND_HOST", "").strip().strip("[]").lower()
    if bind:
        hosts.add(bind)
    for origin in os.getenv("JARVIS_ALLOWED_ORIGINS", "").split(","):
        origin = origin.strip()
        if not origin:
            continue
        try:
            name = urlsplit(origin).hostname
        except ValueError:
            continue
        if name:
            hosts.add(name.lower())
    return frozenset(hosts)


def host_allowed(host_header: Optional[str]) -> bool:
    """Refuse a `Host` that names a domain. This is the rebinding check.

    The reads — /api/sessions, /api/specs/doc — cannot be gated on Origin,
    because a same-origin GET from fetch does not send one. What stops a
    hostile page reading them is that JARVIS answers with no CORS headers.
    DNS rebinding goes around that: evil.example resolves to 127.0.0.1, the
    browser sends `Host: evil.example`, and the page and the response now
    share an origin, so no CORS is needed at all.

    The Host header is the only evidence that this happened, and it is
    enough. A rebinding attack has to name a domain it controls in public
    DNS, and a public domain has a dot in it. An address literal is not a
    name and has nothing to rebind; a single-label host (`localhost`, a
    machine name, `testserver`) cannot be a public domain. Anything dotted
    has to be declared in JARVIS_ALLOWED_ORIGINS — which an operator
    reaching JARVIS at a .local or tailscale name has already had to set for
    the Origin check anyway.
    """
    if not host_header:
        return True                    # HTTP/1.0, and some local clients
    try:
        hostname = urlsplit(f"//{host_header}").hostname or ""
    except ValueError:
        return False
    if not hostname:
        return False
    hostname = hostname.lower()
    if hostname in allowed_hosts():
        return True
    try:
        ipaddress.ip_address(hostname.strip("[]"))
        return True
    except ValueError:
        pass
    return "." not in hostname


def bearer(header_value: Optional[str]) -> Optional[str]:
    """The token out of an `Authorization: Bearer <token>` header."""
    if not header_value or len(header_value) < 8:
        return None
    if header_value[:7].lower() != "bearer ":
        return None
    return header_value[7:].strip() or None


def token_matches(supplied: Optional[str]) -> bool:
    """Constant-time compare against the per-install tool token.

    The token file is only touched when a caller actually offered one, so
    the common path — a browser with a good origin — does no disk I/O.
    """
    if not supplied:
        return False
    try:
        expected = data_paths.ensure_tool_token()
    except Exception as e:                                   # pragma: no cover
        log.error(f"could not read the tool token: {e}")
        return False
    try:
        return secrets.compare_digest(supplied.encode("utf-8", "ignore"),
                                      expected.encode("utf-8"))
    except (TypeError, ValueError):                          # pragma: no cover
        return False


def request_authorized(origin: Optional[str],
                       authorization: Optional[str]) -> bool:
    return origin_allowed(origin) or token_matches(bearer(authorization))


def _header(scope: dict, name: bytes) -> Optional[str]:
    for key, value in scope.get("headers") or ():
        if key.lower() == name:
            return value.decode("latin-1")
    return None


def scope_authorized(scope: dict) -> bool:
    return request_authorized(_header(scope, b"origin"),
                              _header(scope, b"authorization"))


# ---------------------------------------------------------------------------
# The owner's login (issue #1)
# ---------------------------------------------------------------------------
#
# Off until a password exists (`auth_store.password_configured`), so a Mac
# install that never set one behaves exactly as before. Mandatory in cloud
# mode: `server.lifespan` refuses to start without it.
#
# Once on, the Origin check above stops being what admits a browser and goes
# back to being what it always really was, a CSRF defence: a request must now
# be AUTHENTICATED (session cookie or tool token) and, if it changes
# something, ALSO come from a page JARVIS serves. A forged Origin from curl
# gets nothing without the cookie.

LOGIN_PATH = "/login"
LOGOUT_PATH = "/logout"

# Paths a browser that is not logged in may fetch. Nothing else.
PUBLIC_PATHS = frozenset({LOGIN_PATH})

_MAX_LOGIN_BODY = 4096


def auth_required() -> bool:
    return auth_store.password_configured()


def _cookie(scope: dict, name: str) -> Optional[str]:
    raw = _header(scope, b"cookie")
    if not raw:
        return None
    for part in raw.split(";"):
        key, sep, value = part.strip().partition("=")
        if sep and key == name:
            return value
    return None


def scope_authenticated(scope: dict) -> bool:
    """Is this the owner — a valid session cookie, or the tool token?"""
    if auth_store.session_valid(_cookie(scope, auth_store.SESSION_COOKIE)):
        return True
    return token_matches(bearer(_header(scope, b"authorization")))


def _trust_proxy() -> bool:
    return (os.getenv("JARVIS_TRUST_PROXY") or "").strip().lower() in (
        "1", "true", "yes", "on")


def client_address(scope: dict) -> str:
    """Who is knocking, for the login limiter.

    Behind the cloud deployment's Caddy every connection comes from
    127.0.0.1, so the address Caddy saw is taken from the LAST
    X-Forwarded-For entry (the one Caddy appended itself; anything before it
    the client wrote) — but only when JARVIS_TRUST_PROXY says a proxy is
    there and the peer really is loopback.
    """
    peer = (scope.get("client") or ("?", 0))[0] or "?"
    if _trust_proxy() and is_loopback(peer):
        forwarded = _header(scope, b"x-forwarded-for")
        if forwarded:
            last = forwarded.split(",")[-1].strip()
            if last:
                return last
    return peer


def _request_is_https(scope: dict) -> bool:
    if scope.get("scheme") in ("https", "wss"):
        return True
    if (os.getenv("JARVIS_PUBLIC_URL") or "").lower().startswith("https://"):
        return True
    if _trust_proxy() and is_loopback((scope.get("client") or ("", 0))[0]):
        return (_header(scope, b"x-forwarded-proto") or "").lower() == "https"
    return False


def _session_cookie_header(scope: dict, value: str, max_age: int) -> bytes:
    parts = [f"{auth_store.SESSION_COOKIE}={value}", "Path=/", "HttpOnly",
             "SameSite=Strict", f"Max-Age={max_age}"]
    if _request_is_https(scope):
        parts.append("Secure")
    return "; ".join(parts).encode("latin-1")


def safe_next(target: Optional[str]) -> str:
    """Where to go after logging in: a local path, never another site."""
    if (not target or not target.startswith("/") or target.startswith("//")
            or "\\" in target or any(ord(c) < 32 for c in target)):
        return "/"
    if target.startswith(LOGIN_PATH):
        return "/"
    return target


def _wants_html(scope: dict) -> bool:
    if scope.get("method", "GET").upper() not in ("GET", "HEAD"):
        return False
    path = scope.get("path", "")
    if path.startswith(("/api/", "/ws", "/internal/")):
        return False
    return True


def _html_escape(text: str) -> str:
    return (text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;").replace("'", "&#39;"))


def login_page(next_path: str = "/", error: str = "") -> str:
    """The one page a stranger can see. Self-contained: no script at all."""
    message = (f'<p class="err" role="alert">{_html_escape(error)}</p>'
               if error else "")
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex">
<meta name="referrer" content="same-origin">
<title>JARVIS · Sign in</title>
<style>
:root{{color-scheme:dark}}
body{{margin:0;min-height:100vh;display:grid;place-items:center;
background:#05080c;color:#cfe8ff;font:16px/1.4 -apple-system,system-ui,sans-serif}}
form{{width:min(340px,calc(100vw - 32px));padding:28px;border:1px solid #1d3a52;
border-radius:14px;background:#0a1219}}
h1{{margin:0 0 4px;font-size:20px;letter-spacing:.3em}}
p{{margin:0 0 20px;color:#7fa3c0;font-size:14px}}
label{{display:block;font-size:13px;color:#7fa3c0;margin-bottom:6px}}
input{{box-sizing:border-box;width:100%;padding:11px 12px;border-radius:8px;
border:1px solid #2a4f6e;background:#05080c;color:#e6f3ff;font-size:16px}}
input:focus{{outline:2px solid #4fb3ff;outline-offset:1px}}
button{{margin-top:16px;width:100%;padding:11px;border:0;border-radius:8px;
background:#4fb3ff;color:#031019;font-weight:600;font-size:15px;cursor:pointer}}
.err{{color:#ff8a8a;margin:12px 0 0}}
</style></head>
<body><form method="post" action="{LOGIN_PATH}">
<h1>JARVIS</h1><p>At your service, once you have signed in.</p>
<label for="pw">Password</label>
<input id="pw" name="password" type="password" autocomplete="current-password" autofocus required>
<input type="hidden" name="next" value="{_html_escape(next_path)}">
<button type="submit">Sign in</button>{message}
</form></body></html>"""


async def _read_body(receive, limit: int) -> Optional[bytes]:
    body = b""
    while True:
        message = await receive()
        if message.get("type") != "http.request":
            return None
        body += message.get("body", b"")
        if len(body) > limit:
            return None
        if not message.get("more_body"):
            return body


async def _send_html(send, status: int, html: str,
                     extra_headers: list[tuple[bytes, bytes]] = ()) -> None:
    body = html.encode("utf-8")
    await send({"type": "http.response.start", "status": status,
                "headers": [(b"content-type", b"text/html; charset=utf-8"),
                            (b"content-length", str(len(body)).encode()),
                            (b"cache-control", b"no-store"),
                            # Only the sign-in page is sent through here; see
                            # SAME_ORIGIN_REFERRER for why it needs this.
                            (b"referrer-policy", SAME_ORIGIN_REFERRER),
                            *extra_headers]})
    await send({"type": "http.response.body", "body": body})


async def _redirect(send, location: str,
                    extra_headers: list[tuple[bytes, bytes]] = ()) -> None:
    await send({"type": "http.response.start", "status": 303,
                "headers": [(b"location", location.encode("latin-1", "ignore")),
                            (b"content-length", b"0"),
                            (b"cache-control", b"no-store"),
                            *extra_headers]})
    await send({"type": "http.response.body", "body": b""})


async def handle_login(scope, receive, send) -> None:
    """GET shows the form; POST checks the password and sets the cookie."""
    from urllib.parse import parse_qs

    method = scope.get("method", "GET").upper()
    query = parse_qs((scope.get("query_string") or b"").decode("latin-1"))
    if method in ("GET", "HEAD"):
        if scope_authenticated(scope):
            await _redirect(send, safe_next((query.get("next") or ["/"])[0]))
            return
        await _send_html(send, 200, login_page(safe_next((query.get("next") or ["/"])[0])))
        return
    if method != "POST":
        await _send_html(send, 405, login_page(error="Use the form."))
        return

    # A login form posted from someone else's page is a login-CSRF; refuse it
    # the same way any other cross-site POST is refused.
    if not origin_allowed(_header(scope, b"origin")):
        await _send_html(send, 403, login_page(
            error="That sign-in did not come from this page."))
        return

    address = client_address(scope)
    if auth_store.LIMITER.blocked(address):
        log.warning("login refused: too many failures (from %s)", address)
        await _send_html(send, 429, login_page(
            error="Too many attempts. Wait fifteen minutes and try again."))
        return

    body = await _read_body(receive, _MAX_LOGIN_BODY)
    form = parse_qs((body or b"").decode("utf-8", "ignore"))
    password = (form.get("password") or [""])[0]
    next_path = safe_next((form.get("next") or ["/"])[0])

    if not auth_store.verify_password(password, auth_store.stored_hash()):
        auth_store.LIMITER.failed(address)
        log.warning("login failed from %s", address)
        await _send_html(send, 401, login_page(next_path, "That is not the password."))
        return

    auth_store.LIMITER.succeeded(address)
    log.info("login from %s", address)
    cookie = _session_cookie_header(scope, auth_store.issue_session(),
                                    auth_store.SESSION_SECONDS)
    await _redirect(send, next_path, [(b"set-cookie", cookie)])


async def handle_logout(scope, receive, send) -> None:
    cookie = _session_cookie_header(scope, "", 0)
    await _redirect(send, LOGIN_PATH, [(b"set-cookie", cookie)])


class OriginGuard:
    """One gate in front of everything, rather than a check per route.

    A raw ASGI middleware and not `@app.middleware("http")` on purpose:
    BaseHTTPMiddleware passes WebSocket scopes straight through, and the
    WebSockets are where the worst of it was. Sitting above the router also
    means a route added later is covered the day it is written, instead of
    the day somebody remembers.
    """

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        kind = scope.get("type")
        # Wrapped before anything else so the refusals written below carry
        # the headers too — they never reach the router, so a middleware
        # further in could not have added them.
        if kind == "http":
            send = self._with_security_headers(send)
        # The Host check covers every method, reads included: it is the only
        # evidence of a DNS rebind, which is how a page makes a loopback GET
        # same-origin and so needs no CORS from us at all.
        if kind in ("http", "websocket") and not host_allowed(
                _header(scope, b"host")):
            self._log_refusal(scope, f"{kind} (host)")
            if kind == "websocket":
                await send({"type": "websocket.close", "code": 1008})
            else:
                await JSONResponse(
                    status_code=403,
                    content={"error": "Refused: that Host is not one JARVIS "
                                      "answers to."})(scope, receive, send)
            return
        path = scope.get("path", "")
        if kind == "http" and auth_required():
            if path == LOGIN_PATH:
                await handle_login(scope, receive, send)
                return
            if path == LOGOUT_PATH and scope.get("method", "").upper() == "POST":
                if not origin_allowed(_header(scope, b"origin")):
                    await JSONResponse(status_code=403, content={
                        "error": "Refused: cross-site logout."})(scope, receive, send)
                    return
                await handle_logout(scope, receive, send)
                return
        if kind in ("http", "websocket") and auth_required() \
                and path not in PUBLIC_PATHS and not scope_authenticated(scope):
            self._log_refusal(scope, f"{kind} (not signed in)")
            if kind == "websocket":
                await send({"type": "websocket.close", "code": 1008})
            elif _wants_html(scope):
                from urllib.parse import quote
                query = (scope.get("query_string") or b"").decode("latin-1")
                target = path + (f"?{query}" if query else "")
                await _redirect(send, f"{LOGIN_PATH}?next={quote(safe_next(target), safe='/')}")
            else:
                await JSONResponse(
                    status_code=401,
                    headers={"x-jarvis-login": "required"},
                    content={"error": "Sign in first.",
                             "login": LOGIN_PATH})(scope, receive, send)
            return
        if kind == "websocket":
            if not scope_authorized(scope):
                self._log_refusal(scope, "websocket")
                # Closing before `accept` is how ASGI says "no": uvicorn
                # turns it into an HTTP 403 and the socket never opens.
                await send({"type": "websocket.close", "code": 1008})
                return
        elif kind == "http" and scope.get("method", "").upper() in MUTATING_METHODS:
            if not scope_authorized(scope):
                self._log_refusal(scope, scope.get("method", "?"))
                response = JSONResponse(
                    status_code=403,
                    content={"error": "Refused: this request did not come "
                                      "from a page JARVIS serves, and "
                                      "carried no tool token."})
                await response(scope, receive, send)
                return
        await self.app(scope, receive, send)

    @staticmethod
    def _with_security_headers(send):
        """Add SECURITY_HEADERS to the response start message.

        A raw ASGI wrapper rather than a `BaseHTTPMiddleware` on top,
        because BaseHTTPMiddleware would buffer every streamed response
        (`/ws` aside, the run event feed and static files both stream) and
        because this guard already has to be raw ASGI to see WebSockets.

        Only `http.response.start` is touched; body chunks and the
        WebSocket message types pass through untouched.
        """
        async def send_wrapper(message):
            if message.get("type") == "http.response.start":
                message = dict(message)
                message["headers"] = apply_security_headers(
                    message.get("headers"))
            await send(message)

        return send_wrapper

    @staticmethod
    def _log_refusal(scope: dict, what: str) -> None:
        log.warning("refused %s %s from origin %r",
                    what, scope.get("path", "?"),
                    _header(scope, b"origin") or "<none>")
