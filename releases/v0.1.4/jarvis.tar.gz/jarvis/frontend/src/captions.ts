/**
 * The caption bar along the bottom of the voice page, and the "file ready"
 * cards above it.
 *
 * Captions: the server streams each reply as `{"type":"caption", utt, delta}`
 * while the brain writes it (after the one-line-per-turn filter, so it is
 * exactly what will be spoken). Scripted lines (greetings, notices) have no
 * deltas; for those the text of each `audio` chunk is shown as it plays.
 * Words fade in as they arrive; the bar fades out a while after JARVIS stops.
 *
 * Files: `{"type":"file", name, url, inline, what}` when JARVIS hands
 * something over. A card with a download link (and a thumbnail for images).
 *
 * textContent and createElement only: this is model output and file names.
 */

const FADE_AFTER_MS = 7000;
const MAX_WORDS = 90;              // keep the bar to a couple of lines
const MAX_CARDS = 3;

let bar: HTMLElement | null = null;
let line: HTMLElement | null = null;
let currentUtt: number | null = null;
const streamed = new Set<number>();  // utterances that arrive as deltas
let pending = "";                    // a word not yet finished
let fadeTimer: number | undefined;
let cards: HTMLElement | null = null;

function ensure(): void {
  if (bar) return;
  bar = document.createElement("div");
  bar.id = "caption-bar";
  bar.setAttribute("aria-live", "polite");
  line = document.createElement("div");
  line.className = "caption-line";
  bar.appendChild(line);
  document.body.appendChild(bar);
  cards = document.createElement("div");
  cards.id = "file-cards";
  document.body.appendChild(cards);
}

function plain(text: string): string {
  // What TTS strips before speaking, so the caption reads like the voice.
  return text.replace(/[*_`#>]+/g, "");
}

function startUtterance(utt: number): void {
  ensure();
  if (currentUtt === utt) return;
  currentUtt = utt;
  pending = "";
  line!.replaceChildren();
}

function addWord(word: string): void {
  const span = document.createElement("span");
  span.className = "caption-word";
  span.textContent = word + " ";
  line!.appendChild(span);
  while (line!.childElementCount > MAX_WORDS) line!.firstElementChild?.remove();
  show();
}

function addText(text: string, final: boolean): void {
  pending += plain(text);
  const parts = pending.split(/\s+/);
  pending = final ? "" : parts.pop() ?? "";
  for (const w of parts) if (w) addWord(w);
}

function show(): void {
  bar!.classList.add("visible");
  window.clearTimeout(fadeTimer);
  fadeTimer = window.setTimeout(() => bar?.classList.remove("visible"), FADE_AFTER_MS);
}

/** A delta of the reply being written. */
export function captionDelta(utt: number, delta: string): void {
  startUtterance(utt);
  streamed.add(utt);
  if (streamed.size > 50) streamed.delete(streamed.values().next().value as number);
  addText(delta, false);
}

/** An audio chunk starting to play; captions scripted lines. */
export function captionAudio(utt: number, text: string): void {
  if (!text || streamed.has(utt)) return;
  startUtterance(utt);
  addText(text + " ", true);
}

/** JARVIS went quiet: finish the last word and start the fade. */
export function captionIdle(): void {
  if (!line) return;
  if (pending) {
    addWord(pending);
    pending = "";
  }
  show();
}

function humanSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
}

/** JARVIS handed over a file. */
export function fileReady(msg: Record<string, unknown>): void {
  ensure();
  const name = String(msg.name ?? "");
  const url = String(msg.url ?? "");
  if (!name || !url.startsWith("/api/files/")) return;
  const card = document.createElement("div");
  card.className = "file-card";

  if (msg.inline) {
    const img = document.createElement("img");
    img.src = url;
    img.alt = "";
    img.className = "file-thumb";
    const view = document.createElement("a");
    view.href = url;
    view.target = "_blank";
    view.rel = "noopener";
    view.appendChild(img);
    card.appendChild(view);
  }
  const text = document.createElement("div");
  text.className = "file-text";
  const title = document.createElement("div");
  title.className = "file-name";
  title.textContent = name.replace(/^\d{8}-\d{6}-/, "");
  const meta = document.createElement("div");
  meta.className = "file-meta";
  meta.textContent = `${String(msg.what ?? "file")} · ${humanSize(Number(msg.size ?? 0))}`;
  text.append(title, meta);

  const actions = document.createElement("div");
  actions.className = "file-actions";
  const dl = document.createElement("a");
  dl.href = `${url}?download=1`;
  dl.textContent = "Download";
  dl.setAttribute("download", name);
  const close = document.createElement("button");
  close.type = "button";
  close.textContent = "×";
  close.title = "Dismiss";
  close.addEventListener("click", () => card.remove());
  actions.append(dl, close);

  card.append(text, actions);
  cards!.prepend(card);
  while (cards!.childElementCount > MAX_CARDS) cards!.lastElementChild?.remove();
}


/** JARVIS has memories for the user to review on the dashboard. */
export function proposalsReady(count: number): void {
  ensure();
  if (!count) return;
  cards!.querySelector(".file-card--memory")?.remove();
  const card = document.createElement("div");
  card.className = "file-card file-card--memory";
  const text = document.createElement("div");
  text.className = "file-text";
  const title = document.createElement("div");
  title.className = "file-name";
  title.textContent = `${count} thing${count === 1 ? "" : "s"} worth remembering`;
  const meta = document.createElement("div");
  meta.className = "file-meta";
  meta.textContent = "Approve or dismiss them in the dashboard's Memory tab";
  text.append(title, meta);
  const actions = document.createElement("div");
  actions.className = "file-actions";
  const open = document.createElement("a");
  open.href = "/dashboard";
  open.target = "_blank";
  open.rel = "noopener";
  open.textContent = "Review";
  const close = document.createElement("button");
  close.type = "button";
  close.textContent = "×";
  close.addEventListener("click", () => card.remove());
  actions.append(open, close);
  card.append(text, actions);
  cards!.prepend(card);
}
