"""Memories JARVIS proposes after a conversation, for the user to approve.

Nothing here writes a memory on its own. After a quiet spell the server asks
the brain, in a silent background turn, what from the recent conversation is
worth keeping; the answers wait in `<brain home>/proposals.json` until the
user approves, edits or dismisses each one on the dashboard. Approving is
what calls `jarvis_memory.write_memory` / `add_to_index`, so the user is the
one who writes it — the same rule as `remember`, which only runs on his
word.

`review_prompt` builds the request and `parse_reply` reads the brain's JSON
back defensively: a reply that is not the shape asked for proposes nothing.
"""

from __future__ import annotations

import json
import re
import secrets
import threading
import time
from pathlib import Path
from typing import Optional

import auth_store
import data_paths
import jarvis_memory
from conversation_log import Exchange

IDLE_BEFORE_REVIEW_SEC = 10 * 60
MIN_EXCHANGES = 2
MAX_PROPOSALS = 5
MAX_PENDING = 40
TITLE_MAX = 80
HOOK_MAX = 140
BODY_MAX = 1200

_lock = threading.Lock()


def _path() -> Path:
    return data_paths.brain_home() / "proposals.json"


def load() -> dict:
    try:
        body = json.loads(_path().read_text())
    except (OSError, ValueError):
        body = {}
    if not isinstance(body, dict):
        body = {}
    body.setdefault("last_reviewed", 0.0)
    pending = body.get("pending")
    body["pending"] = [p for p in pending if isinstance(p, dict)] if isinstance(pending, list) else []
    return body


def _save(body: dict) -> None:
    data_paths.brain_home().mkdir(parents=True, exist_ok=True)
    auth_store.write_private(_path(), json.dumps(body, indent=2) + "\n")


def pending() -> list[dict]:
    return load()["pending"]


def last_reviewed() -> float:
    return float(load().get("last_reviewed") or 0.0)


def mark_reviewed(at: Optional[float] = None) -> None:
    with _lock:
        body = load()
        body["last_reviewed"] = at or time.time()
        _save(body)


def review_prompt(exchanges: list[Exchange], known_titles: list[str]) -> str:
    convo = "\n".join(f"[{e.day} {e.time[:5]}] He: {e.you}\n[{e.day} {e.time[:5]}] You: {e.jarvis}"
                      for e in exchanges)
    known = "; ".join(known_titles[:60]) or "none yet"
    return (
        "HOUSEKEEPING, from your own server — not the user, and nothing you "
        "write now is spoken. Read the conversation below and propose at most "
        f"{MAX_PROPOSALS} things worth remembering for good: facts about him, "
        "his preferences, his projects, decisions made, standing instructions. "
        "Skip small talk, one-off requests and anything already remembered "
        f"(already remembered: {known}). Reply with ONLY a JSON array, no "
        'prose, each item {"title": "short name", "hook": "one line", '
        '"body": "the fact, in a sentence or two"}. Reply [] if nothing '
        "qualifies. Do not call any tools.\n\n<conversation>\n"
        f"{convo}\n</conversation>")


def _clean(value: object, limit: int) -> str:
    return jarvis_memory.one_line(str(value or ""), limit)


def parse_reply(text: str) -> list[dict]:
    """The proposals in a reply, or [] for anything that is not the shape."""
    if not text:
        return []
    match = re.search(r"\[.*\]", text, re.S)
    if not match:
        return []
    try:
        items = json.loads(match.group(0))
    except ValueError:
        return []
    if not isinstance(items, list):
        return []
    out = []
    for item in items[:MAX_PROPOSALS]:
        if not isinstance(item, dict):
            continue
        title = _clean(item.get("title"), TITLE_MAX)
        body = str(item.get("body") or "").strip()[:BODY_MAX]
        if not title or not body:
            continue
        out.append({"title": title, "hook": _clean(item.get("hook"), HOOK_MAX) or title,
                    "body": body})
    return out


def add(proposals: list[dict], reviewed_at: float) -> list[dict]:
    """Store new proposals (skipping titles already pending or remembered)."""
    with _lock:
        body = load()
        known = {jarvis_memory.slugify(p["title"]) for p in body["pending"]}
        known |= {e["slug"] for e in jarvis_memory.memory_entries()}
        added = []
        for p in proposals:
            slug = jarvis_memory.slugify(p["title"])
            if slug in known:
                continue
            known.add(slug)
            entry = {"id": secrets.token_hex(6), "created": time.time(), **p}
            body["pending"].append(entry)
            added.append(entry)
        body["pending"] = body["pending"][-MAX_PENDING:]
        body["last_reviewed"] = reviewed_at
        _save(body)
        return added


def _take(proposal_id: str) -> Optional[dict]:
    body = load()
    for i, p in enumerate(body["pending"]):
        if p.get("id") == proposal_id:
            del body["pending"][i]
            _save(body)
            return p
    return None


def approve(proposal_id: str, title: str = "", hook: str = "", body: str = "") -> Optional[Path]:
    """Write it as a memory (with the user's edits). Raises IndexFull."""
    with _lock:
        state = load()
        match = next((p for p in state["pending"] if p.get("id") == proposal_id), None)
        if match is None:
            return None
        title = _clean(title or match["title"], TITLE_MAX)
        hook = _clean(hook or match.get("hook") or title, HOOK_MAX)
        text = (body or match["body"]).strip()[:BODY_MAX * 4]
        jarvis_memory.add_to_index(title, hook)   # first: it is the one that can refuse
        path = jarvis_memory.write_memory(title, text)
        _take(proposal_id)
        return path


def dismiss(proposal_id: str) -> bool:
    with _lock:
        return _take(proposal_id) is not None
