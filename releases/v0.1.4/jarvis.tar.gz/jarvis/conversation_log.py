"""Everything that was said, one Markdown file per day.

`<brain home>/conversations/2026-11-03.md`:

    # Conversations, 2026-11-03

    ## 14:32:05
    **You:** what's the server doing
    **JARVIS:** Four percent CPU and plenty of disk, sir.

Plain files for the same reason the rest of memory is: the user can read,
search, correct or delete them by hand, and they travel in a memory export.
Each field is flattened to one line, so an utterance can never forge an
entry of its own, and the parser below reads back exactly what was written.

What is recorded: the user's own words and what JARVIS actually said back.
Never tool output. The brain's replies can paraphrase a page it read; the
owner has accepted that, so searching this log does not taint a turn
(server.TAINT_EXEMPT_TOOLS says so).
"""

from __future__ import annotations

import re
import threading
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import data_paths
from jarvis_memory import one_line

FIELD_MAX = 4000
_DAY_RE = re.compile(r"\d{4}-\d{2}-\d{2}")
_TIME_RE = re.compile(r"## (\d{2}:\d{2}:\d{2})")
_WORD_RE = re.compile(r"[a-z0-9']+")
_STOP = frozenset("a an the and or but to of in on at for is it its it's i you "
                  "me my we what was were be do did does that this with sir".split())
_lock = threading.Lock()


@dataclass
class Exchange:
    day: str
    time: str
    you: str
    jarvis: str

    @property
    def epoch(self) -> float:
        try:
            return datetime.strptime(f"{self.day} {self.time}", "%Y-%m-%d %H:%M:%S").timestamp()
        except ValueError:
            return 0.0

    def as_dict(self) -> dict:
        return {"day": self.day, "time": self.time, "you": self.you, "jarvis": self.jarvis}


def _dir() -> Path:
    path = data_paths.conversations_dir()
    path.mkdir(parents=True, exist_ok=True)
    return path


def append(you: str, jarvis: str, when: Optional[datetime] = None) -> Optional[Path]:
    """Record one exchange. Never raises: a full disk must not stop a reply."""
    you = one_line(you, FIELD_MAX)
    jarvis = one_line(jarvis, FIELD_MAX)
    if not you and not jarvis:
        return None
    when = when or datetime.now()
    day = when.strftime("%Y-%m-%d")
    try:
        with _lock:
            path = _dir() / f"{day}.md"
            new = not path.exists()
            with path.open("a", encoding="utf-8") as fh:
                if new:
                    fh.write(f"# Conversations, {day}\n\n")
                fh.write(f"## {when.strftime('%H:%M:%S')}\n"
                         f"**You:** {you}\n**JARVIS:** {jarvis}\n\n")
        return path
    except OSError:
        return None


def parse_day(path: Path) -> list[Exchange]:
    day = path.stem
    out: list[Exchange] = []
    current: Optional[Exchange] = None
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return out
    for line in lines:
        m = _TIME_RE.fullmatch(line.strip())
        if m:
            current = Exchange(day, m.group(1), "", "")
            out.append(current)
        elif current is not None and line.startswith("**You:** "):
            current.you = line[len("**You:** "):]
        elif current is not None and line.startswith("**JARVIS:** "):
            current.jarvis = line[len("**JARVIS:** "):]
    return out


def days() -> list[Path]:
    try:
        files = [p for p in _dir().glob("*.md") if _DAY_RE.fullmatch(p.stem)]
    except OSError:
        return []
    return sorted(files, key=lambda p: p.stem, reverse=True)


def days_meta() -> list[dict]:
    return [{"slug": p.stem, "count": len(parse_day(p))} for p in days()]


def since(epoch: float, max_chars: int = 8000) -> list[Exchange]:
    """Exchanges after `epoch`, oldest first, the newest kept when over budget."""
    cutoff_day = datetime.fromtimestamp(epoch).strftime("%Y-%m-%d") if epoch else ""
    found: list[Exchange] = []
    for path in sorted(days(), key=lambda p: p.stem):
        if path.stem < cutoff_day:
            continue
        found.extend(e for e in parse_day(path) if e.epoch > epoch)
    kept, used = [], 0
    for e in reversed(found):
        used += len(e.you) + len(e.jarvis) + 40
        if used > max_chars and kept:
            break
        kept.append(e)
    return list(reversed(kept))


def last_exchange_epoch() -> float:
    for path in days():
        entries = parse_day(path)
        if entries:
            return entries[-1].epoch
    return 0.0


def _words(text: str) -> set[str]:
    return {w for w in _WORD_RE.findall(text.lower()) if w not in _STOP and len(w) > 1}


def search(query: str, days_back: int = 90, limit: int = 6) -> list[Exchange]:
    """Best-matching exchanges: every query word counts, a word in what the
    user said counts double, and newer wins a tie."""
    wanted = _words(query)
    if not wanted:
        return []
    oldest = (datetime.now() - timedelta(days=max(1, days_back))).strftime("%Y-%m-%d")
    scored = []
    for path in days():
        if path.stem < oldest:
            break
        for e in parse_day(path):
            you, said = _words(e.you), _words(e.jarvis)
            score = 2 * len(wanted & you) + len(wanted & said)
            if score:
                scored.append((score, e.epoch, e))
    scored.sort(key=lambda t: (t[0], t[1]), reverse=True)
    return [e for _, _, e in scored[:limit]]


def doc_path(slug: str) -> Optional[Path]:
    if not isinstance(slug, str) or not _DAY_RE.fullmatch(slug):
        return None
    path = _dir() / f"{slug}.md"
    return path if path.is_file() and not path.is_symlink() else None
