"""Where JARVIS is running: on the user's own Mac, or on a cloud server.

`JARVIS_MODE=cloud` is set by the DigitalOcean installer (`deploy/`) and by
nothing else. It means three things, and every one of them is enforced in
code rather than asked of the model:

1. **No on-device control.** The server is not the user's computer. There is
   no Terminal.app to type into, no Chrome to open a tab in, no screen to
   capture and no permission dialog to answer, so the tools that do those
   things (`DEVICE_TOOLS`) are left off the brain's allowlist, left out of
   the MCP child's `tools/list`, and refused by `/internal/tool` if anything
   names them anyway. Three layers, because the CLI is measured NOT to filter
   MCP tools by `--tools` (see brain.py), so the allowlist alone would not do.

2. **Authentication is mandatory.** A cloud server is reachable from the
   internet through its reverse proxy, so the `Origin` check that protects a
   loopback install is not enough (issue #1). `server.lifespan` refuses to
   start in cloud mode without a password configured (`web_auth`).

3. **Nothing is inferred from the machine.** The server's public IP is a
   datacenter, so weather is never located by IP lookup, and there is no
   `~/Desktop` to scan for projects.

Read per call, never cached: the test suite flips the variable per test.
"""

from __future__ import annotations

import os

CLOUD = "cloud"
LOCAL = "local"

# The tools that act on, or look at, the machine JARVIS runs on as if a person
# were sitting at it. Every one of them is AppleScript or `screencapture`
# underneath (actions.py, dialog.py, screen.py).
DEVICE_TOOLS = frozenset({
    "open_in_browser",      # opens a tab in the user's Chrome
    "open_in_terminal",     # opens a Terminal.app window
    "open_in_editor",       # launches VS Code on the desktop
    "run_command",          # types a command into a visible Terminal window
    "what_is_on_screen",    # System Events window list
    "look_at_screen",       # screencapture
    "answer_dialog",        # keystrokes into a Terminal tab (Accessibility)
})


def mode() -> str:
    raw = (os.getenv("JARVIS_MODE") or "").strip().lower()
    return CLOUD if raw == CLOUD else LOCAL


def is_cloud() -> bool:
    return mode() == CLOUD


def tool_available(name: str) -> bool:
    """Is the JARVIS tool `name` (bare, or `mcp__jarvis__name`) usable here?"""
    bare = name.split("__")[-1] if name.startswith("mcp__jarvis__") else name
    return not (is_cloud() and bare in DEVICE_TOOLS)


# Appended to the brain's launch prompt in cloud mode. The persona
# (jarvis_home/CLAUDE.md) describes a Mac on the user's desk at length, and a
# user may have edited their copy, so the correction goes in the launch
# prompt, which is rebuilt for every brain generation and cannot go stale.
CLOUD_PROMPT = (
    " DEPLOYMENT: you are running on a cloud server, not on the user's Mac. "
    "You cannot see his screen, open his browser, open a Terminal or an "
    "editor, run a command in a window he can watch, or answer a dialog on "
    "his computer — those tools do not exist here, whatever your notes say. "
    "Projects live on the server; you can still read them, build in them "
    "with spawned runs, and report on them, and he watches the work on the "
    "dashboard. If he asks for something on his own computer, say plainly "
    "that it is out of reach from the server. What you CAN do here: report "
    "the server's own health and logs (system_status, server_logs); hand him "
    "files, which appear on his screen as downloads (save_screenshot of any "
    "page, including a dev server you started; create_file for a document "
    "you write; share_file for a file from a project), and open windows on "
    "his screen (save_screenshot shows a page, show_file shows a file); see "
    "files he uploads (project 'uploads'; look_at_file for pictures); and "
    "work with his "
    "GitHub (github_read, github_write; code changes and pull requests go "
    "through a spawned run, which has git and gh).")
