/**
 * Windows on the voice page: what JARVIS shows the user.
 *
 * The server sends `{"type":"window", kind, title, url, name?, source?}` when
 * a tool wants something on screen (show_file, save_screenshot); the file
 * cards open the same windows. Kinds:
 *
 *   image     an <img>
 *   markdown  rendered by the dashboard's own createElement-only renderer
 *   text      a <pre>
 *   html      a file JARVIS wrote, rendered in an iframe with
 *             sandbox="allow-scripts" and NO allow-same-origin: it runs in an
 *             opaque origin, so it cannot read the page, its cookies or the
 *             API. The server only ever serves it as text/plain; it becomes a
 *             document here, inside the sandbox, via srcdoc.
 *   page      a screenshot of a web page, with Refresh (a new capture). A
 *             real site cannot be embedded: most refuse framing, and it
 *             would run beside the signed-in session.
 *   download  anything else: a link
 *
 * Windows drag by their title bar, resize from the corner, come to the front
 * on click, and close with × or Escape. Everything is createElement /
 * textContent.
 */

import { markdown } from "./dashboard/markdown";

export interface WindowSpec {
  kind: string;
  title: string;
  url: string;
  name?: string;
  source?: string;
}

const MAX_WINDOWS = 4;
const TEXT_LIMIT = 400_000;
let layer: HTMLElement | null = null;
let z = 30;
let opened = 0;

function ensureLayer(): HTMLElement {
  if (!layer) {
    layer = document.createElement("div");
    layer.id = "window-layer";
    document.body.appendChild(layer);
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && layer?.lastElementChild) {
        const top = [...layer.children].sort(
          (a, b) => Number((b as HTMLElement).style.zIndex) - Number((a as HTMLElement).style.zIndex))[0];
        top?.remove();
      }
    });
  }
  return layer;
}

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (text !== undefined) node.textContent = text;
  return node;
}

function iconButton(label: string, title: string, onClick: () => void): HTMLButtonElement {
  const b = el("button", "jw-btn", label);
  b.type = "button";
  b.title = title;
  b.addEventListener("click", (e) => { e.stopPropagation(); onClick(); });
  return b;
}

function draggable(win: HTMLElement, handle: HTMLElement): void {
  let sx = 0, sy = 0, ox = 0, oy = 0;
  handle.addEventListener("pointerdown", (e) => {
    if ((e.target as HTMLElement).closest(".jw-btn")) return;
    sx = e.clientX; sy = e.clientY;
    ox = win.offsetLeft; oy = win.offsetTop;
    handle.setPointerCapture(e.pointerId);
    win.classList.add("dragging");
  });
  handle.addEventListener("pointermove", (e) => {
    if (!handle.hasPointerCapture(e.pointerId)) return;
    const x = Math.min(Math.max(0, ox + e.clientX - sx), window.innerWidth - 80);
    const y = Math.min(Math.max(0, oy + e.clientY - sy), window.innerHeight - 40);
    win.style.left = `${x}px`;
    win.style.top = `${y}px`;
  });
  handle.addEventListener("pointerup", (e) => {
    handle.releasePointerCapture(e.pointerId);
    win.classList.remove("dragging");
  });
}

async function fill(body: HTMLElement, spec: WindowSpec, setMeta: (t: string) => void): Promise<void> {
  body.replaceChildren();
  if (spec.kind === "image" || spec.kind === "page") {
    const img = el("img", "jw-img");
    img.alt = spec.title;
    img.src = spec.url;
    body.append(img);
    return;
  }
  if (spec.kind === "download") {
    const a = el("a", "jw-link", "Download this file");
    a.href = `${spec.url}?download=1`;
    a.setAttribute("download", spec.name ?? "");
    body.append(el("p", "jw-note", "This kind of file can't be shown here."), a);
    return;
  }
  body.append(el("p", "jw-note", "Loading…"));
  let text = "";
  try {
    const res = await fetch(spec.url, { cache: "no-store" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    text = await res.text();
  } catch (e) {
    body.replaceChildren(el("p", "jw-note", "Could not load it."));
    return;
  }
  if (text.length > TEXT_LIMIT) {
    text = text.slice(0, TEXT_LIMIT);
    setMeta("showing the beginning");
  }
  body.replaceChildren();
  if (spec.kind === "markdown") {
    body.append(markdown(text, "md jw-md"));
  } else if (spec.kind === "html") {
    const frame = el("iframe", "jw-frame");
    // allow-scripts, and deliberately NOT allow-same-origin: see the header.
    frame.setAttribute("sandbox", "allow-scripts");
    frame.setAttribute("referrerpolicy", "no-referrer");
    frame.srcdoc = text;
    body.append(frame);
  } else {
    body.append(el("pre", "jw-pre", text));
  }
}

export function openWindow(spec: WindowSpec): void {
  const root = ensureLayer();
  while (root.childElementCount >= MAX_WINDOWS) root.firstElementChild?.remove();

  const win = el("section", `jw jw--${spec.kind}`);
  win.setAttribute("role", "dialog");
  win.setAttribute("aria-label", spec.title);
  const offset = (opened++ % 5) * 28;
  const width = Math.min(spec.kind === "page" ? 760 : 640, window.innerWidth - 32);
  win.style.width = `${width}px`;
  win.style.left = `${Math.max(16, (window.innerWidth - width) / 2 - 60 + offset)}px`;
  win.style.top = `${Math.max(16, 80 + offset)}px`;
  win.style.zIndex = String(++z);
  win.addEventListener("pointerdown", () => { win.style.zIndex = String(++z); });

  const bar = el("header", "jw-bar");
  const title = el("span", "jw-title", spec.title);
  const meta = el("span", "jw-meta", "");
  const setMeta = (t: string) => { meta.textContent = t; };
  const actions = el("span", "jw-actions");
  const body = el("div", "jw-body");

  if (spec.kind === "page" && spec.source) {
    setMeta(hostOf(spec.source));
    actions.append(iconButton("↻", "Refresh", async () => {
      setMeta("refreshing…");
      try {
        const res = await fetch("/api/view/screenshot", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: spec.source }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
        spec.url = data.url;
        spec.name = data.name;
        await fill(body, spec, setMeta);
        setMeta(`${hostOf(spec.source!)} · ${new Date().toLocaleTimeString()}`);
      } catch (e) {
        setMeta(e instanceof Error ? e.message : "refresh failed");
      }
    }));
    if (!/^https?:\/\/(localhost|127\.|\[::1\])/i.test(spec.source)) {
      const open = el("a", "jw-btn", "↗");
      open.href = spec.source;
      open.target = "_blank";
      open.rel = "noopener noreferrer";
      open.title = "Open the real page in a new tab";
      actions.append(open);
    }
  }
  if (spec.kind !== "download") {
    const dl = el("a", "jw-btn", "⤓");
    dl.href = `${spec.url}?download=1`;
    dl.title = "Download";
    dl.setAttribute("download", spec.name ?? "");
    actions.append(dl);
  }
  actions.append(
    iconButton("▢", "Larger / smaller", () => win.classList.toggle("jw--max")),
    iconButton("×", "Close", () => win.remove()),
  );
  bar.append(title, meta, actions);
  win.append(bar, body);
  root.append(win);
  draggable(win, bar);
  void fill(body, spec, setMeta);
}

function hostOf(url: string): string {
  try { return new URL(url).host; } catch { return url; }
}

/** The window kind for a file name, mirroring server._window_kind. */
export function kindFor(name: string): string {
  const ext = (name.match(/\.[a-z0-9]+$/i)?.[0] ?? "").toLowerCase();
  if ([".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg"].includes(ext)) return "image";
  if ([".md", ".markdown"].includes(ext)) return "markdown";
  if ([".html", ".htm"].includes(ext)) return "html";
  if ([".txt", ".csv", ".json", ".py", ".js", ".ts", ".sh", ".yaml", ".yml", ".toml",
       ".xml", ".sql", ".log", ".css"].includes(ext)) return "text";
  return "download";
}
