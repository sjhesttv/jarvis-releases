# JARVIS in the cloud (DigitalOcean)

Run JARVIS on a small DigitalOcean droplet instead of your Mac, and talk to it
from Chrome on any computer. It is **single-user**: you, signed in with one
password.

```
Chrome (any device) ──HTTPS/WSS──▶ Caddy :443  (automatic Let's Encrypt)
                                      │
                                      ▼
                     JARVIS on 127.0.0.1:8340  (systemd, user "jarvis", JARVIS_MODE=cloud)
                     ├─ sign-in required on every request and WebSocket
                     ├─ brain: claude -p on your Claude subscription
                     └─ runs:  claude -p in /var/lib/jarvis/projects
```

## What changes in the cloud

* **No on-device control.** The server is not your computer, so the tools
  that drive one are switched off at all three layers (brain allowlist, the
  MCP child's tool list, and `/internal/tool`): opening a browser, Terminal or
  editor, running a command in a visible window, seeing your screen, and
  answering a permission dialog. See `deploy_mode.DEVICE_TOOLS`. JARVIS still
  reads, builds and reports on projects, and you watch work on the dashboard.
* **A password.** Every page, API call and WebSocket needs a session from
  `/login` (`auth_store.py`, `web_auth.py`). JARVIS refuses to start in cloud
  mode without one.
* **No guessing from the machine.** Weather uses the city you give the wizard,
  not the datacenter's IP, and projects live in `/var/lib/jarvis/projects`,
  not `~/Desktop`.
* **Contained.** The `jarvis` user's processes (brain, runs, headless
  Chromium) cannot reach the droplet metadata service or private networks
  (`jarvis-firewall`). The service runs with `ProtectSystem=strict` and can
  write only `/var/lib/jarvis`.

## You need

* A DigitalOcean account.
* A **Claude Pro or Max** subscription. JARVIS runs on it; no API key.
* A **Fish Audio** API key (https://fish.audio). This is JARVIS's voice.
* **Google Chrome** on the computer you talk from. The mic needs it.
* Optional: a domain name. Without one you get a free
  `<your-ip>.sslip.io` address with a real certificate.

## 1. Create the droplet (about 2 minutes, then 5 minutes unattended)

1. **Create → Droplets.** Choose **Ubuntu 24.04 (LTS) x64**.
2. Size: **Basic, Regular, 2 vCPU / 4 GB** (about $24/mo). Headless Chromium
   and a few parallel Claude Code runs need the memory. 2 GB will swap.
3. Authentication: **SSH key** (not a password).
4. **Advanced options → Add initialization scripts (user data)** and paste
   the contents of [`deploy/cloud-init.yaml`](../deploy/cloud-init.yaml).
   It contains no secrets. Never put any there, because user-data is readable
   from inside the droplet.
5. Optional: enable **weekly backups** (+20%). They are the simplest way to
   keep your data, memory and projects safe.
6. Create it, and wait about 5 minutes for the install to finish
   (`tail -f /var/log/jarvis-install.log` if you SSH in early).

Already have an Ubuntu 24.04 droplet? Install directly instead:

```bash
curl -fsSL https://raw.githubusercontent.com/sjhesttv/jarvis-releases/main/install.sh -o install.sh
```

```bash
sudo bash install.sh
```

## 2. Run the wizard (about 3 minutes)

```bash
ssh root@<droplet-ip>
```

```bash
sudo jarvis-setup
```

It walks through six steps. Enter keeps the current value, so it is safe to
re-run:

1. **Address.** Your domain (its A record must point at the droplet), or the
   offered `<ip>.sslip.io`.
2. **Password.** At least 12 characters. This is the only lock on a machine
   that runs code, so use a passphrase.
3. **Fish Audio key.** Checked against Fish Audio before it is saved.
4. **Claude login.** The wizard runs `claude setup-token`. Open the link it
   prints on any device, sign in, paste the code back, then paste the
   `sk-ant-oat…` token it prints.
5. **About you.** Your name, city (for weather), units and brain model.
6. **GitHub (optional).** You can skip this and connect it later from
   **Settings → Connections** in the app. A *fine-grained* token limited to the repositories
   JARVIS may touch, plus a commit name and email.

It then writes the configuration, applies the egress rules, starts JARVIS and
Caddy, waits for HTTPS, and prints your address.

## 3. Use it

Open `https://<your-address>` in **Chrome**, sign in, click once to enable
audio, and speak. The run dashboard is `https://<your-address>/dashboard`,
with **Sign out** in its header.

## Day to day

| Task | Command |
|---|---|
| Connect GitHub, or add/remove MCP servers | In the app: **⋯ menu → Settings → Connections** |
| Move to a new server | **Settings → Memory → Download export** on the old one, **Import** on the new one (or `memory_archive.py export/import` on the command line) |
| Server health, and files JARVIS gave you | Dashboard → **Server** tab |
| Give JARVIS a file | Drop it anywhere on the voice page, or the paperclip; it goes to the `uploads` project |
| Review memories JARVIS proposes, edit or delete what he remembers, read past conversations | Dashboard → **Memory** tab |
| Change the password (signs out every browser) | `sudo jarvis-setup --password` |
| Redo the Claude login (token expired) | `sudo jarvis-setup --claude` |
| See what is configured | `sudo jarvis-setup --status` |
| Update to the latest release | `sudo jarvis-update` |
| Roll back the last update | `sudo jarvis-update --rollback` |
| Logs | `journalctl -u jarvis -f` |
| HTTPS / certificate logs | `journalctl -u caddy -n 50` |
| Sign out everywhere, keeping the password | `sudo -u jarvis env JARVIS_DATA_DIR=/var/lib/jarvis/data /opt/jarvis/venv/bin/python /opt/jarvis/current/auth_store.py logout-everywhere` |

If JARVIS says "my language systems are down", the Claude token has usually
expired (they last about a year). Run `sudo jarvis-setup --claude`.

## Where everything lives

| Path | What | Owner / mode |
|---|---|---|
| `/opt/jarvis/current` | the release (read-only to JARVIS) | root |
| `/opt/jarvis/venv` | Python, from the hash-locked `deploy/requirements.lock` | root |
| `/etc/jarvis/jarvis.env` | mode, paths, address | root:jarvis 0640 |
| `/etc/jarvis/secrets.env` | Claude token, GitHub token | root:jarvis 0640 |
| `/var/lib/jarvis/settings.env` | Fish key, voice, name, weather, model (the UI's settings page edits it) | jarvis 0600 |
| `/var/lib/jarvis/data` | database, memory, password hash, connections.json | jarvis 0700 |
| `/var/lib/jarvis/projects` | everything JARVIS builds | jarvis 0700 |

Back up `/var/lib/jarvis`. That is everything that is yours.

## Security notes

* The firewall (`ufw`) allows only 22, 80 and 443. Use SSH keys.
  Consider a DigitalOcean Cloud Firewall with the same rules on top.
* Sign-in failures are rate-limited (10 per address and 50 overall per 15
  minutes). Each guess also costs an scrypt hash.
* Runs execute with `--dangerously-skip-permissions` as the `jarvis` user
  (issue #3). The droplet is the sandbox: keep nothing else on it, and give
  JARVIS only the fine-grained GitHub token it needs.
* MCP servers you add to `/var/lib/jarvis/data/jarvis/connections.json` can
  act with their own credentials (issue #2). Prefer read-only tokens.

## Publishing releases (one-time setup, for the maintainer)

This repository is private, so droplets download a **public release
tarball** from the public repository `sjhesttv/jarvis-releases`. Its files are
served from `raw.githubusercontent.com`:

| File | What |
|---|---|
| `install.sh` | the bootstrap that cloud-init downloads |
| `latest/jarvis.tar.gz` (+ `.sha256`, `VERSION`) | what install and update use |
| `releases/<tag>/` | every published version, kept |

To publish automatically from a tag:

1. Create a fine-grained personal access token with **Contents: Read and
   write** on `jarvis-releases` only. Add it to *this* repository as the
   Actions secret `RELEASES_TOKEN`. If the public repo has another name, also
   set the Actions variable `RELEASES_REPO` to `owner/name`, and update the
   URLs in `deploy/install.sh` and `deploy/cloud-init.yaml`.
2. Tag a release:
   ```bash
   git tag v0.2.0
   ```
   ```bash
   git push origin v0.2.0
   ```
   `.github/workflows/release.yml` runs the cloud tests, builds the frontend,
   and commits the tarball, its checksum and `install.sh` to
   `jarvis-releases`. Installs and updates refuse a tarball whose checksum
   does not match.

The tarball contains the source code. JARVIS's license allows personal,
non-commercial use and copying with the notice kept (it ships `LICENSE`), but
not offering it as a commercial or hosted service.
