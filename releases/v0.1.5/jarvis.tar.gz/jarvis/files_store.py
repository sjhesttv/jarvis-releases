"""Files JARVIS hands to the user: screenshots, documents he wrote, and
copies of project files. The "outbox".

One flat folder, `<data>/files`, private to the service user. A file gets in
only through `save_bytes` / `save_text` / `copy_in`, which pick its name
(`20261103-031500-front-page.png`) — so a name is never a path, and serving
one is a lookup in this folder, never a join with user input.

The browser fetches them from `/api/files/<name>` behind the sign-in. They are
served as downloads, except images, which may be shown inline; every response
carries `Content-Security-Policy: sandbox` so an HTML or SVG file can never
run script on JARVIS's origin.
"""

from __future__ import annotations

import os
import re
import shutil
import stat
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import data_paths

MAX_FILE_BYTES = 200 * 1024 ** 2         # one file
MAX_TEXT_BYTES = 2 * 1024 ** 2           # a document the brain writes
MAX_TOTAL_BYTES = 5 * 1024 ** 3          # the whole outbox

NAME_RE = re.compile(r"[0-9]{8}-[0-9]{6}-[a-z0-9][a-z0-9._-]{0,80}")
_SLUG_DROP = re.compile(r"[^a-z0-9.]+")

# Shown in the page (an <img>); everything else is a download.
INLINE_TYPES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                ".gif": "image/gif", ".webp": "image/webp",
                # Shown through <img>, where an SVG's script never runs; a
                # direct visit is still covered by the download CSP sandbox.
                ".svg": "image/svg+xml"}
TEXT_EXTENSIONS = {".md", ".txt", ".csv", ".json", ".html", ".py", ".js", ".ts",
                   ".sh", ".yaml", ".yml", ".toml", ".xml", ".sql", ".log", ".css"}


class FileProblem(ValueError):
    """Something to tell the user; the message is spoken."""


@dataclass
class Entry:
    name: str
    size: int
    created: float

    @property
    def inline(self) -> bool:
        return Path(self.name).suffix.lower() in INLINE_TYPES

    def as_dict(self) -> dict:
        return {"name": self.name, "size": self.size, "created": self.created,
                "inline": self.inline, "url": f"/api/files/{self.name}"}


def outbox() -> Path:
    path = data_paths.data_dir() / "files"
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    return path


def _slug(hint: str, ext: str) -> str:
    base = Path(str(hint or "file")).name.lower()
    stem, dot, given_ext = base.rpartition(".")
    if not dot:
        stem, given_ext = base, ""
    ext = (ext or (f".{given_ext}" if given_ext else "")).lower()
    if not re.fullmatch(r"\.[a-z0-9]{1,10}", ext or ".x"):
        ext = ".bin"
    stem = _SLUG_DROP.sub("-", stem).strip("-.")[:60] or "file"
    return f"{stem}{ext}"


def _fresh_name(hint: str, ext: str = "") -> str:
    stamp = time.strftime("%Y%m%d-%H%M%S")
    slug = _slug(hint, ext)
    name = f"{stamp}-{slug}"
    n = 2
    while (outbox() / name).exists():
        stem, dot, suffix = slug.rpartition(".")
        name = f"{stamp}-{stem}-{n}.{suffix}" if dot else f"{stamp}-{slug}-{n}"
        n += 1
    return name


def _used_bytes() -> int:
    total = 0
    for entry in outbox().iterdir():
        try:
            total += entry.lstat().st_size
        except OSError:
            pass
    return total


def _check_room(size: int) -> None:
    if size > MAX_FILE_BYTES:
        raise FileProblem("that file is too large to hand over")
    if _used_bytes() + size > MAX_TOTAL_BYTES:
        raise FileProblem("the files folder is full — delete some from the dashboard first")


def save_bytes(hint: str, data: bytes, ext: str = "") -> Entry:
    _check_room(len(data))
    name = _fresh_name(hint, ext)
    path = outbox() / name
    fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, "wb") as fh:
        fh.write(data)
    return entry(name)


def save_text(hint: str, text: str) -> Entry:
    data = str(text).encode("utf-8")
    if len(data) > MAX_TEXT_BYTES:
        raise FileProblem("that document is too long")
    ext = Path(str(hint)).suffix.lower()
    if ext not in TEXT_EXTENSIONS:
        ext = ".md"
    return save_bytes(hint, data, ext)


def copy_in(source: Path) -> Entry:
    info = source.lstat()
    if not stat.S_ISREG(info.st_mode):
        raise FileProblem("that is not a regular file")
    _check_room(info.st_size)
    name = _fresh_name(source.name)
    target = outbox() / name
    fd = os.open(str(target), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    try:
        with open(source, "rb") as src, os.fdopen(fd, "wb") as dst:
            shutil.copyfileobj(src, dst, 1024 * 1024)
    except BaseException:
        try:
            target.unlink()
        except OSError:
            pass
        raise
    return entry(name)


def path_for(name: str) -> Optional[Path]:
    """The file called `name` in the outbox, or None. Never follows a link."""
    if not isinstance(name, str) or not NAME_RE.fullmatch(name):
        return None
    path = outbox() / name
    try:
        info = path.lstat()
    except OSError:
        return None
    if not stat.S_ISREG(info.st_mode):
        return None
    return path


def entry(name: str) -> Entry:
    path = outbox() / name
    info = path.lstat()
    return Entry(name=name, size=info.st_size, created=info.st_mtime)


def list_files(limit: int = 200) -> list[Entry]:
    rows = []
    for path in outbox().iterdir():
        if path_for(path.name) is not None:
            rows.append(entry(path.name))
    rows.sort(key=lambda e: e.created, reverse=True)
    return rows[:limit]


def delete(name: str) -> bool:
    path = path_for(name)
    if path is None:
        return False
    path.unlink()
    return True


def content_type(name: str) -> str:
    ext = Path(name).suffix.lower()
    if ext in INLINE_TYPES:
        return INLINE_TYPES[ext]
    if ext in TEXT_EXTENSIONS:
        return "text/plain; charset=utf-8"
    return "application/octet-stream"


